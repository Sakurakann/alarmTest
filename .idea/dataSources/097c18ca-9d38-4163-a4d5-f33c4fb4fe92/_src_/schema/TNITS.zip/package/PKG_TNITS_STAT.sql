CREATE package pkg_tnits_stat is

--------------------------------------------
-- Export file for user tnits             --
-- updated by zxp on  2017-07-31-
--------------------------------------------

-- 清除记录 ------------------------------------------------------------------
  procedure BakClear(
    a_days            number
  );


-- 统计话单 ------------------------------------------------------------------
  procedure Patch_Stat(
    a_delay           Number,
    a_holdDaley       Number);

-- 按日统计(job) ------------------------------------------------------------------------
  --procedure DayStat_TestResult;
 procedure DayStat_TestResult;
-- 按日统计 ------------------------------------------------------------------------
  procedure DayStat_exe(
    c_testCode     number,
    c_startDate    varchar2,
    c_endDate      varchar2,
    c_JT_startDate varchar2,
    c_JT_endDate   varchar2,
    c_statFlag     varchar2, -- 第1位-是否统计普通，第2位-是否统计集团
    v_dateHour     varchar2
  );


procedure creatTablePartition;
 
end pkg_tnits_stat;


/
