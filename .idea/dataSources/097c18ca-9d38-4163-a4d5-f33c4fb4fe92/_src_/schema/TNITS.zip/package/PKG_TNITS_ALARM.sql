CREATE package pkg_tnits_alarm is

--------------------------------------------
-- Export file for user tnits             --
-- Created by wxl on 2009-06-22           --
-- updated by wxl on 2009-12-25           --
-- updated by lht on 2013-09-26           --
-- updated by lht on 2014-02-28           --
-- updated by psc on 2014-12-05           --
-- updated by psc on 2014-12-23           --
-- updated by psc on 2015-01-06           --
-- Create Alarm_Shield by psc on 2015-03-18 --
-- Create Alarm_Generation_delay by psc on 2015-05-07 --
-- updated by psc on 2015-05-25 table s_param add AMALRM_POOL_FLAG  1表示pool告警了单个就不告警，反之都告警 --
-- updated by psc on 2015-09-09 table s_param add GROUP_ALARAM_DETAIL_FLAG  1表示组告警中显示所有任务详细，0最多显示2条信息  z_alarm表中alarmdetail 需扩充到4000字节--
-- updated by psc on 2015-10-20 table s_param add POOL_ALARAM_FLAG  pool出告警 0：普通告警不出,1：普通告警出    DUAN_ALARAM_FLAG  port出告警 0：普通告警不出,1：普通告警出  --
-- updated by psc on 2016-01-07 modify 组告警中统计类 重复出告警问题
-- updated by psc on 2016-01-07 modify 组告警中综合类 
-- updated by psc on 2016-03-21 modify Alarm_Generation_delay  z_alarm table taskname
-- updated by psc on 2016-03-24 modify Alarm_Generation group 
-- create sgw pgw psbc pool by psc on 2016-07-08
-- updated by psc on 2016-08-16 modify failure_cause
-- updated by psc on 2016-12-23 modify sgw pgw psbc clearalarm  update
-- updated by psc on 2017-01-05 modify sgw pgw psbc clearalarm  update
-- updated by psc on 2017-06-16 add ALARM_INTERVAL param,modify Alarm_Generation_***
--------------------------------------------

  procedure ALarmCheck(
    a_cycle   number --单位：小时
  );

 procedure Alarm_Generation(
    a_taskID        in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number, --是否告警：0-清除告警 1-告警 2-关联告警，3-取消关联告警
    a_alarmFlag in number,--是否出过port  pool告警  0--未出  0x01--port  0x02-pool  0x03--port+pool
    a_failurecause in varchar2); 

  procedure Del_SwitchAlarm(
    a_switchCode    in varchar2,
    YY_CLEAR_ALARM_FLAG integer);

 procedure Alarm_Generation_port(
    a_portID        in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,
    a_failurecause in varchar2); 

    procedure Alarm_Generation_mgw(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,
    a_failurecause in varchar2); 

 ----时延波动告警-----
    procedure Alarm_Generation_delay(
    a_psNeName         in varchar2,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,   --是否告警：1-告警 0-清除告警
    a_failurecause in varchar2); 
    
procedure Alarm_Generation_tlv(
    a_taskID        in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警
    a_failurecause in varchar2); 
    
procedure Alarm_Generation_sgw(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,
    a_failurecause in varchar2); 
 
 procedure Alarm_Generation_pgw(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,
    a_failurecause in varchar2); 
 
procedure Alarm_Generation_psbc(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,
    a_failurecause in varchar2); 
    
  procedure Add_SwitchAlarm;

  function Get_AlarmDetail(
    a_switchCode varchar2
  ) return varchar2;


 procedure fail_bill_insert(
    a_neid          in number,
    a_progid        in number,
    a_alarmnumber   in number,
    a_taskid        in number,
    a_flag			in number);

procedure groups_alarm(
    a_groupid          in number,
    a_groupname        varchar2,
    a_alarmKB          in number);
    
 procedure Alarm_Shield(  --ips200设备告警
    a_shield_type      in number,--告警类型 1--主控板网络不可达  2--业务板网络不可达  3--NO.7信令不可达  4--M3UA信令不可达 5--单板状态异常 6--MSIP单板mount异常 
    a_alarmDetail   in varchar2,
    a_alarmKB       in number);  --是否告警：1-告警 0-清除告警   

end pkg_tnits_alarm;
/
