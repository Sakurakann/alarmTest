CREATE package PKG_PGW_WEB is

  -- Author  : yuxinrong
  -- Created : 2014/12/10 星期三 09:08:37
  -- Purpose : pgw报表
  
  -- Public type declarations
  type rc_class is ref cursor;
  
  -- Public constant declarations
  ---<ConstantName> constant <Datatype> := <Value>;

  -- Public variable declarations
  ---<VariableName> <Datatype>;

  -- Public function and procedure declarations
  --function <FunctionName>(<Parameter> <Datatype>) return <Datatype>;

/**
*话单明细
*/
  procedure sp_z_bill_detailCount(
       c_startTime   in varchar2,
       c_endTime     in varchar2,
       c_phone       in varchar2,
       c_def         in varchar2,
       Message         out varchar2,
       ResultCursor    out rc_class
   );
   procedure sp_z_bill_detailQueryPage(
       c_startTime   in varchar2,
       c_endTime     in varchar2,
       c_phone       in varchar2,
       c_def         in varchar2,
       c_rowStart      in number,
       c_rowEnd        in number,
       Message         out varchar2,
       ResultCursor    out rc_class
    );
    /**
    * 15分钟已统计的sum数查询
    */
     procedure sp_z_billstatCount(
       c_startTime in varchar2,
       c_endTime   in varchar2,
       c_def         in varchar2,
       Message         out varchar2,
       ResultCursor    out rc_class
     );
     
      procedure sp_z_billstatChartQuery(
       c_startTime in varchar2,
       c_endTime   in varchar2,
       c_def         in varchar2,
        c_rowStart in number,
       c_rowEnd    in number,
       Message         out varchar2,
       ResultCursor    out rc_class
     );
     
      procedure sp_z_apnbillstatCount(
       c_startTime in varchar2,
       c_endTime   in varchar2,
       c_apn       in varchar2,
       c_def         in varchar2,
       Message         out varchar2,
       ResultCursor    out rc_class
     );
     
     procedure sp_z_apnbillstatChartQuery(
       c_startTime in varchar2,
       c_endTime   in varchar2,
       c_apn       in varchar2,
       c_def         in varchar2,
       c_rowStart in number,
       c_rowEnd    in number,
       Message         out varchar2,
       ResultCursor    out rc_class
     );
end PKG_PGW_WEB;
/
