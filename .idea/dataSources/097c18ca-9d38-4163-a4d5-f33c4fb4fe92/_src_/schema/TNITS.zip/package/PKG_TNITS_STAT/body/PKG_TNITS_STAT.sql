CREATE package body pkg_tnits_stat is
------ update by zxp  2017-07-31--
-- 清除记录 ------------------------------------------------------------------
  procedure BakClear(
    a_days            number
  ) is
  begin

    /*insert into BL_GWCallBill_Bak select a.* from BL_GWCallBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    delete from BL_GWCallBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    commit;
    insert into BL_VOCCallBill_bak select a.* from BL_VOCCallBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    delete from BL_VOCCallBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    commit;
    insert into BL_RtpTestBill_bak select a.* from BL_RtpTestBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    delete from BL_RtpTestBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    commit;
    insert into BL_MosValueBill_bak select a.* from BL_MosValueBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    delete from BL_MosValueBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    commit;
    insert into BL_GPRSBill_bak select a.* from BL_GPRSBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    delete from BL_GPRSBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    commit;
    insert into BL_NeBill_bak select a.* from BL_NeBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    delete from BL_NeBill a where not exists (select taskID from Z_Taskinfo b where b.taskID=a.taskID and b.deleteFlag=0);
    commit;

    insert into BL_GWCallBill_bak select * from BL_GWCallBill where procflag = 9;
    delete from BL_GWCallBill where procflag = 9;
    commit;
    insert into BL_VOCCallBill_bak select * from BL_VOCCallBill where procflag = 9;
    delete from BL_VOCCallBill where procflag = 9;
    commit;
    insert into BL_RtpTestBill_bak select * from BL_RtpTestBill where procflag = 9;
    delete from BL_RtpTestBill where procflag = 9;
    commit;
    insert into BL_MosValueBill_bak select * from BL_MosValueBill where procflag = 9;
    delete from BL_MosValueBill where procflag = 9;
    commit;
    insert into BL_GPRSBill_bak select * from BL_GPRSBill where procflag = 9;
    delete from BL_GPRSBill where procflag = 9;
    commit;
    insert into BL_NeBill_bak select * from BL_NeBill where procflag = 9;
    delete from BL_NeBill where procflag = 9;
    commit;
    insert into BL_CSFBBILL_BAK select * from BL_CSFBBILL where procflag = 9;
    delete from BL_CSFBBILL where procflag = 9;
    commit;
    ------2015-05-25修改，原始话单保存7天--------------
    delete from BL_GWCallBill_bak where istDate < sysdate-7;---a_days*2;
    commit;
    delete from BL_VOCCallBill_bak where istDate < sysdate-7;---a_days*2;
    commit;
    delete from BL_RtpTestBill_bak where istDate < sysdate-7;--a_days*2;
    commit;
    delete from BL_MosValueBill_bak where istDate < sysdate-7;---a_days*2;
    commit;
    delete from BL_GPRSBill_bak where istDate < sysdate-7;---a_days*2;
    commit;
    delete from BL_NeBill_bak where istDate < sysdate-7;---a_days*2;
    commit;
    delete from BL_CSFBBILL_BAK where ISDATE < sysdate-7;---a_days*2;
    commit;
    delete from ZB_NeBill where istDate < sysdate-7;---a_days*2;
    commit;
    delete from ZB_NeBill_bak where istDate < sysdate-7;---a_days*2;
    commit;
    delete from Z_TaskStat where istDate < sysdate-a_days*6;
    commit;
    delete from Z_TaskStatReport where istDate < sysdate-a_days*6;
    commit;
    delete from Z_SSResult where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResult_bak select * from Z_TestResult where istDate < sysdate-a_days;
    delete from Z_TestResult where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResult_bak select * from Z_TestResult_His where istDate < sysdate-a_days;
    delete from Z_TestResult_His where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResultJTReport_bak select * from Z_TestResultJTReport where istDate < sysdate-a_days;
    delete from Z_TestResultJTReport where istDate < sysdate-a_days;
    commit;
    delete from Z_TestResult_bak where istDate < sysdate-a_days*2;
    commit;
    -- zhangyx added. 2011/02/24
    delete from Z_TestResultJTReport_bak where istDate < sysdate-a_days*2;
    commit;
    -- zhangyx end.
    delete from Z_TestResultReport_401 where istDate < sysdate-a_days;
    delete from Z_TestResultReport_420 where istDate < sysdate-a_days;
    delete from Z_TestResultReport_421 where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResult_His select * from Z_TestResult a where exists (select taskID from Z_TaskInfo b where b.taskID=a.taskID and b.executeMode != 3 and b.planTime < trunc(sysdate-7));
    delete from Z_TestResult a where exists (select taskID from Z_TaskInfo b where b.taskID=a.taskID and b.executeMode != 3 and b.planTime < trunc(sysdate-7));
    commit;
    insert into Z_TaskInfo_His select * from Z_TaskInfo where executeMode != 3 and planTime < trunc(sysdate-7);
    delete from Z_TaskInfo where executeMode != 3 and planTime < trunc(sysdate-7);
    commit;
    delete from T_BSCInfo where record_Date < sysdate-a_days/4;
    commit;*/
    ---------增加日志删除----------------
    delete from s_log where istDate < sysdate-60;
    commit;
    delete from BL_GWCallBill where istDate < sysdate-14;---a_days*2;
    commit;
    delete from BL_VOCCallBill where istDate < sysdate-14;---a_days*2;
    commit;
    delete from BL_RtpTestBill where istDate < sysdate-14;--a_days*2;
    commit;
    delete from BL_MosValueBill where istDate < sysdate-14;---a_days*2;
    commit;
    delete from BL_GPRSBill where istDate < sysdate-14;---a_days*2;
    commit;
    delete from BL_NeBill where istDate < sysdate-14;---a_days*2;
    commit;
    delete from BL_CSFBBILL where ISDATE < sysdate-14;---a_days*2;
    commit;
    delete from ZB_NeBill where istDate < sysdate-14;---a_days*2;
    commit;
    delete from Z_TaskStat where istDate < sysdate-a_days*6;
    commit;
    delete from Z_TaskStatReport where istDate < sysdate-a_days*6;
    commit;
    delete from Z_SSResult where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResult_bak select * from Z_TestResult where istDate < sysdate-a_days;
    delete from Z_TestResult where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResult_bak select * from Z_TestResult_His where istDate < sysdate-a_days;
    delete from Z_TestResult_His where istDate < sysdate-a_days;
    commit;
    insert into Z_TestResultJTReport_bak select * from Z_TestResultJTReport where istDate < sysdate-a_days;
    delete from Z_TestResultJTReport where istDate < sysdate-a_days;
    commit;
    delete from Z_TestResult_bak where istDate < sysdate-a_days*3;
    commit;
    delete from Z_TestResultJTReport_bak where istDate < sysdate-a_days*2;
    commit;
    delete from Z_TestResultReport_401 where istDate < sysdate-a_days;
    delete from Z_TestResultReport_420 where istDate < sysdate-a_days;
    delete from Z_TestResultReport_421 where istDate < sysdate-a_days;
    commit;
   -- insert into Z_TestResult_His select * from Z_TestResult a where exists (select taskID from Z_TaskInfo b where b.taskID=a.taskID and b.executeMode != 3 and b.planTime < trunc(sysdate-7));
   -- delete from Z_TestResult a where exists (select taskID from Z_TaskInfo b where b.taskID=a.taskID and b.executeMode != 3 and b.planTime < trunc(sysdate-7));
   -- commit;
   -- insert into Z_TaskInfo_His select * from Z_TaskInfo where executeMode != 3 and planTime < trunc(sysdate-7);
   -- delete from Z_TaskInfo where executeMode != 3 and planTime < trunc(sysdate-7);
   -- commit;
    delete from T_BSCInfo where record_Date < sysdate-a_days/4;
    commit;
  Exception when others then
    rollback;
  end BakClear;


-- 统计话单 ------------------------------------------------------------------
  procedure Patch_Stat(
    a_delay           number,    --延时参数
    a_holdDaley       number)    --话单保持延时
  is
    v_holdDaley       number;
  begin
    select a_holdDaley into v_holdDaley from dual; --无用语句

   /* update z_Testresult t set (TotalTime,CallerValue)=
      (select a.MosDuration, a.MosP862 from Bl_Mosvaluebill a
      where a.taskid = t.taskid and a.progid = t.progid and a.calltype = 0)
      where testcode = 421
        and talkStatus = 2
        and CallerValue = 0
        and exists (select taskid from Bl_Mosvaluebill c where c.taskid = t.taskid and c.progid = t.progid and c.calltype = 0);
    update z_Testresult t set CalledValue=
      (select b.MosP862 from Bl_Mosvaluebill b
      where b.taskid = t.taskid and b.progid = t.progid and b.calltype = 1)
      where testcode = 421
        and talkStatus = 2
        and CalledValue = 0
        and exists (select taskid from Bl_Mosvaluebill c where c.taskid = t.taskid and c.progid = t.progid and c.calltype = 1);
    insert into BL_MosValueBill_bak select * from BL_MosValueBill;
    delete from BL_MosValueBill;
    commit;


    insert into BL_GWCallBill_bak select * from BL_GWCallBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    delete from BL_GWCallBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    commit;
    insert into BL_VOCCallBill_bak select * from BL_VOCCallBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    delete from BL_VOCCallBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    commit;
    insert into BL_RtpTestBill_bak select * from BL_RtpTestBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    delete from BL_RtpTestBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    commit;
    --insert into BL_MosValueBill_bak select * from BL_MosValueBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    --delete from BL_MosValueBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    insert into BL_GPRSBill_bak select * from BL_GPRSBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    delete from BL_GPRSBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    ---------start 2013-6-3---------------
    insert into BL_NeBill_bak select * from BL_NeBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    delete from BL_NeBill where procflag = 2 and istDate < (sysdate-a_delay/(24*60*60));
    -----------------end ---------------------
    commit;*/
	Exception when others then
    	rollback;
  end;



-- 按日统计(job) ------------------------------------------------------------------------

  procedure DayStat_TestResult
     is
    c_testCode       S_TestCode.TestCode%type;
    vStat_Date       varchar2(20);
    vJTStat_Date     varchar2(20);
    -- v_lastDate       varchar2(20); 2010/08/03 Zhou.WeiFei del
    message          varchar2(50);
    rs               pkg_tnits_web.rc_class;
    vArea            number;
    v_dateHour       varchar2(200);
    Message2          varchar2(200);
  begin
    Message2 :='模块执行成功!';
    DECLARE CURSOR ResultCursor IS
     select testCode from S_TestCode where state = 1  order by testcode;
    BEGIN
      select NVL(to_char(max(statDate)+1,'yyyy-mm-dd'),'2017-03-27') into vStat_Date from Z_TaskStat;
      select NVL(to_char(max(statDate)+1,'yyyy-mm-dd'),'2017-03-27') into vJTStat_Date from Z_TaskStatReport;
      select to_number(paramValue) into vArea from S_Param where paramName = 'JTTASKSTAT_WEB_AREA';
    --分时间段统计
      select paramvalue into v_dateHour from  S_Param where paramName = 'DATEHOUR';
      
      open ResultCursor;
       LOOP
        FETCH ResultCursor INTO c_testCode;
         exit when ResultCursor%notfound;
        if c_testCode in (401, 420, 421) then
          pkg_tnits_web.SP_Z_JTTaskReportResultUpload(c_testCode, vArea, to_char(sysdate-1,'yyyy-mm-dd')||' 00:00:00', to_char(sysdate-1,'yyyy-mm-dd')||' 23:59:59', message, rs);
        end if;

        DayStat_exe(c_testCode, vStat_Date, to_char(sysdate,'yyyy-mm-dd'), vJTStat_Date, to_char(sysdate,'yyyy-mm-dd'), '11',v_dateHour);

      END LOOP;
      close ResultCursor;
      commit;
    exception when others then
      ROLLBACK;
      close ResultCursor;
       Message2 := '模块执行失败!----错误testcode: '|| c_testCode||'-----' ||substr(sqlerrm,1,100);
      dbms_output.put_line(Message2);
    END;

  end;

-- 按日统计 ------------------------------------------------------------------------
  procedure DayStat_exe(
    c_testCode     number,
    c_startDate    varchar2,
    c_endDate      varchar2,
    c_JT_startDate varchar2,
    c_JT_endDate   varchar2,
    c_statFlag     varchar2, -- 第1位-是否统计普通，第2位-是否统计集团
    v_dateHour     varchar2
  )  is
    vNormalFLag    integer;
    vJTFlag        integer;
    tmp            varchar2(30000);
    sqlstr         varchar2(30000);
     tmp2           varchar2(500);
  begin
    tmp := '';
    vNormalFLag := substr(c_statFlag, 1, 1);
    vJTFlag := substr(c_statFlag, 2, 1);
    if v_dateHour is not null then
         tmp2:='  and ( to_number(to_char(t1.StartTime,''hh24''))>=to_number(SF_StrArrayStr('''||v_dateHour||''',''-'',0)) and to_number(to_char(t1.StartTime,''hh24''))<to_number(SF_StrArrayStr('''||v_dateHour||''',''-'',1)))';
    end if;
        if c_testCode=401 or c_testCode=301 or c_testCode=730 or c_testCode=711 or c_testCode=741  then  --中继电路测试结果统计
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, ' --测试成功次数
          ||'    sum(decode(callResult, 1, 1, 0)) SuccessCount, ' --呼叫成功次数
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' --未接通次数
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, ' --时延
          --||' NVL(min(decode(testresult, 1, responseTime, null)), 0) MinDelay, ' --最小时延
          ||' NVL(min(decode(testResult,1, (select min(responseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.responseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, ' --最大时延
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数(包括单通保持)
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, ' --掉线次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,6,1,0), 0)) NoiseCount, ' --噪音次数
          ||' sum(decode(testResult, 1, decode(callResult,7,1,0), 0)) ErrCount, ' --错码次数
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) ShortCRCount, ' --回声次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --静音次数
          ||' sum(decode(testResult, 1, decode((callResult-2)*(callResult-3)*(callResult-4)*(callResult-5),0,1,0), 0)) NonBeginCRCount, ' --异常次数

         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RightCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif c_testCode=402 or c_testCode=714 then --彩铃测试结果统计表

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, ' --测试成功
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, ' --正确次数
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, ' --未接通
          ||' sum(decode(TestResult, 1, decode(sign((CallResult-1)*(CallResult-4)),1,0,ResponseTime), 0)) sumDelay, ' --时延
          ||' NVL(min(decode(TestResult, 1, to_number(decode(sign((CallResult-1)*(CallResult-4)),1,null,ResponseTime)), null)), 0) MinDelay, ' --最小时延
          ||' max(decode(TestResult, 1, decode(sign((CallResult-1)*(CallResult-4)),1,0,ResponseTime), 0)) MaxDelay, ' --最大时延
          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, 0 ErrCount, '
          ||' sum(decode(testResult, 1, decode(callResult,1,1,0), 0)) RightCount, ' --正确次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) ShortCRCount, ' --短彩铃
          ||' sum(decode(testResult, 1, decode(callResult,4,1,0), 0)) NonBeginCRCount, ' --非从头播放
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --未播放
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) NotSPCount, ' --非指定彩铃
          ||' sum(decode(testResult, 1, decode(callResult,6,1,0), 0)) RSuccessCount, ' --错误彩铃

         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '
         
         
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          --||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif c_testCode=405 then --BSC测试结果统计表

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(sign(CallResult-1),1,1,0), 0)) MonoDirectionCount, ' --单通
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, '
          
          
         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '



          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=406 or c_testCode=422) then --虚拟网测试、CAP测试结果统计表

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(sign(CallResult-1),1,1,0), 0)) MonoDirectionCount, '
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=407 or c_testCode=491 or c_testCode=492) then --亲情号码测试结果统计表

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(sign(CallResult-1),1,1,0), 0)) MonoDirectionCount, '
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';


    elsif c_testCode=408 then --IVR测试结果统计表

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=410 or c_testCode=411) then --MAP测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 4, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, totalTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, totalTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, totalTime, 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 1, 1, 0)) NotSPCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


         ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif ( c_testCode=419  or c_testCode=480 or c_testCode=429 or c_testCode=431 or c_testCode=455 or c_testCode=705 or c_testCode=813  or c_testCode=203) then --MAP短信测试

          tmp := ' sum(decode(talkStatus, 2, 1, 6, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 1, 1, 8, 1, 0)) NotSPCount, '
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, responseTime, null), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 2, 1, 8, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 1, totalTime, 0)) RSumDelay, '
          ||' min(decode(testResult, 1, totalTime, 0)) RMinDelay, '
          ||' max(decode(testResult, 1, totalTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

      elsif (c_testCode=443) then
           tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, totalTime, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, totalTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, totalTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime , 0 NotSPCount , '
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
     elsif (c_testCode=414) then --MAP短信测试

          tmp := ' sum(decode(talkStatus, 2, 1, 6, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, 1, 6, 1, 0)) RSuccessCount, '
          ||' sum(decode(talkStatus, 1, 1, 8, 1, 0)) NotSPCount, '
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, responseTime, null), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 2, 1, 8, 1, 0)) ErrCount, '

          ||' sum(decode(testResult, 1, totalTime, 0)) RSumDelay, '
          ||' min(decode(testResult, 1, totalTime, 0)) RMinDelay, '
          ||' max(decode(testResult, 1, totalTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

      elsif (c_testCode=412 or c_testCode=415 or c_testCode=413   or c_testCode=441 or c_testCode=442 or c_testCode=486) then --MAP短信测试

          tmp := ' sum(decode(talkStatus, 2, 1, 6, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 1, 1, 8, 1, 0)) NotSPCount, '
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, responseTime, null), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 2, 1, 8, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 1, totalTime, 0)) RSumDelay, '
          ||' min(decode(testResult, 1, totalTime, 0)) RMinDelay, '
          ||' max(decode(testResult, 1, totalTime, 0)) RMaxDelay, '
          --------mt时延------
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, (totalTime-responseTime), 0), 0)) sumBreakLine, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, (totalTime-responseTime), null), null)), 0) minBreakLine, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, (totalTime-responseTime), 0), 0)) maxBreakLine, '
          --------------------
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate';
        --  ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=416 or c_testCode=417  or c_testCode=488) then --MAP来电开机提醒测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, decode(talkStatus,1,1,0), 0)) RightCount, ' --关机失败
          ||' sum(decode(testResult, 1, decode(talkStatus,4,1,0), 0)) ShortCrCount, ' --呼叫失败
          ||' sum(decode(testResult, 1, decode(talkStatus,6,1,0), 0)) NonBeginCrCount, ' --开机失败
          ||' sum(decode(testResult, 1, decode(talkStatus,8,1,0), 0)) SilCount, ' --提醒失败
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, responseTime, null), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 1, totalTime, 0)) RSumDelay, '
          ||' min(decode(testResult, 1, totalTime, 0)) RMinDelay, '
          ||' max(decode(testResult, 1, totalTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 NotSPCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=418) then --MAP短信中心局数据验证测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(talkStatus, 2, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 1, 1, 0)) FailureCount, ' --超时
          ||' sum(decode(talkStatus, 4, 1, 0)) NotSPCount, '  --遗漏
          ||' sum(decode(talkStatus, 6, 1, 0)) AcrossCount, '  --多余
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, responseTime, null), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) MaxDelay, '

         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=420  or c_testCode=490 or c_testCode=302 or c_testCode=723 or c_testCode=728  or c_testCode=749) then --IP承载网测试

        tmp := ' sum(decode(callResult, 1,1,2,1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          
          -----2017-06-20------------修改丢包错报callresult=2的时候计算，时延抖动则callresult>0都计算--------------
          ||' NVL(min(decode(callResult, 2, (select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=2  and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '  --最小丢包率
          ||' max(decode(callResult, 2, lostPacketRate, 0)) RMaxDelay, '  --最大丢包率
          ||' sum(decode(callResult, 2, sendPacket-recvPacket, 0)) MonoDirectionCount, '  --丢包
          
          
          ||' NVL(min(decode(callResult,2, (select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=2  and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 2, errPacketRate, 2, errPacketRate, 0)) maxErrPacketRate, '  --最大错包率
          ||' sum(decode(callResult, 2, sendPacket*errPacketRate/100, 0)) NotSPCount, '  --错包
         
        
          ||' NVL(min(decode(callResult,0,null,(select min(minDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult>0  and zt.minDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')))), 0) MinDelay, '
          ||' max(decode(callResult, 1, maxDelay,2, maxDelay, 0)) MaxDelay, '  --最大时延
         -- ||' sum(decode(callResult, 1, avgDelay, 0)) sumDelay, '  --平均时延
         ||' sum(case when callResult>0 then avgDelay else 0 end) sumDelay, '  --平均时延
          
          ||' NVL(min(decode(callResult,0,null, (select min(breakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult>0  and zt.breakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')))), 0) minBreakLine, '
          ||' max(decode(callResult, 1, breakLine, 2, breakLine, 0)) maxBreakLine, '  --最大抖动
        --  ||' sum(decode(testResult, 1, breakLine, 0)) sumBreakLine, '  --平均抖动
          ||' sum(case when callResult>0 then breakLine else 0 end) sumBreakLine, '  --平均抖动
          
          ||' sum(decode(callResult, 2, decode(sign(lostPacketRate), 1, 1, 0), 0)) ErrCount, ' --丢包次数
          ||' sum(decode(callResult, 2, decode(sign(errPacketRate), 1, 1, 0), 0)) NonBeginCRCount, ' --错包次数
          ||' sum(decode(testResult, 1, decode(sign(breakLine), 1, 1, 0), 0)) BreakLineCount, ' --抖动次数
          ||' sum(decode(testResult, 1, decode(sign(avgDelay), 1, 1, 0), 0)) NoiseCount, ' --延时次数
          ||' sum(decode(callResult, 2, decode(sign(lostPacketRate),1,sendPacket-recvPacket,0), 0)) ShortCRCount, ' --有丢包率的丢包总和
          ||' sum(decode(callResult, 2, decode(sign(lostPacketRate),1,sendPacket,0), 0)) RightCount, ' --有丢包率的发包总和
          ||' sum(decode(callResult, 2, decode(sign(errPacketRate),1,sendPacket,0), 0)) AcrossCount, ' --有错包率的发包总和
          ||' sum(decode(callResult, 2, sendPacket, 0)) RSuccessCount, '  ----发包总和
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RSumDelay, 0 sumErrPacketRate, 0 SilCount ';


    elsif c_testCode=487 then 
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, totalTime, 0)) sumDelay, '
         -- ||' NVL(min(decode(callResult, 1, totalTime, null)), 0) MinDelay, '
          ||' NVL(min(decode(callResult,1, (select min(totalTime) from z_testresult zt where  zt.callResult=1  and  zt.taskid=t2.taskid and zt.totalTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1,totalTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 SilCount,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
      elsif (c_testCode=731) then

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          --||' NVL(min(decode(testResult, 1, lostPacketRate, null)), 0) RMinDelay, '  --最小丢包率
          ||' NVL(min(decode(testResult,1, (select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '

          ||' max(decode(testResult, 1, lostPacketRate, 0)) RMaxDelay, '  --最大丢包率
          ||' sum(decode(testResult, 1, sendPacket-recvPacket, 0)) MonoDirectionCount, '  ----平均丢包率---丢包
          --||' NVL(min(decode(testResult, 1, errPacketRate, null)), 0) minErrPacketRate, '  --最小错包率
           ||' NVL(min(decode(testResult,1, (select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '

          ||' max(decode(testResult, 1, errPacketRate, 0)) maxErrPacketRate, '  --最大错包率
          ||' sum(decode(testResult, 1, sendPacket*errPacketRate/100, 0)) NotSPCount, '  --平均错包率---错包
          --||' NVL(min(decode(testResult, 1, minDelay, null)), 0) MinDelay, '  --最小时延
           ||' NVL(min(decode(testResult,1, (select min(minDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.minDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '

          ||' max(decode(testResult, 1, maxDelay, 0)) MaxDelay, '  --最大时延
          ||' sum(decode(testResult, 1, avgDelay, 0)) sumDelay, '  --平均时延
         -- ||' NVL(min(decode(testResult, 1, breakLine, null)), 0) minBreakLine, '  --最小抖动
          ||' NVL(min(decode(testResult,1, (select min(breakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.breakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '

          ||' max(decode(testResult, 1, breakLine, 0)) maxBreakLine, '  --最大抖动
          ||' sum(decode(testResult, 1, breakLine, 0)) sumBreakLine, '  --平均抖动
          ||' sum(decode(testResult, 1, decode(sign(lostPacketRate), 1, 1, 0), 0)) ErrCount, ' --丢包次数
          ||' sum(decode(testResult, 1, decode(sign(errPacketRate), 1, 1, 0), 0)) NonBeginCRCount, ' --错包次数
          ||' sum(decode(testResult, 1, decode(sign(breakLine), 1, 1, 0), 0)) BreakLineCount, ' --抖动次数
          ||' sum(decode(testResult, 1, decode(sign(avgDelay), 1, 1, 0), 0)) NoiseCount, ' --延时次数
          ||' sum(decode(testResult, 1, decode(sign(lostPacketRate),1,sendPacket-recvPacket,0), 0)) ShortCRCount, ' --有丢包率的丢包总和
          ||' sum(decode(testResult, 1, decode(sign(lostPacketRate),1,sendPacket,0), 0)) RightCount, ' --有丢包率的发包总和
          ||' sum(decode(testResult, 1, decode(sign(errPacketRate),1,sendPacket,0), 0)) AcrossCount, ' --有错包率的发包总和
          ||' sum(decode(testResult, 1, sendPacket, 0)) RSuccessCount, '  ----发包总和
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

         ||' 0 RSumDelay, 0 sumErrPacketRate, 0 SilCount ';

     elsif (c_testCode=421 or c_testCode=303 or c_testCode = 810  or c_testCode=212 or c_testCode = 837) then --语音MOS测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) sumDelay, '
         -- ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) MinDelay, '
          ||' NVL(min(decode(testResult,1, (select min(CallerValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.CallerValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '

          ||' max(decode(callResult, 1, CallerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, CalledValue, 0)) RSumDelay, '
         -- ||' NVL(min(decode(callResult, 1, to_number(decode(CalledValue,0,null,CalledValue)), null)), 0) RMinDelay, '
          ||' NVL(min(decode(testResult,1, (select min(CalledValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.CalledValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '

          ||' max(decode(callResult, 1, CalledValue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, decode(sign(CallerValue), 1, 1, 0), 0)) ErrCount, ' --主叫mos次数
          ||' sum(decode(callResult, 1, decode(sign(CalledValue), 1, 1, 0), 0)) NonBeginCRCount, ' --被叫mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, 1), 0)) AcrossCount, ' --mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, (CallerValue+CalledValue)/2), 0)) MonoDirectionCount, ' --平均mos值
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-4.0)*((CallerValue+CalledValue)/2-5.0)), 1, 0, 1)), 0)) RightCount, ' --优mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.5)*((CallerValue+CalledValue)/2-3.9999999)), 1, 0, 1)), 0)) NoiseCount, ' --良mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.0)*((CallerValue+CalledValue)/2-3.4999999)), 1, 0, 1)), 0)) ShortCRCount, ' --中mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-1.5)*((CallerValue+CalledValue)/2-2.9999999)), 1, 0, 1)), 0)) BreakLineCount, ' --差mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-0)*((CallerValue+CalledValue)/2-1.4999999)), 1, 0, 1)), 0)) SilCount, ' --劣mos次数
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 NotSPCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif ( c_testCode = 713  or c_testCode=727 or c_testCode=732  or c_testCode=743) then --语音MOS测试

        tmp := ' sum(decode(callResult, 1,decode(callerValue*calledValue,0,0,1), 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, decode(callerValue*callerValue,0,0,callerValue), 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1,decode(callerValue*calledValue,0,0,1), 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue,0,0,calledValue), 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CalledValue,0,null,CalledValue)), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, CalledValue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, decode(sign(CallerValue), 1, 1, 0), 0)) ErrCount, ' --主叫mos次数
          ||' sum(decode(callResult, 1, decode(sign(CalledValue), 1, 1, 0), 0)) NonBeginCRCount, ' --被叫mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, 1), 0)) AcrossCount, ' --mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, (CallerValue+CalledValue)/2), 0)) MonoDirectionCount, ' --平均mos值
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-4.0)*((CallerValue+CalledValue)/2-5.0)), 1, 0, 1)), 0)) RightCount, ' --优mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.5)*((CallerValue+CalledValue)/2-3.9999999)), 1, 0, 1)), 0)) NoiseCount, ' --良mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.0)*((CallerValue+CalledValue)/2-3.4999999)), 1, 0, 1)), 0)) ShortCRCount, ' --中mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-1.5)*((CallerValue+CalledValue)/2-2.9999999)), 1, 0, 1)), 0)) BreakLineCount, ' --差mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-0)*((CallerValue+CalledValue)/2-1.4999999)), 1, 0, 1)), 0)) SilCount, ' --劣mos次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 NotSPCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=423) then --一号双机测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, '

           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=424) then --Ping测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
        --  ||' sum(decode(talkStatus, 2, replace(replace(t1.remark3,''ms'',''''),''<'',''''), 0)) sumDelay, '
         -- ||' NVL(min(decode(talkStatus, 2, replace(replace(t1.remark1,''ms'',''''),''<'',''''), null)), 0) MinDelay, '
         -- ||' max(decode(talkStatus, 2, replace(replace(t1.remark2,''ms'',''''),''<'',''''), 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 2, replace(replace(replace(t1.remark3,''*'',''''),''ms'',''''),''<'',''''), 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, replace(replace(replace(t1.remark1,''*'',''''),''ms'',''''),''<'',''''), null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, replace(replace(replace(t1.remark2,''*'',''''),''ms'',''''),''<'',''''), 0)) MaxDelay, '

          ||' 0 BreakLineCount, '
          ||' sum(decode(callResult, 1, sendPacket-recvPacket, 0)) MonoDirectionCount, '  ----丢包总数 zhangyx 2011/06/09
          ||' sum(decode(callResult, 1, sendPacket, 0)) RSuccessCount, '  ----ping包总和 zhangyx 2011/06/09
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ErrCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=425 or c_testCode=616) then --tracert测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, '

           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '



          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=426) then --无线语音MOS测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, decode(sign(CallerValue), 1, 1, 0), 0)) ErrCount, ' --主叫mos次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 NonBeginCRCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ShortCRCount, 0 SilCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=427 or c_testCode=809) then --闭合群测试, RNC监狱网

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) RightCount, '
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) ErrCount, '
          ||' sum(decode(testResult, 1, decode(callResult,4,1,0), 0)) ShortCRCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 NonBeginCRCount,  0 SilCount,'
          ||' 0 FailureCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=428 or c_testCode=801  or c_testCode=202 or c_testCode=836 or c_testCode=821 or c_testCode=822) then --局数据验证、RNC交换机局数据验证

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 NonBeginCRCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 SilCount,'
          ||' 0 RightCount, 0 ErrCount, 0 ShortCRCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=430) then --欠费风险控制

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 NotSPCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=432) then --彩铃语音平台

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 4, 1, 0)) ErrCount, ' --彩铃短信均无
          ||' sum(decode(callResult, 2, 1, 0)) SilCount, ' --未播放彩铃
          ||' sum(decode(callResult, 3, 1, 0)) BreakLineCount, ' --未收到短信
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 NotSPCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=433 or c_testCode=453) then  --主叫付费测试结果统计/锚定测试结果统计

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(sign(CallResult-1),1,1,0), 0)) MonoDirectionCount, '
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=434 or c_testCode=435) then --17951IP长途测试、自助网测试结果统计表

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=436) then --HLR测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 4, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 1, 1, 0)) NotSPCount, '
          ||' sum(decode(talkStatus, 2, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

      elsif c_testCode=437 then  --虚拟网语音测试结果统计

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, ' --测试成功次数
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, ' --呼叫成功次数
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' --未接通次数
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, ' --时延
          ||' NVL(min(decode(testresult, 1, responseTime, null)), 0) MinDelay, ' --最小时延
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, ' --最大时延
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, ' --掉线次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,6,1,0), 0)) NoiseCount, ' --噪音次数
          --||' sum(decode(testResult, 1, decode(callResult,7,1,0), 0)) ErrCount, ' --错码次数
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) ShortCRCount, ' --回声次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --静音次数
          ||' sum(decode(testResult, 1, decode((callResult-2)*(callResult-3)*(callResult-4)*(callResult-5),0,1,0), 0)) NonBeginCRCount, ' --异常次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RightCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine, 0 ErrCount ';

      elsif (c_testCode=438) then --无线座机注册流程测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(talkStatus, 2, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 1, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 3, 1, 0)) ErrCount, '
          ||' sum(decode(talkStatus, 4, 1, 0)) ShortCRCount, '
          ||' sum(decode(talkStatus, 2, totalTime, 0)) sumDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 NotSPCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, 0 MinDelay, 0 MaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';


      elsif (c_testCode=439 or c_testCode=440) then --国际漫游测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 4, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, totalTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, totalTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, totalTime, 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 1, 1, 0)) NotSPCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

         ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=451) then  --国际呼叫测试结果统计

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, ' --测试成功次数
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, ' --呼叫成功次数
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' --未接通次数
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, ' --时延
          ||' NVL(min(decode(testresult, 1, responseTime, null)), 0) MinDelay, ' --最小时延
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, ' --最大时延
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, ' --掉线次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,6,1,0), 0)) NoiseCount, ' --噪音次数
          ||' sum(decode(testResult, 1, decode(callResult,7,1,0), 0)) ErrCount, ' --错码次数
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) ShortCRCount, ' --回声次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --静音次数
          ||' sum(decode(testResult, 1, decode((callResult-2)*(callResult-3)*(callResult-4)*(callResult-5),0,1,0), 0)) NonBeginCRCount, ' --异常次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RightCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=452) then --国际长途MOS测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, CalledValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CalledValue,0,null,CalledValue)), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, CalledValue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, decode(sign(CallerValue), 1, 1, 0), 0)) ErrCount, ' --主叫mos次数
          ||' sum(decode(callResult, 1, decode(sign(CalledValue), 1, 1, 0), 0)) NonBeginCRCount, ' --被叫mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, 1), 0)) AcrossCount, ' --mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, (CallerValue+CalledValue)/2), 0)) MonoDirectionCount, ' --平均mos值
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-4.0)*((CallerValue+CalledValue)/2-5.0)), 1, 0, 1)), 0)) RightCount, ' --优mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.5)*((CallerValue+CalledValue)/2-3.9999999)), 1, 0, 1)), 0)) NoiseCount, ' --良mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.0)*((CallerValue+CalledValue)/2-3.4999999)), 1, 0, 1)), 0)) ShortCRCount, ' --中mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-1.5)*((CallerValue+CalledValue)/2-2.9999999)), 1, 0, 1)), 0)) BreakLineCount, ' --差mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-0)*((CallerValue+CalledValue)/2-1.4999999)), 1, 0, 1)), 0)) SilCount, ' --劣mos次数
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 NotSPCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=454) then --全球呼业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, decode(talkStatus,1,1,0), 0)) RightCount, ' --关机失败
          ||' sum(decode(testResult, 1, decode(talkStatus,4,1,0), 0)) ShortCrCount, ' --呼叫失败
          ||' sum(decode(testResult, 1, decode(talkStatus,6,1,0), 0)) NonBeginCrCount, ' --开机失败
          ||' sum(decode(testResult, 1, decode(talkStatus,8,1,0), 0)) SilCount, ' --提醒失败
          ||' sum(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, decode(talkStatus, 2, responseTime, null), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, decode(talkStatus, 2, responseTime, 0), 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 1, totalTime, 0)) RSumDelay, '
          ||' min(decode(testResult, 1, totalTime, 0)) RMinDelay, '
          ||' max(decode(testResult, 1, totalTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 NotSPCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=457) then --群呼群聊测试

        tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, ' --测试成功次数
          ||' sum(decode(talkStatus, 2, 1, 0)) SuccessCount, ' --成功次数
          ||' sum(decode(talkStatus, 3, 1, 0)) RightCount, ' --呼叫失败次数
          ||' sum(decode(talkStatus, 4, 1, 0)) FailureCount, ' --群呼失败次数
          ||' sum(decode(talkStatus, 2, responseTime/100, 0)) BreakLineCount, ' --平均接入时延
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, ' --最大接入响应时延(毫秒)
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, ' --最小接入响应时延(毫秒)
          ||' sum(decode(talkStatus, 2, ((detachTime+totalTime)/200), 0)) NoiseCount, ' --平均群呼响应时延
          ||' max(decode(talkStatus, 2, GREATEST(totalTime,detachTime), 0)) RMaxDelay, ' --最大群呼响应时延(毫秒)
          ||' NVL(min(decode(talkStatus, 2, LEAST(totalTime,detachTime), null)),0) RMinDelay, ' --最小群呼响应时延(毫秒)
          ||' sum(decode(talkStatus, 2, responseTime, 0)) SumDelay, ' --总接入响应时延(毫秒)
          ||' sum(decode(talkStatus, 2, (detachTime+totalTime)/2, 0)) SumBreakLine, ' --总群呼响应时延(毫秒)
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 AcrossCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 RSuccessCount, 0 RSumDelay,0 SilCount,0 ErrCount,0 RAveDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 NotSPCount,'
          ||' 0 minBreakLine, 0 maxBreakLine ';

        elsif (c_testCode=509 or c_testCode=527 or c_testCode=528 or c_testCode=529 or c_testCode=530) then  --radius服务器测试结果统计
         tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
              ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, ' --成功次数
               ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, ' --成功次数
              ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '--失败次数
              ||' sum(decode(talkstatus, 5, 1, 0)) ErrCount, ' --验证失败次数
              ||' sum(decode(talkstatus, 6, 1, 0)) RightCount, ' --计费开失败次数
              ||' sum(decode(talkstatus, 7, 1, 0)) SilCount, ' --计费结束失败次数
              ||' NVL(min(decode(talkstatus, 2, ResponseTime, 0)), 0) MinDelay, '  --验证最小时延
              ||' max(decode(talkstatus,2, ResponseTime, 0)) MaxDelay, '  --验证最大时延
              ||' sum(decode(talkstatus, 2, ResponseTime, 0)) sumDelay, '--平均时延
              ||' NVL(min(decode(talkstatus, 2, OPERATETIME, null)), 0) RMinDelay, '  --计费最小时延
              ||' max(decode(talkstatus,2, OPERATETIME, 0)) RMaxDelay, '  --计费最大时延
              ||' sum(decode(talkstatus, 2, OPERATETIME, 0)) RSumDelay, '--平均时延
              
               ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

              ||' 0 NonBeginCRCount, 0 ShortCRCount , 0 NotSPCount , 0 AcrossCount , 0 NoiseCount , '
              ||' 0 BreakLineCount , 0 MonoDirectionCount ,'
              ||' 0 minBreakLine, 0 maxBreakLine ,0 SumBreakLine,0 maxErrPacketRate, 0 sumErrPacketRate, 0 minErrPacketRate';


     elsif (c_testCode=701) then --E全球呼业务测试 2010-12-17 Zhou.WeiFei 修改

          tmp := ' sum(decode(talkStatus, 2, 1, 5, 1, 0)) test_Success_Count_, '
          ||' sum(decode(talkStatus, 2, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 2, 1, 5, 1, 0)) RightCount, '
          ||' sum(decode(talkStatus, 2, responseTime, 5, responseTime, 0)) sumDelay, '
          ||' sum(decode(talkStatus, 2, 1, 0)) ShortCRCount, '
          ||' sum(decode(talkStatus, 2, 1, 0)) RSuccessCount, '
          ||' sum(decode(talkStatus, 2, totalTime, 0)) RSumDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 FailureCount,  0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RMinDelay, 0 RMaxDelay, 0 NotSPCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MinDelay, 0 MaxDelay, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';



     elsif (c_testCode=702  or c_testCode=712 or c_testCode=726  or c_testCode=742) then --E讯语音通话测试 / SIP语音通话测试

          tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, ' --测试成功次数
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, ' --呼叫成功次数
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' --未接通次数
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, ' --时延
          ||' NVL(min(decode(testResult,1, (select min(responseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.responseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
         -- ||' NVL(min(decode(testResult, 1, totalTime, null)), 0) MinDelay, ' --最小时延
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, ' --最大时延
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, ' --IMS成功次数
          ||' sum(decode(testResult, 1, totalTime, 0)) RSumDelay, ' --IMS时延
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, ' --掉线次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,6,1,0), 0)) NoiseCount, ' --噪音次数
          ||' sum(decode(testResult, 1, decode(callResult,7,1,0), 0)) ErrCount, ' --错码次数
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) ShortCRCount, ' --回声次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --静音次数
          ||' sum(decode(testResult, 1, decode((callResult-2)*(callResult-3)*(callResult-4)*(callResult-5),0,1,0), 0)) NonBeginCRCount, ' --异常次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RightCount, 0 NotSPCount, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=703) then --E讯MOS测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, CalledValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CalledValue,0,null,CalledValue)), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, CalledValue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, totalTime, 0)) sumBreakLine, '
          ||' NVL(min(decode(callResult, 1, totalTime, null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, totalTime, 0)) maxBreakLine, '
          ||' sum(decode(callResult, 1, decode(sign(CallerValue), 1, 1, 0), 0)) ErrCount, ' --主叫mos次数
          ||' sum(decode(callResult, 1, decode(sign(CalledValue), 1, 1, 0), 0)) NonBeginCRCount, ' --被叫mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, 1), 0)) AcrossCount, ' --mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, (CallerValue+CalledValue)/2), 0)) MonoDirectionCount, ' --平均mos值
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-4.0)*((CallerValue+CalledValue)/2-5.0)), 1, 0, 1)), 0)) RightCount, ' --优mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.5)*((CallerValue+CalledValue)/2-3.9999999)), 1, 0, 1)), 0)) NoiseCount, ' --良mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-3.0)*((CallerValue+CalledValue)/2-3.4999999)), 1, 0, 1)), 0)) ShortCRCount, ' --中mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-1.5)*((CallerValue+CalledValue)/2-2.9999999)), 1, 0, 1)), 0)) BreakLineCount, ' --差mos次数
          ||' sum(decode(callResult, 1, decode(callerValue*calledValue, 0, 0, decode(sign(((CallerValue+CalledValue)/2-0)*((CallerValue+CalledValue)/2-1.4999999)), 1, 0, 1)), 0)) SilCount, ' --劣mos次数
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 NotSPCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 FailureCount ';


       elsif (c_testCode=710 or c_testCode=784) then --SIP登录测试OPERATEREASON

        tmp := ' count(progid) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(dnstime,0,decode(talkStatus, 2, 1,5,1, 0),0)) RSuccessCount, '--首注册
          ||' sum(decode(dnstime,1,decode(testResult, 1, 1, 0),0)) failureCount, ' --重注册
          ||' sum(decode(dnstime,0,decode(talkStatus, 2, 1, 0),0)) ErrCount, '--注消
          ||' sum(decode(dnstime,0,decode(talkStatus, 2, totaltime,5,totaltime, 0),0)) RSumDelay, ' --平均登陆
          ||' NVL(min(decode(dnstime,0,decode(talkStatus, 2, totaltime,5,totaltime, null),0)), 0) RMinDelay, '--最小登陆
          ||' max(decode(dnstime,0,decode(talkStatus, 2, totaltime,5,totaltime, 0),0)) RMaxDelay, '--最大登陆
          ||' sum(decode(dnstime,0,decode(talkStatus, 2, responseTime, 0))) sumDelay, ' --平均注销
          ||' NVL(min(decode(dnstime,0,decode(talkStatus, 2, responseTime, null))), 0) MinDelay, '--最小注销
          ||' max(decode(dnstime,0,decode(talkStatus, 2, responseTime, 0))) MaxDelay, ' --最大注销

          ||' sum(decode(dnstime,1,decode(talkStatus, 2, totaltime, 0))) sumErrPacketRate, ' --重平均登陆
          ||' NVL(min(decode(dnstime,1,decode(talkStatus, 2, totaltime, null))), 0) minErrPacketRate, '--重最小登陆
          ||' max(decode(dnstime,1,decode(talkStatus, 2, totaltime, 0))) maxErrPacketRate, '--重最大登陆
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, '
          ||' 0 NotSPCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';


    elsif (c_testCode=720) then --IMS自由行业务测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(talkStatus, 2, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 1, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 3, 1, 0)) ErrCount, '
          ||' sum(decode(talkStatus, 4, 1, 0)) ShortCRCount, '
          --||' sum(decode(talkStatus, 2, totalTime, 0)) sumDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

         ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 NotSPCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, 0 MinDelay, 0 MaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine, 0 sumDelay ';

    elsif (c_testCode=721) then --IMS一号通测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 1, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, '
          ||' sum(decode(talkStatus, 4, 1, 0)) NotSPCount, '
          ||' sum(decode(talkStatus, 5, 1, 0)) ErrCount, '
          ||' sum(decode(talkStatus, 6, 1, 0)) NonBeginCRCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ShortCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

 elsif (c_testCode=722 or c_testCode=734 ) then

        tmp := 'sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(DnsTime,1,1,0)) SuccessCount, '
          ||' sum(decode(DnsTime,0,1,0)) RSuccessCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '

          ||' sum(decode(DnsTime,0,decode(callResult, 1, 1, 0),0)) SilCount, ' --首注册
          ||' sum(decode(DnsTime,1,decode(callResult, 1, 1, 0),0)) failureCount, '--重注消
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          || ' 0 RSumDelay , 0 RMinDelay , 0 RMaxDelay , 0 sumErrPacketRate , 0 minErrPacketRate, 0 maxErrPacketRate ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime , 0 ErrCount , '
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
      elsif (c_testCode=735 or c_testCode=736) then

        tmp := 'sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult,1,1,0)) SuccessCount, '
          ||' sum(decode(callResult,1,1,0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult,0,1,0)) failureCount, '--注消
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          || ' 0 RSumDelay , 0 RMinDelay , 0 RMaxDelay , 0 sumErrPacketRate , 0 minErrPacketRate, 0 maxErrPacketRate ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime , 0 ErrCount , '
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 MonoDirectionCount, 0 BreakLineCount,  0 SilCount ,'
          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=754) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

     elsif (c_testCode=478) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

   elsif (c_testCode=479 or c_testCode=481 or c_testCode=482) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RMinDelay, 0 RMaxDelay,0 RSumDelay ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=802) then --RNC复制卡验证测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 2, 0)) NonBeginCrCount, ' --注册失败
          ||' sum(decode(callResult, 3, 0)) ShortCrCount, ' --复制卡失败
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 RightCount, 0 SilCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 NotSPCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 sumDelay, 0 MinDelay, 0 MaxDelay,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 RSuccessCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay';

    elsif (c_testCode=803  or c_testCode=204) then --Rnc呼叫转移测试

          tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(talkStatus, 4, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 1, 1, 0)) NotSPCount, '
          ||' sum(decode(talkStatus, 2, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, responseTime, null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, responseTime, 0)) MaxDelay, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=804  or c_testCode=205 or c_testCode=805  or c_testCode=206 or c_testCode=806  or c_testCode=209 or c_testCode=807  or c_testCode=207 or c_testCode=808 or c_testCode=811  or c_testCode=208 or c_testCode=814 or c_testCode=815 or c_testCode=816 or c_testCode=817  or c_testCode=211 or c_testCode=818  or c_testCode=210 or c_testCode=819 or c_testCode=820 or c_testCode=823   or c_testCode=213 or c_testCode=824 or c_testCode=825 or c_testCode=826  or c_testCode=827  or c_testCode=828  or c_testCode=829  or c_testCode=830  or c_testCode=831  or c_testCode=832 or c_testCode=833 or c_testCode=835) then --RNC本地虚拟网测试、RNC省级虚拟网测试、RNC家庭亲情网测试、RNC6000虚拟网测试结果统计表、RNC闭合群测试，监狱网测试 ,亲情网

         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(sign(CallResult-1),1,1,0), 0)) MonoDirectionCount, '
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

   elsif (c_testCode=834) then

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(TALKSTATUS, 4, 1, 0)) FailureCount, '
          ||' sum(decode(TALKSTATUS, 5, 1, 0)) AcrossCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, decode(sign(CallResult-1),1,1,0), 0)) MonoDirectionCount, '
          ||' sum(decode(testResult, 1, breakLine, 0)) BreakLineCount, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

      elsif (c_testCode=458 or c_testCode=459 or c_testCode=812 or c_testCode=715 or c_testCode=716 or c_testCode=718  or c_testCode=719 or c_testCode=745 or c_testCode=746 or c_testCode=748) then --铁通无线座机

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

     elsif (c_testCode=476 or c_testCode=477) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, CallerValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, to_number(decode(CallerValue,0,null,CallerValue)), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, CallerValue, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
     elsif (c_testCode=838 or c_testCode=839 or c_testCode=840  or c_testCode=841  or c_testCode=842 or c_testCode=843 or c_testCode=844 or c_testCode=845  or c_testCode=846  or c_testCode=847  or c_testCode=848 or c_testCode=849) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount,0 RSumDelay,0 RMinDelay,0  RMaxDelay,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';


    elsif (c_testCode=851 or c_testCode=852) then
       tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1,(select min(responseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.responseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, times, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult,1,(select min(times) from z_testresult zt where zt.taskid=t2.taskid and zt.times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, times, 0)) RMaxDelay, '

          ||' sum(decode(callResult, 1, totalTime, 0)) sumOperateTime, '
          ||' NVL(min(decode(callResult,1,(select min(totalTime) from z_testresult zt where zt.taskid=t2.taskid and zt.totalTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, totalTime, 0)) maxOperateTime, '
          
          ||' sum(decode(callResult, 1, t1.duration, 0)) sunDnsTime, '
          ||' NVL(min(decode(callResult,1,(select min(zt.duration) from z_testresult zt where zt.taskid=t2.taskid and zt.duration>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, t1.duration, 0)) maxDnsTime, '
          
          ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
          ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSuccessCount,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
      elsif (c_testCode=717 or c_testCode=2102) then

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, OPERATETIME, 0)) MaxDelay, '
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) RSumDelay, '
           ||' NVL(min(decode(testResult, 1, RESPONSETIME, null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) RMaxDelay, '
           ||' sum(decode(testResult, 1, ErrPacketRate, 0)) sumErrPacketRate, '
           
            ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , '
          ||' 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

    elsif (c_testCode=601 or c_testCode=602 or c_testCode=603 or c_testCode=604 or c_testCode=605 or c_testCode=606 or c_testCode=607) then --DNS解析时延测试
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

      elsif (c_testCode=611 or c_testCode=608  or c_testCode=614 or c_testCode=615 or c_testCode=618) then
          tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, callerValue, 0))  RSumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, BreakLine, 0))  sumBreakLine, '
          ||' NVL(min(decode(callResult, 1, BreakLine, null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, BreakLine, 0)) maxBreakLine, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 AcrossCount, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

        elsif ( c_testCode=619) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, AvgDelay, 0))  RSumDelay, '
          ||' NVL(min(decode(callResult, 1, AvgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AvgDelay, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, Remark4, 0))  sumBreakLine, '
          ||' NVL(min(decode(callResult, 1, Remark4, null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, Remark4, 0)) maxBreakLine, '
          ||' sum(decode(callResult, 1, callerValue, 0))  sumErrPacketRate, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, callerValue, 0)) maxErrPacketRate, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

        elsif (c_testCode=609 or c_testCode=612) then

         tmp := ' sum(decode(talkStatus, 2, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(talkStatus, 2, replace(replace(t1.remark3,''ms'',''''),''<'',''''), 0)) sumDelay, '
          ||' NVL(min(decode(talkStatus, 2, replace(replace(t1.remark1,''ms'',''''),''<'',''''), null)), 0) MinDelay, '
          ||' max(decode(talkStatus, 2, replace(replace(t1.remark2,''ms'',''''),''<'',''''), 0)) MaxDelay, '
          ||' 0 BreakLineCount, '
          ||' max(decode(callResult, 1, codedata, 0)) sumBreakLine, '
          ||' sum(decode(callResult, 1, codedata, 0)) maxBreakLine, '
          ||' NVL(min(decode(callResult, 1, codedata, null)), 0) minBreakLine, '
          ||' sum(decode(callResult, 1, sendPacket-recvPacket, 0)) MonoDirectionCount, '  ----丢包总数 zhangyx 2011/06/09
          ||' sum(decode(callResult, 1, sendPacket, 0)) RSuccessCount, '  ----ping包总和 zhangyx 2011/06/09
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 RightCount, 0 ErrCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate ';
         -- ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=610  or c_testCode=613) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, callerValue, 0))  RSumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) RMaxDelay, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 sumBreakLine , 0 minBreakLine ,0 maxBreakLine , 0 sumErrPacketRate , 0 minErrPacketRate , 0 maxErrPacketRate ,'
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 AcrossCount, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';
    elsif (c_testCode=620) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 3, 1, 0)) ErrCount, '--密码获取失败
          ||' sum(decode(callResult, 4, 1, 0)) RightCount, '--登录失败
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, '--获取密码时延
          ||' NVL(min(decode(callResult, 1, BreakLine, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, AvgDelay, 0)) RSumDelay, '--登陆时延
          ||' NVL(min(decode(callResult, 1, AvgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AvgDelay, 0)) RMaxDelay, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

           ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
        --  ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

     elsif (c_testCode=621 or c_testCode=622) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 3,1,0)) FailureCount, '
          ||' sum(decode(callResult, 3, 1, 0)) RightCount, '--登录失败
          ||' sum(decode(callResult, 1, BreakLine, 0)) RSumDelay, '--登陆时延
          ||' NVL(min(decode(callResult, 1, BreakLine, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 ErrCount,'
          ||' 0 sumDelay , 0 MinDelay ,0 MaxDelay ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

           ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
        --  ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';


     elsif (c_testCode=623 or c_testCode=624 or c_testCode=625 or c_testCode=626 or c_testCode=627 or c_testCode=628 or c_testCode=629 or c_testCode=630 or c_testCode=631) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(callResult, 1, ActivationTime, 0)) sumDelay, '--创建会议时延
          ||' NVL(min(decode(callResult, 1, ActivationTime, null)), 0) minDelay, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxDelay, '
          
          ||' sum(decode(callResult, 1, DetachTime, 0)) RSumDelay, '--查询会议时延
          ||' NVL(min(decode(callResult, 1, DetachTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, DetachTime, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumOperateTime, '--删除会议时延
          ||' NVL(min(decode(callResult, 1, DeActivationTime, null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxOperateTime, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '--会议时延
          ||' NVL(min(decode(callResult, 1, AttachTime, null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' sum(decode(callResult, 1, sptodelay, 0)) sunDnsTime, '--退出会议时延
          ||' NVL(min(decode(callResult, 1, sptodelay, null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, sptodelay, 0)) maxDnsTime, '
          
           ||' sum(decode(callResult, 1, sockettime, 0)) sumReceivetime, '--邀请与会者加入会议时延
          ||' NVL(min(decode(callResult, 1, sockettime, null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, sockettime, 0)) maxReceivetime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          

          ||' 0 ErrCount, 0 RightCount,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
           ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

    elsif (c_testCode=632 or c_testCode=633  or c_testCode=634 or c_testCode=635 or c_testCode=636 or c_testCode=637) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum(decode(testResult, 1, dnsTime, 0)) sumDelay, '--ping时延
          ||' NVL(min(decode(testResult,1,(select min(dnsTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.dnsTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, dnsTime, 0)) MaxDelay, '

          ||' sum(decode(testResult, 1, times, 0)) RSumDelay, '--平均成功率
          ||' NVL(min(decode(testResult,1,(select min(times) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, times, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 ErrCount,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
           ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 RightCount ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

    elsif (c_testCode=638 or c_testCode=639 or c_testCode=640 or c_testCode=641  or c_testCode=642  or c_testCode=643 or c_testCode=644 or c_testCode=645  or c_testCode=647 or c_testCode=648 or c_testCode=649 or c_testCode=650 or c_testCode=651 or c_testCode=652 or c_testCode=657) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum(decode(testResult, 1, ACTIVATIONTIME, 0)) sumDelay, '--ping时延
          ||' NVL(min(decode(testResult,1,(select min(ACTIVATIONTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ACTIVATIONTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, ACTIVATIONTIME, 0)) MaxDelay, '

          ||' sum(decode(testResult, 1, DEACTIVATIONTIME, 0)) RSumDelay, '--平均成功率
          ||' NVL(min(decode(testResult,1,(select min(DEACTIVATIONTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEACTIVATIONTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, DEACTIVATIONTIME, 0)) RMaxDelay, '

          ||' sum(decode(testResult, 1, DETACHTIME, 0)) sumDetachTime, '
          ||' NVL(min(decode(testResult,1,(select min(DETACHTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DETACHTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(testResult, 1, DETACHTIME, 0)) maxDetachTime, '
          
          ||' sum(decode(testResult, 1, ATTACHTIME, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(ATTACHTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ATTACHTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(testResult, 1, ATTACHTIME, 0)) maxAttachTime, '
          
          ||' sum(decode(testResult, 1, SECONDRESPONSETIME, 0)) sumOperateTime, '
          ||' NVL(min(decode(testResult,1,(select min(SECONDRESPONSETIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.SECONDRESPONSETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(testResult, 1, SECONDRESPONSETIME, 0)) maxOperateTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 ErrCount,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 RightCount ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount , 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';


    elsif (c_testCode=653 or c_testCode=654 or c_testCode=655 or c_testCode=656) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum(decode(testResult, 1, ATTACHTIME, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(ATTACHTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ATTACHTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(testResult, 1, ATTACHTIME, 0)) maxAttachTime, '
          
          ||' sum(decode(SENDPACKET, 2, 1, 0)) NoiseCount, '
         
         ||' 0 sumDelay ,0 MaxDelay ,0 MinDelay ,0 RSumDelay ,0 RMaxDelay ,0 RMinDelay ,0 ShortCRCount, 0 NonBeginCRCount ,' 
         ||' 0 sumDetachTime ,0 maxDetachTime ,0  minDetachTime ,0 sumOperateTime ,0 maxOperateTime ,0 minOperateTime,'
         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

           
           
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 ErrCount,'
          --||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 RightCount ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount';
   elsif (c_testCode=646) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum(decode(testResult, 1, ACTIVATIONTIME, 0)) sumDelay, '--ping时延
          ||' NVL(min(decode(testResult,1,(select min(ACTIVATIONTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.ACTIVATIONTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, ACTIVATIONTIME, 0)) MaxDelay, '

          ||' sum(decode(testResult, 1, DEACTIVATIONTIME, 0)) RSumDelay, '--平均成功率
          ||' NVL(min(decode(testResult,1,(select min(DEACTIVATIONTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.DEACTIVATIONTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, DEACTIVATIONTIME, 0)) RMaxDelay, '

          ||' sum(decode(testResult, 1, DETACHTIME, 0)) sumDetachTime, '
          ||' NVL(min(decode(testResult,1,(select min(DETACHTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.DETACHTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(testResult, 1, DETACHTIME, 0)) maxDetachTime, '
          
          ||' sum(decode(testResult, 1, ATTACHTIME, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(ATTACHTIME) from z_testresult zt where zt.taskid=t2.taskid and zt.ATTACHTIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(testResult, 1, ATTACHTIME, 0)) maxAttachTime, '
          
          ||' sum(decode(testResult, 1, SECONDRESPONSETIME, 0)) sumOperateTime, '
          ||' NVL(min(decode(testResult,1,(select min(SECONDRESPONSETIME) from z_testresult zt where zt.taskid=t2.taskid and zt.SECONDRESPONSETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(testResult, 1, SECONDRESPONSETIME, 0)) maxOperateTime, '

           ||' sum(decode(SENDPACKET, 2, 1, 0)) NoiseCount, '
           ||' sum(decode(LOSTPACKETRATE, 2, 1, 0)) ShortCRCount, '
           ||' sum(decode(RECVPACKET, 2, 1, 0)) NonBeginCRCount, '
           
            ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '
           
           
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 ErrCount,'
          --||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, 0 RightCount ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount';

      elsif (c_testCode=1651 or c_testCode=1652 or c_testCode=1653 or c_testCode=1654 or c_testCode=1655 or c_testCode=1656) then
          tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, BreakLine, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, operateTime, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, operateTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, operateTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 ErrCount, 0 RightCount,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

           ||' 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
        --  ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 AcrossCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';

     elsif (c_testCode=901 or c_testCode=520 or c_testCode=521 or c_testCode=1129 or c_testCode=1230) then --附着测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, AttachTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine,0 FailureCount, 0 maxBreakLine, 0 SilCount, 0 NoiseCount, 0 ShortCRCount, 0 NonBeginCRCount';
     elsif (c_testCode=903 or c_testCode=933 or c_testCode=949 or c_testCode=522 or c_testCode=1130  or c_testCode=1181  or c_testCode=1500 or c_testCode=1275) then --激活测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 1, ActivationTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, ActivationTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) MaxDelay, '

          ||' sum(decode(callResult, 1, AttachTime, 0)) sumBreakLine, '
          ||' NVL(min(decode(callResult, 1, AttachTime, null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxBreakLine, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '



          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount,0 RSumDelay ,0 RMinDelay,0 RMaxDelay,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 SilCount ,0 NoiseCount,0 NonBeginCRCount';

    elsif (c_testCode=1276 or c_testCode=1277 or c_testCode=1278  or c_testCode=1279  or c_testCode=1280  or c_testCode=1281  or c_testCode=1282) then

          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, operateTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, operateTime, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, operateTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumBreakLine , 0 minBreakLine , 0 maxBreakLine ,0 NotSPCount ,'
          ||' 0 RSumDelay , 0 RMinDelay , 0 RMaxDelay ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate';

      elsif (c_testCode=1283 or c_testCode=1285) then

          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(testResult, 1, ResponseDelay, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, ResponseDelay, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, ResponseDelay, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumBreakLine , 0 minBreakLine , 0 maxBreakLine ,0 NotSPCount ,'
          ||' 0 RSumDelay , 0 RMinDelay , 0 RMaxDelay ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate';
          
     elsif (c_testCode=1284 or c_testCode=1286 or c_testCode=1287 or c_testCode=1288) then

          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(testResult, 1, times, 0)) sumDelay, '
          ||' NVL(min(decode(testResult, 1, times, null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, times, 0)) MaxDelay, '
           ||' sum(decode(testResult, 1, dnstime, 0)) RSumDelay, '
          ||' NVL(min(decode(testResult, 1, dnstime, null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, dnstime, 0)) RMaxDelay, '
          
         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumBreakLine , 0 minBreakLine , 0 maxBreakLine ,0 NotSPCount ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate';

   elsif (c_testCode=1780 or c_testCode=1781 or c_testCode=1782 or c_testCode=1783 or c_testCode=1784 or c_testCode=1785 or c_testCode=1786 or c_testCode=1787 or c_testCode=1788 or c_testCode=1789 or c_testCode=1790) then

          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(callResult, 1, OperateTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OperateTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '
          
         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumBreakLine , 0 minBreakLine , 0 maxBreakLine ,0 NotSPCount ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 RSumDelay , 0 RMaxDelay , 0 RMinDelay ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 MonoDirectionCount, 0 BreakLineCount, 0 AcrossCount, 0 NoiseCount, '
          ||' 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, 0 SilCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate';

    elsif (c_testCode=910 or c_testCode=909 or c_testCode=908 or c_testCode=1131  or c_testCode=1182  or c_testCode=1501 or c_testCode=1400 or c_testCode=1600) then --GPRS-VPN业务测试

          tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --ping失败
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, activationTime, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, activationTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, activationTime, 0)) RMaxDelay, '

          ||' sum(decode(callResult, 1, AttachTime, 0)) sumBreakLine, '
          ||' NVL(min(decode(callResult, 1, AttachTime, null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxBreakLine, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 NoiseCount, 0 NonBeginCRCount';


    elsif (c_testCode=923 or c_testCode=935 or c_testCode=951 or c_testCode=975 or c_testCode=928 or c_testCode=940 or c_testCode=956 or c_testCode=1010 or c_testCode=1034 or c_testCode=1037 or c_testCode=1011 or c_testCode=1035 or c_testCode=1038 or c_testCode=1010 or c_testCode=1034 or c_testCode=1037 or c_testCode=1011 or c_testCode=1035 or c_testCode=1038 or c_testCode=1022 or c_testCode=1023 or c_testCode=1024 or c_testCode=1028 or c_testCode=1029 or c_testCode=1030 or c_testCode=1085 or c_testCode=1086 or c_testCode=1087 or c_testCode=1133  or c_testCode=1184  or c_testCode=1402  or c_testCode=1602 or c_testCode=1138  or c_testCode=1189   or c_testCode=1508 or c_testCode=1407 or c_testCode=1607 or c_testCode=1153 or c_testCode=1203  or c_testCode=1522  or c_testCode=1421  or c_testCode=1621 or c_testCode=1157 or c_testCode=1207  or c_testCode=1526  or c_testCode=1425  or c_testCode=1625 or c_testCode=1159 or c_testCode=1209  or c_testCode=1528  or c_testCode=1427   or c_testCode=1627 or c_testCode=1160 or c_testCode=1210   or c_testCode=1529 or c_testCode=1428  or c_testCode=1628 or c_testCode=1168  or c_testCode=1218   or c_testCode=1537 or c_testCode=1436  or c_testCode=1636  or c_testCode=1716) then --PCU/RNC-彩信收发业务测试 --PCU/RNC-手机邮箱业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) BreakLineCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 7, 1, 0)) SilCount, '  --发送失败
          ||' sum(decode(callResult, 12, 1, 0)) NoiseCount, '  --短信通知失败
          ||' sum(decode(callResult, 8, 1, 0)) NonBeginCRCount, '  --短信接收失败
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumBreakLine, '--发
          ||' NVL(min(decode(callResult,1, BreakLine, null)), 0) minBreakLine, '--发
          ||' max(decode(callResult, 1, BreakLine, 0)) maxBreakLine, '--发
          ||' sum(decode(callResult, 1, sendpacket, 0)) sumDelay, ' --push
          ||' NVL(min(decode(callResult, 1, sendpacket, null)), 0) MinDelay, '--push
          ||' max(decode(callResult, 1, sendpacket, 0)) MaxDelay, '--push
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '--收
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '--收
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '--收
          ||' sum(decode(callResult, 1, maxDelay, 0)) sumErrPacketRate, '--全
          ||' NVL(min(decode(callResult, 1, maxDelay, null)), 0) minErrPacketRate, '--全
          ||' max(decode(callResult, 1, maxDelay, 0)) maxErrPacketRate, '--全
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


           ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount,'
          ||' 0 FailureCount';

      elsif (c_testCode=1019 or c_testCode=1020 or c_testCode=1156 or c_testCode=1206  or c_testCode=1525  or c_testCode=1424  or c_testCode=1624 or c_testCode=1237 or c_testCode=1238 or c_testCode=1239   or c_testCode=1550  or c_testCode=1449  or c_testCode=1649 or c_testCode=1240 or c_testCode=1241 or c_testCode=1242 or c_testCode=1243   or c_testCode=1551  or c_testCode=1450  or c_testCode=1650 or c_testCode=1244 or c_testCode=1245 or c_testCode=1246 or c_testCode=1247 or c_testCode=1248) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --ping浏览失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '
          ||' sum(decode(callResult, 13, 1, 0)) NotSPCount, '  --dns解析失败
          ||' sum(decode(callResult, 1, (toSPDELAY-sptodelay), 0)) MonoDirectionCount, '---响应时延
          ||' sum((case when toSPDELAY-sptodelay>0  then 1 else 0 end)) ErrCount, '
          ||' sum(decode(callResult, 1,dnstime, 0)) BreakLineCount, '---dns解析时延
          ||' sum(decode(callResult, 1,Sockettimeall, 0)) RightCount, '---SOCKET连接时延
          ||' sum(decode(callResult, 1,Receivetime, 0)) NoiseCount, ' ---数据接收时延
          ||' sum(decode(callResult, 1,Times, 0)) NonBeginCRCount, ' --平均速度大于60KB/S次数

          ||' sum(decode(callResult, 1,SocketTime, 0)) FailureCount, '---页面显示时长
          ||' sum(decode(callResult, 1, callerValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult,1,(select min(callerValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.callerValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
        -- ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) RMaxDelay, '
          ------------------------------------
          ||' sum(decode(callResult, 1, ActivationTime, 0)) sumActivationTime, '
          ||' NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxActivationTime, '
          
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxDeActivationTime, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' sum(decode(callResult, 1, DetachTime, 0)) sumDetachTime, '
          ||' NVL(min(decode(testResult,1,(select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, DetachTime, 0)) maxDetachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';



      elsif (c_testCode=1091 or c_testCode=1092 or c_testCode=1093 or c_testCode=1094 or c_testCode=921 or c_testCode=934 or c_testCode=950  or c_testCode=944 or c_testCode=947 or c_testCode=961 or c_testCode=930 or c_testCode=942 or c_testCode=958 or c_testCode=965 or c_testCode=967 or c_testCode=971 or c_testCode=979 or c_testCode=980 or c_testCode=981 or c_testCode=1001  or c_testCode=1004  or c_testCode=1007  or c_testCode=1016  or c_testCode=1013  or c_testCode=1040  or c_testCode=1025  or c_testCode=1002  or c_testCode=1005   or c_testCode=1014  or c_testCode=1017  or c_testCode=1041  or c_testCode=1008  or c_testCode=1026  or c_testCode=1006  or c_testCode=1018  or c_testCode=1042  or c_testCode=1009  or c_testCode=1027   or c_testCode=1044 or c_testCode=1043 or c_testCode=1050 or c_testCode=1051 or c_testCode=1060 or c_testCode=1063 or c_testCode=1066 or c_testCode=1069 or c_testCode=1072  or c_testCode=1075 or c_testCode=1076 or c_testCode=1059 or c_testCode=1062 or c_testCode=1065 or c_testCode=1068 or c_testCode=1071  or c_testCode=1074 or c_testCode=1058 or c_testCode=1061 or c_testCode=1064 or c_testCode=1067 or c_testCode=1070  or c_testCode=1073 or c_testCode=523 or c_testCode=524 or c_testCode=525 or c_testCode=526 or c_testCode=1103 or c_testCode=1104 or c_testCode=1105 or c_testCode=1106 or c_testCode=1123 or c_testCode=1124 or c_testCode=1132  or c_testCode=1183  or c_testCode=1502 or c_testCode=1401   or c_testCode=1601 or c_testCode=1140  or c_testCode=1191   or c_testCode=1510 or c_testCode=1409 or c_testCode=1609 or c_testCode=1143  or c_testCode=1193  or c_testCode=1512 or c_testCode=1411 or c_testCode=1611 or c_testCode=1148  or c_testCode=1198  or c_testCode=1517  or c_testCode=1416 or c_testCode=1616 or c_testCode=1150  or c_testCode=1200  or c_testCode=1519   or c_testCode=1418  or c_testCode=1618 or c_testCode=1152 or c_testCode=1202  or c_testCode=1521  or c_testCode=1420  or c_testCode=1620 or c_testCode=1154 or c_testCode=1204  or c_testCode=1523  or c_testCode=1422  or c_testCode=1622 or c_testCode=1155 or c_testCode=1205  or c_testCode=1524  or c_testCode=1423  or c_testCode=1623 or c_testCode=1161  or c_testCode=1211   or c_testCode=1530 or c_testCode=1429  or c_testCode=1629  or c_testCode=1162  or c_testCode=1212   or c_testCode=1531 or c_testCode=1430  or c_testCode=1630 or c_testCode=1163  or c_testCode=1213     or c_testCode=1532 or c_testCode=1431  or c_testCode=1631 or c_testCode=1164  or c_testCode=1214    or c_testCode=1533 or c_testCode=1432  or c_testCode=1632 or c_testCode=1165  or c_testCode=1215   or c_testCode=1534 or c_testCode=1433  or c_testCode=1633 or c_testCode=1170  or c_testCode=1220    or c_testCode=1539 or c_testCode=1438  or c_testCode=1638 or c_testCode=1173 or c_testCode=1223   or c_testCode=1542  or c_testCode=1441  or c_testCode=1641 or c_testCode=1178 or c_testCode=1228   or c_testCode=1547  or c_testCode=1446  or c_testCode=1646) then --PCU/RNC-Ping业务测试--PCU/RNC-SOCKET业务测试--PCU/RNC-HTTP浏览业务测试
           --PCU/RNC-WAP浏览业务测试--PCU/RNC-手机地图业务测试 --PCU/RNC-手机阅读业务测试
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --ping浏览失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
       --   ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '


          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine, 0 NoiseCount, 0 NonBeginCRCount';

    elsif (c_testCode=925 or c_testCode=937 or c_testCode=953 or c_testCode=1135  or c_testCode=1186  or c_testCode=1505 or c_testCode=1404 or c_testCode=1604) then --ping
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '--失败次数
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --ping浏览失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) RSumDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount,  0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine, 0 NoiseCount, 0 NonBeginCRCount';

  elsif (c_testCode=1110 or c_testCode=1111 or c_testCode=1112 or c_testCode=1113 or c_testCode=1114 or c_testCode=1115 or c_testCode=1116  or c_testCode=1174 or c_testCode=1224   or c_testCode=1543  or c_testCode=1442  or c_testCode=1642 or c_testCode=1175 or c_testCode=1225   or c_testCode=1544  or c_testCode=1443  or c_testCode=1643) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --浏览解析失败
          ||' sum(decode(callResult, 13, 1, 0)) NotSPCount, '  --dns解析失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '

          ||' sum(decode(callResult, 1, (toSPDELAY-sptodelay), 0)) MonoDirectionCount, '---响应时延
          ||' sum(decode(callResult, 1,dnstime, 0)) BreakLineCount, '---dns解析时延
          ||' sum(decode(callResult, 1,Sockettimeall, 0)) RightCount, '---SOCKET连接时延
          ||' sum(decode(callResult, 1,Receivetime, 0)) NoiseCount, ' ---数据接收时延
          ||' sum(decode(callResult, 1,Times, 0)) NonBeginCRCount, ' --平均速度大于60KB/S次数
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

    elsif (c_testCode=1117 or c_testCode=1118 or c_testCode=1119  or c_testCode=1176 or c_testCode=1226   or c_testCode=1545  or c_testCode=1444  or c_testCode=1644) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --ping浏览失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '

          ||' sum(decode(callResult, 1, (toSPDELAY-sptodelay), 0)) MonoDirectionCount, '                        --响应时延
          ||' sum(decode(callResult, 1, (DATERECEIVEDELAY), 0)) BreakLineCount, '     --数据接收时延
          ||' sum(decode(callResult, 1, times, 0)) RightCount, ' --平均速度大于60KB/S次数
          ||' sum(decode(callResult, 1, (SPTODELAY), 0)) NoiseCount, ' --模拟端到Sp时延
          ||' sum(decode(callResult, 1, (TOSPDELAY), 0)) NonBeginCRCount, ' --SP到模拟端时延
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 NotSPCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine';

       elsif (c_testCode=1120 or c_testCode=1121 or c_testCode=1122  or c_testCode=1177 or c_testCode=1227   or c_testCode=1546  or c_testCode=1445  or c_testCode=1645) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --浏览失败
          ||' sum(decode(callResult, 13, 1, 0)) NotSPCount, '  --dns浏览失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OPERATETIME, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, callervalue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, callervalue, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, callervalue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, (toSPDELAY-sptodelay), 0)) MonoDirectionCount, '                        --响应时延
          ||' sum(decode(callResult, 1, (DNSTIME), 0)) BreakLineCount, '     --dns时延
          ||' sum(decode(callResult, 1, SOCKETTIMEALL, 0)) RightCount, ' --SOCKET时延
          ||' sum(decode(callResult, 1, (Receivetime), 0)) NoiseCount, ' ---数据接收时延
          ||' sum(decode(callResult, 1, (times), 0)) NonBeginCRCount, ' --平均速度大于60KB/S次数

          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, '
          ||' 0 RSuccessCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine';


      elsif(c_testCode=924 or c_testCode=936 or c_testCode=952 or c_testCode=976 or c_testCode=1134  or c_testCode=1185   or c_testCode=1504 or c_testCode=1403  or c_testCode=1603 or c_testCode=1254 or c_testCode=1255 or c_testCode=1256 or c_testCode=1257 or c_testCode=1258 or c_testCode=1259 or c_testCode=1260 or c_testCode=1261 or c_testCode=1262 or c_testCode=1268 or c_testCode=1269 or c_testCode=1270 or c_testCode=1274 or c_testCode=1700 or c_testCode=1701) then

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --ping浏览失败
          ||' sum(decode(callResult, 13, 1, 0)) NotSPCount, '  --dns失败
          ||' sum(decode(callResult, 1, callerValue, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, OperateTime, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, OperateTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '

          ||' sum(decode(callResult, 1, (toSPDELAY-sptodelay), 0)) MonoDirectionCount, '                        --响应时延
          ||' sum(decode(callResult, 1, (DNSTIME), 0)) BreakLineCount, '     --dns时延
          ||' sum(decode(callResult, 1, SOCKETTIMEALL, 0)) RightCount, ' --SOCKET时延
          ||' sum(decode(callResult, 1, (Receivetime), 0)) NoiseCount, ' ---数据接收时延
          ||' sum(decode(callResult, 1, (times), 0)) NonBeginCRCount, ' --平均速度大于60KB/S次数
          
          
          ||' sum(decode(callResult, 1, ActivationTime, 0)) sumActivationTime, '
          ||' NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxActivationTime, '
          
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxDeActivationTime, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' sum(decode(callResult, 1, DetachTime, 0)) sumDetachTime, '
          ||' NVL(min(decode(testResult,1,(select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, DetachTime, 0)) maxDetachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 ErrCount,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine';

    elsif (c_testCode=1271 or c_testCode=1399 ) then --MME激活
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, ActivationTime, 0)) sumDelay, '--附着
          ||' NVL(min(decode(callResult, 1, ActivationTime, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '--承载建立时延
          ||' NVL(min(decode(callResult, 1, AttachTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumBreakLine, '--去附着
          ||' NVL(min(decode(callResult, 1, DeActivationTime, null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxBreakLine, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 AcrossCount , 0 ShortCRCount , 0 SilCount ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 NoiseCount, 0 NonBeginCRCount';

     elsif (c_testCode=926 or c_testCode=938 or c_testCode=954 or c_testCode=927 or c_testCode=939 or c_testCode=955 or c_testCode=982 or c_testCode=983 or c_testCode=984 or c_testCode=1082 or c_testCode=1083 or c_testCode=1084  or c_testCode=1099 or c_testCode=1100 or c_testCode=1101 or c_testCode=1136   or c_testCode=1187  or c_testCode=1506 or c_testCode=1405 or c_testCode=1605 or c_testCode=1137  or c_testCode=1188  or c_testCode=1507 or c_testCode=1406  or c_testCode=1606 or c_testCode=1151 or c_testCode=1201   or c_testCode=1520  or c_testCode=1419  or c_testCode=1619 or c_testCode=1167  or c_testCode=1217    or c_testCode=1536 or c_testCode=1435  or c_testCode=1635 or c_testCode=1172 or c_testCode=1222   or c_testCode=1541  or c_testCode=1440  or c_testCode=1640 or c_testCode=1232 or c_testCode=1233   or c_testCode=1549  or c_testCode=1448  or c_testCode=1648 or c_testCode=1234 or c_testCode=1235 or c_testCode=1236  or c_testCode=1657  or c_testCode=1658) then --PCU/RNC-KJAVA下载业务测试--PCU/RNC-FTP下载业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --下载失败
          
          ||' sum((case when avgDelay>0  then  decode(callResult, 17, 0, 1) else 0 end)) NotSPCount, '
          
          ||' sum(decode(callResult, 1, callerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine, 0 NoiseCount, 0 NonBeginCRCount';

   elsif (c_testCode=1791 or c_testCode=1792 or c_testCode=1793 or c_testCode=1794 ) then 

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '      
          ||' sum((case when avgDelay>0  then  decode(callResult, 17, 0, 1) else 0 end)) NotSPCount, '
          
          ||' sum(decode(callResult, 1, callerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, operateTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(operateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.operateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, operateTime, 0)) maxAttachTime, '
          
             ||' sum(decode(callResult, 1, BreakLine, 0)) sumBreakLine, '
          ||' NVL(min(decode(testResult,1,(select min(BreakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, BreakLine, 0)) maxBreakLine, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,0 AcrossCount, 0 ShortCRCount ,0 SilCount ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate , '
          ||'  0 NoiseCount, 0 NonBeginCRCount';
          
          
      elsif (c_testCode=1795) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          
          ||' sum(decode(callResult, 1, dnstime, 0)) sumAttachTime, '
          ||' NVL(min(decode(callResult,1, (select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, dnstime, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, t1.duration, 0)) sumDetachTime, '
          ||' NVL(min(decode(callResult,1, (select min(t1.duration) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DURATION>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, t1.duration, 0)) maxDetachTime, '
          
          ||' sum(decode(callResult, 1, Sockettimeall, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(Sockettimeall) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1   and zt.Sockettimeall>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, Sockettimeall, 0)) maxDeActivationTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumActivationTime , 0 minActivationTime , 0 maxActivationTime , '
          ||' 0 sumDelay , 0 MinDelay , 0 MaxDelay , '
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , 0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
   elsif (c_testCode=1096 or c_testCode=1097 or c_testCode=1098  or c_testCode=1171 or c_testCode=1221   or c_testCode=1540  or c_testCode=1439  or c_testCode=1639) then --PCU/RNC-KJAVA下载业务测试--PCU/RNC-FTP下载业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --下载失败
          ||' sum(decode(callResult, 1, callerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, OperateTime, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, OperateTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) RMaxDelay, '

          ||' sum(decode(callResult, 1, TospDelay, 0)) MonoDirectionCount, '--响应时延
          ||' sum(decode(callResult, 1, dnstime, 0)) BreakLineCount, '--响应时延
          ||' sum(decode(callResult, 1, sockettimeall, 0)) RightCount, '--socket时延
          ||' sum(decode(callResult, 1, receivetime, 0)) NoiseCount, '--数据接收时延
          ||' sum(decode(callResult, 1, Times, 0)) NonBeginCRCount, '--平均速度大于60KB/S次数
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          

          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount,0 NotSPCount,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine';

 elsif (c_testCode=1125 or c_testCode=1126 or c_testCode=1127  or c_testCode=1179 or c_testCode=1229   or c_testCode=1548  or c_testCode=1447  or c_testCode=1647 
         or c_testCode=1702 or c_testCode=1703  or c_testCode=1704  or c_testCode=1705  or c_testCode=1706  or c_testCode=1707  or c_testCode=1708) then --PCU/RNC-ping业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --下载失败
          ||' sum(decode(callResult, 1, callerValue, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, callerValue, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, callerValue, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, OperateTime, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, OperateTime, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) RMaxDelay, '

          ||' sum(decode(callResult, 1, TospDelay, 0)) MonoDirectionCount, '--响应时延
          ||' sum(decode(callResult, 1, dnstime, 0)) BreakLineCount, '--抖动
          ||' sum(decode(callResult, 1, sockettimeall, 0)) RightCount, '--成功次数
          ||' sum(decode(callResult, 1, receivetime, 0)) NoiseCount, '--数据接收时延
          ||' sum(decode(callResult, 1, Times, 0)) NonBeginCRCount, '--丢包率
          ||' sum(decode(callResult, 1, RECEIVETIME, 0)) ErrCount, '
          ||' sum(decode(callResult, 1, SOCKETTIMEALL, 0)) NotSPCount, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
        --  ||' 0 ErrCount,0 NotSPCount,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
        --  ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate,0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine';
  elsif ( c_testCode=929 or c_testCode=941 or c_testCode=957 or c_testCode=1139  or c_testCode=1190   or c_testCode=1509 or c_testCode=1408 or c_testCode=1608) then --PCU/RNC-飞信业务业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 7, 1, 0)) SilCount, '  --发送失败
          ||' sum(decode(callResult, 8, 1, 0)) NonBeginCRCount, '  --短信接收失败
          ||' sum(decode(callResult, 1, responseDelay, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseDelay, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseDelay, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, sockettimeall, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, sockettimeall, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, sockettimeall, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumErrPacketRate , 0 minErrPacketRate , 0 maxErrPacketRate ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';
      elsif ( c_testCode=1031 or c_testCode=1032 or c_testCode=1033  or c_testCode=1158 or c_testCode=1208   or c_testCode=1527 or c_testCode=1426  or c_testCode=1626) then --PCU/RNC-飞信业务业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 7, 1, 0)) SilCount, '  --发送失败
          ||' sum(decode(callResult, 12, 1, 0)) NonBeginCRCount, '  --短信接收失败
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, BreakLine, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '
          ||' sum(decode(callResult, 1, maxDelay, 0)) sumErrPacketRate, '
          ||' NVL(min(decode(callResult, 1, maxDelay, null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, maxDelay, 0)) maxErrPacketRate, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';

     elsif ( c_testCode=945 or c_testCode=946 or c_testCode=960 or c_testCode=977 or c_testCode=1144  or c_testCode=1194  or c_testCode=1513  or c_testCode=1412 or c_testCode=1612) then --PCU/RNC-QQ

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 7, 1, 0)) SilCount, '  --发送失败接收失败
          ||' sum(decode(callResult, 8, 1, 0)) NonBeginCRCount, '  --
          ||' sum(decode(callResult, 1, responseDelay, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, responseDelay, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseDelay, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, sockettimeall, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, sockettimeall, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, sockettimeall, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          ||' 0 sumErrPacketRate , 0 maxErrPacketRate , 0 minErrPacketRate ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';


    elsif (c_testCode=931 or c_testCode=943 or c_testCode=959 or c_testCode=978 or c_testCode=1079 or c_testCode=1080 or c_testCode=1081 or c_testCode=1088 or c_testCode=1089 or c_testCode=1090 or c_testCode=1142  or c_testCode=1192  or c_testCode=1511 or c_testCode=1410 or c_testCode=1610 or c_testCode=1166  or c_testCode=1216   or c_testCode=1535 or c_testCode=1434  or c_testCode=1634 or c_testCode=1263  or c_testCode=1264  or c_testCode=1265  or c_testCode=1266  or c_testCode=1267) then --PCU/RNC-号码管家业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 10, 1, 0)) SilCount, '  --初始化失败
          ||' sum(decode(callResult, 6, 1, 0)) NonBeginCRCount, '  --同步失败
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1, BreakLine, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate,0 minErrPacketRate,0 maxErrPacketRate, '
          ||' 0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';

    elsif (c_testCode=1052 or c_testCode=1053 or c_testCode=1054  or c_testCode=1055) then

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 6, 1, 0)) SilCount, '  --浏览首页失败
          ||' sum(decode(callResult, 10, 1, 0)) NonBeginCRCount, '  --登录失败
          ||' sum(decode(callResult, 11, 1, 0)) MonoDirectionCount, '  --信息录入失败
          ||' sum(decode(callResult, 1, maxDelay, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1, maxDelay, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, maxDelay, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate,0 minErrPacketRate,0 maxErrPacketRate, '
          ||' 0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';

     elsif (c_testCode=962 or c_testCode=968 or c_testCode=972  or c_testCode=1195  or c_testCode=1514 or c_testCode=1413 or c_testCode=1613 or c_testCode=963 or c_testCode=969 or c_testCode=973 or c_testCode=1196  or c_testCode=1515 or c_testCode=1414 or c_testCode=1614 or c_testCode=964 or c_testCode=970 or c_testCode=974 or c_testCode=1146  or c_testCode=1196 or c_testCode=1147  or c_testCode=1197  or c_testCode=1516  or c_testCode=1415 or c_testCode=1615) then --PCU/RNC-手机证券业务测试--PCU/RNC-手机应用商场业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 10, 1, 0)) SilCount, '  --登陆失败下载失败
          ||' sum(decode(callResult, 6, 1, 0)) NonBeginCRCount, '  --
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1, BreakLine, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
        --  ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate ,0 minErrPacketRate,0 maxErrPacketRate,'
          ||' 0 FailureCount,0 NoiseCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine';
      elsif (c_testCode=966 or c_testCode=1149  or c_testCode=1199  or c_testCode=1518  or c_testCode=1417  or c_testCode=1617) then --PCU/RNC-手机报业务测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 12, 1, 0)) SilCount, '  --接收短信失败
          ||' sum(decode(callResult, 8, 1, 0)) NonBeginCRCount, '  --接收失败
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1, BreakLine, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
        --  ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate ,0 minErrPacketRate,0 maxErrPacketRate,'
          ||' 0 FailureCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';
      elsif (c_testCode=1056  or c_testCode=1057 or c_testCode=1169  or c_testCode=1219   or c_testCode=1538 or c_testCode=1437  or c_testCode=1637) then --校讯通平台测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 7, 1, 0)) SilCount, '  --请求发送短信失败
          ||' sum(decode(callResult, 8, 1, 0)) NonBeginCRCount, '  --接收短信失败
          ||' sum(decode(callResult, 10, 1, 0)) MonoDirectionCount, '  --登陆失败
          ||' sum(decode(callResult, 1, maxDelay, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1, maxDelay, null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, maxDelay, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, avgDelay, 0)) RSumDelay, '
          ||' NVL(min(decode(callResult, 1, avgDelay, null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgDelay, 0)) RMaxDelay, '
          
          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0)) maxAttachTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
         -- ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate,0 minErrPacketRate,0 maxErrPacketRate, '
          ||' 0 FailureCount, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';
       elsif ( c_testCode=1077 or c_testCode=1078 or c_testCode=1102 or c_testCode=1128 or c_testCode=1272 or c_testCode=1273) then --校讯通平台测试

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) AcrossCount, '  --Attach失败
          ||' sum(decode(callResult, 4, 1, 0)) ShortCRCount, '  --Activation失败
          ||' sum(decode(callResult, 7, 1, 0)) SilCount, '  --请求发送短信失败
          ||' sum(decode(callResult, 8, 1, 0)) NonBeginCRCount, '  --接收短信失败
          ||' sum(decode(callResult, 10, 1, 0)) MonoDirectionCount, '  --登陆失败
          ||' sum(decode(callResult, 1, OPERATETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult,1, OPERATETIME, 0)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OPERATETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

       
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 BreakLineCount, '
          ||' 0 sumErrPacketRate,0 minErrPacketRate,0 maxErrPacketRate, '
          ||' 0 FailureCount, 0 RSumDelay, 0 RMinDelay ,0 RMaxDelay, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine,0 NoiseCount';
     elsif (c_testCode=725 or c_testCode=724  or c_testCode=751 or c_testCode=752 or c_testCode=2011 or c_testCode=462 or c_testCode=463 or c_testCode=464 or c_testCode=465 or c_testCode=466 or c_testCode=467  or c_testCode=468  or c_testCode=472 or c_testCode=475 or c_testCode=750 or c_testCode=2001 or c_testCode=2003 or c_testCode=2005 or c_testCode=2006 or c_testCode=2007 or c_testCode=2008 or c_testCode=2009 or c_testCode=2010 or c_testCode=2101   or c_testCode=2103  or c_testCode=2105  or c_testCode=2107 or c_testCode=2108 or c_testCode=2109 or c_testCode=2110 or c_testCode=2111 or c_testCode=2112 or c_testCode=785 or c_testCode=786 or c_testCode=787 or c_testCode=788) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(RESPONSETIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.RESPONSETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
         -- ||' NVL(min(decode(testResult,1, RESPONSETIME, 0)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
   elsif (c_testCode=470) then
     tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, RESPONSETIME, 0)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

    elsif (c_testCode=469) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 3, 1, 0)) FailureCount, '---充值失败
          ||' sum(decode(callResult, 4, 1, 0)) SilCount, '---冲正失败
          ||' sum(decode(testResult, 1, BreakLine, 0)) RSumDelay, '--充值时延
          ||' NVL(min(decode(testResult,1, BreakLine, 0)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, BreakLine, 0)) RMaxDelay, '
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) sumDelay, '--冲正时延
          ||' NVL(min(decode(testResult,1, RESPONSETIME, 0)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount , '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

    elsif (c_testCode=471) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, 1, 0)) SilCount, '---接通成功
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, RESPONSETIME, 0)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

   elsif (c_testCode=473) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1,1, decode(TALKSTATUS, 4, 1, 0))) RSuccessCount, '
          ||' sum(decode(TALKSTATUS, 3, 1, 0)) FailureCount, '
          ||' sum(decode(TALKSTATUS, 4, 1, 0)) SilCount, '
          --||' sum(decode(testResult, 1, BreakLine, 0)) RSumDelay, '--订阅时延
          --||' NVL(min(decode(testResult,1, BreakLine, 0)), 0) RMinDelay, '
          --||' max(decode(testResult, 1, BreakLine, 0)) RMaxDelay, '
          ||' sum(decode(testResult,1,BreakLine,decode(TALKSTATUS, 4, BreakLine))) RSumDelay, '
          ||' NVL(min(decode(testResult,1,BreakLine,decode(TALKSTATUS, 4, BreakLine))), 0) RMinDelay, '
          ||' max(decode(testResult,1,BreakLine,decode(TALKSTATUS, 4, BreakLine))) RMaxDelay, '
          ||' sum(decode(testResult, 1, RESPONSETIME)) sumDelay, '--取消时延
          ||' NVL(min(decode(testResult,1, RESPONSETIME)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount , '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
     elsif ( c_testCode=483 or c_testCode=484  or c_testCode=485) then
      /* tmp := ' sum((case when b.codedata=b.cut  then 1 else 0 end)) test_Success_Count_, '
          ||'  sum((case when b.codedata=b.cut  then 1 else 0 end)) SuccessCount, '
          ||' sum((case when b.codedata<>b.cut  then 1 else 0 end)) FailureCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 RSuccessCount , 0 sumDelay , 0 MinDelay , 0 MaxDelay, '
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
         */
         tmp := '';
     elsif ( c_testCode=2002 or c_testCode=2004  or c_testCode=2104 or c_testCode=2106) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, CALLERVALUE, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, CALLERVALUE, 0)), 0) MinDelay, '
          ||' max(decode(testResult, 1, CALLERVALUE, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
     elsif(c_testCode=780 or c_testCode=781 or c_testCode=782 or c_testCode=783) then
          tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, RESPONSETIME, 0)) sumDelay, '
          ||' NVL(min(decode(callResult, 1, (select min(RESPONSETIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.RESPONSETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
         -- ||' NVL(min(decode(testResult,1, RESPONSETIME, 0)), 0) MinDelay, '
          ||' max(decode(callResult, 1, RESPONSETIME, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, CALLERVALUE, 0)) sumErrPacketRate, '
          ||' NVL(min(decode(callResult, 1, (select min(CALLERVALUE) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.CALLERVALUE>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinErrPacketRate, '
          ||' max(decode(callResult, 1, CALLERVALUE, 0)) MaxErrPacketRate, '
          ||' sum(decode(callResult, 1, CALLEDVALUE, 0)) sumBreakLine, '
          ||' NVL(min(decode(callResult, 1, (select min(CALLEDVALUE) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.CALLEDVALUE>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinBreakLine, '
          ||' max(decode(callResult, 1, CALLEDVALUE, 0)) MaxBreakLine, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 MonoDirectionCount, 0 BreakLineCount ';
     elsif (c_testCode=1709 or c_testCode=1710  or c_testCode=1711  or c_testCode=1712  or c_testCode=1713  or c_testCode=1714  or c_testCode=1715) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, operatetime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(operatetime) from z_testresult zt where zt.taskid=t2.taskid and  zt.callResult=1  and zt.operatetime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, operatetime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

     
      elsif (c_testCode=1745) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, attachTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(attachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.attachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, attachTime, 0)) MaxDelay, '
          
          ||' sum(decode(testResult, 1, detachTime, 0)) RSumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(detachTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.detachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, detachTime, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '



          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
          
     elsif (c_testCode=1734 or c_testCode=1735  or c_testCode=1736  or c_testCode=1737  or c_testCode=1738  or c_testCode=1739  or c_testCode=1740) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum((case when attachTime>0  then 1 else 0 end)) AcrossCount,'--附着
          ||' sum((case when detachTime>0  then 1 else 0 end)) NoiseCount,'--去附着
          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount,'--默认承载建立/激活
          ||' sum((case when deActivationTime>0  then 1 else 0 end)) ShortCRCount,'--删除默认承载/去激活
         
          ||' sum(decode(testResult, 1, dnstime, 0)) sunDnsTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(testResult, 1, dnstime, 0)) maxDnsTime, '

          ||' sum(decode(testResult, 1, attachTime, 0)) sumAttachTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(attachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.attachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(testResult, 1, attachTime, 0)) maxAttachTime, '
          
          ||' sum(decode(testResult, 1, detachTime, 0)) sumDetachTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(detachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.detachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(testResult, 1, detachTime, 0)) maxDetachTime, '
          
          ||' sum(decode(testResult, 1, activationTime, 0)) sumActivationTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(testResult, 1, activationTime, 0)) maxActivationTime, '
          
          ||' sum(decode(testResult, 1, deActivationTime, 0)) sumDeActivationTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(deActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.deActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(testResult, 1, deActivationTime, 0)) maxDeActivationTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumDelay , 0 MaxDelay , 0 minDelay ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 ErrCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
          
   
        elsif (c_testCode=1747 or c_testCode=1748 ) then
          
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum(decode(ATTACHRESULT_R, 2, AttachDelay_r, 0)) sumActivationTime, ' 
          ||' NVL(min(decode(ATTACHRESULT_R,2, (select min(AttachDelay_r) from z_testresult zt where zt.taskid=t2.taskid and zt.ATTACHRESULT_R=2 and zt.AttachDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(ATTACHRESULT_R, 2, AttachDelay_r, 0)) maxActivationTime, '
          
          ||' sum(decode(DETTACHRESULT_R, 2, DettachDelay_r, 0)) sumDeActivationTime, ' 
          ||' NVL(min(decode(DETTACHRESULT_R,2, (select min(DettachDelay_r) from z_testresult zt where zt.taskid=t2.taskid and zt.DETTACHRESULT_R=2 and zt.DettachDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(DETTACHRESULT_R, 2, DettachDelay_r, 0)) maxDeActivationTime, '

          ||' sum(decode(VDEFBEAERRESULT_R, 2, VdefbeaerLocalPort_r, 0)) sunDnsTime, ' 
          ||' NVL(min(decode(VDEFBEAERRESULT_R,2, (select min(VdefbeaerLocalPort_r) from z_testresult zt where zt.taskid=t2.taskid and zt.VDEFBEAERRESULT_R=2 and zt.VdefbeaerLocalPort_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(VDEFBEAERRESULT_R, 2, VdefbeaerLocalPort_r, 0)) maxDnsTime, '

          ||' sum(decode(ATTACHRESULT_D, 2, AttachDelay_d, 0)) sumAttachTime, ' 
          ||' NVL(min(decode(ATTACHRESULT_D,2, (select min(AttachDelay_d) from z_testresult zt where zt.taskid=t2.taskid and zt.ATTACHRESULT_D=2 and zt.AttachDelay_d>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(ATTACHRESULT_D, 2, AttachDelay_d, 0)) maxAttachTime, '
          
          ||' sum(decode(DETTACHRESULT_D, 2, DettachDelay_d, 0)) sumDetachTime, ' 
          ||' NVL(min(decode(DETTACHRESULT_D,2, (select min(DettachDelay_d) from z_testresult zt where zt.taskid=t2.taskid and zt.DETTACHRESULT_D=2 and zt.DettachDelay_d>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(DETTACHRESULT_D, 2, DettachDelay_d, 0)) maxDetachTime, '
          
          ||' sum(decode(VDEFBEAERRESULT_D, 2, VdefbeaerLocalPort_d, 0)) RSumDelay, ' 
          ||' NVL(min(decode(VDEFBEAERRESULT_D,2, (select min(VdefbeaerLocalPort_d) from z_testresult zt where zt.taskid=t2.taskid and zt.VDEFBEAERRESULT_D=2 and zt.VdefbeaerLocalPort_d>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(VDEFBEAERRESULT_D, 2, VdefbeaerLocalPort_d, 0)) RMaxDelay, '
          
          
           ||' sum(decode(ATTACHRESULT_R, 2, 1, 0)) AcrossCount, '
           ||' sum(decode(DETTACHRESULT_R, 2, 1, 0)) NoiseCount, '
           ||' sum(decode(VDEFBEAERRESULT_R, 2, 1, 0)) RightCount, '
           ||' sum(decode(ATTACHRESULT_D, 2, 1, 0)) ShortCRCount, '
           ||' sum(decode(DETTACHRESULT_D, 2, 1, 0)) ErrCount, '
           ||' sum(decode(VDEFBEAERRESULT_D, 2, 1, 0)) NonBeginCRCount, '
           
            ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumDelay , 0 MaxDelay , 0 minDelay ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 SilCount, 0 NotSPCount , '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
          
   
     elsif (c_testCode=1750 or c_testCode=1751  or c_testCode=1752  or c_testCode=1753 or c_testCode=1754 or c_testCode=1755  or c_testCode=1756  or c_testCode=1757  or c_testCode=1758  or c_testCode=1759) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
               
          ||' sum(decode(testResult, 1, OperateTime, 0)) sumOperateTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(testResult, 1, OperateTime, 0)) maxOperateTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 sumDelay , 0 MaxDelay , 0 minDelay , 0 AcrossCount , 0 NoiseCount , 0 RightCount , 0 ShortCRCount ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime , '
          ||' 0 ErrCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
          
    elsif (c_testCode=1730 or c_testCode=1731  or c_testCode=1732  or c_testCode=1733  or c_testCode=1741  or c_testCode=1742  or c_testCode=1743 or c_testCode=1744) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          
          ||' sum((case when activationTime>0  then 1 else 0 end)) AcrossCount,'--附着
          ||' sum((case when deActivationTime>0  then 1 else 0 end)) NoiseCount,'--去附着
          ||' sum((case when BreakLine>0  then 1 else 0 end)) RightCount,'--IMS默认承载建立时延
        --  ||' sum((case when deActivationTime>0  then 1 else 0 end)) ShortCRCount,'--删除默认承载/去激活
         
          ||' sum(decode(testResult, 1, ResponseTime, 0)) sunDnsTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(testResult, 1, ResponseTime, 0)) maxDnsTime, '

          ||' sum(decode(testResult, 1, BreakLine, 0)) sumAttachTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(BreakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(testResult, 1, BreakLine, 0)) maxAttachTime, '
          
          ||' sum(decode(testResult, 1, detachTime, 0)) sumDetachTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(detachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.detachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(testResult, 1, detachTime, 0)) maxDetachTime, '
          
          ||' sum(decode(testResult, 1, activationTime, 0)) sumActivationTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(testResult, 1, activationTime, 0)) maxActivationTime, '
          
          ||' sum(decode(testResult, 1, deActivationTime, 0)) sumDeActivationTime, ' 
          ||' NVL(min(decode(testResult,1, (select min(deActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.testresult=1 and zt.deActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(testResult, 1, deActivationTime, 0)) maxDeActivationTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumDelay , 0 MaxDelay , 0 minDelay ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 ErrCount, 0 NonBeginCRCount,0 ShortCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
          

     elsif (c_testCode=1760) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, RECEIVETIME, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(RECEIVETIME) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1 and zt.RECEIVETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RECEIVETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
          
    elsif(c_testCode=3001) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, 1, 0)) BreakLineCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '  ----附着时延
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumDelay, ' --上下文建立时延
          ||' NVL(min(decode(testResult,1,(select min(BreakLine) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '  ----附着时延
          ||' max(decode(callResult, 1, BreakLine, 0)) MaxDelay, '--上下文建立时延
          ||' sum(decode(callResult, 1, deActivationTime, 0)) RSumDelay, '--去附着时延
          ||' NVL(min(decode(testResult,1,(select min(deActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.deActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '  ----附着时延
          ||' max(decode(callResult, 1, deActivationTime, 0)) RMaxDelay, '--去附着时延
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount,'
          ||' 0 AcrossCount,0 ShortCRCount,0 SilCount,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 sumErrPacketRate,0 minErrPacketRate,0 maxErrPacketRate ';
     elsif(c_testCode=3002 or c_testCode=3003 or c_testCode=3004) then
     
       tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, 1, 0)) BreakLineCount, '
          ||' sum(socketTime) ErrCount, '--快速返回时延小于5秒比例
          ||' sum(times) SilCount, '--CSMO呼叫接通率
          ||' sum(decode(times, 1, ResponseTime, 0)) sumErrPacketRate, '--CSMO呼叫接通平均时延
          ||' sum((case when DetachTime>0  then 1 else 0 end)) NotSPCount,'--CSMT回落成功率
          ||' sum((case when DetachTime>0  then DetachTime else 0 end))  RSumDelay, '--CSMT回落平均时延
          ||' sum(dnstime) NoiseCount, '--CSMT呼叫接通率
          ||' sum(decode(dnstime, 1, dateReceiveDelay, 0)) sumDeActivationTime, '--CSMT呼叫接通平均时延
          ||' sum((case when AttachTime>0  then 1 else 0 end)) RightCount,'--CSMO回落成功率
          ||' sum((case when AttachTime>0  then AttachTime else 0 end)) sumDelay, ' --CSMO回落平均时延

          ||' NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, ResponseTime, 0)) maxErrPacketRate, '--主叫振铃时延
          ||' max(decode(callResult, 1, AttachTime, 0)) MaxDelay, '--主叫回落时延
          ||' NVL(min(decode(testResult,1, (select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' sum(decode(callResult, 1, MaxDelay, 0)) sumOperateTime, '--回落后主叫联合附着时延
          ||' NVL(min(decode(testResult,1, (select min(MaxDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.MaxDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, MaxDelay, 0)) maxOperateTime, '--回落后主叫联合附着时延
          ||' sum((case when MaxDelay>0  then 1 else 0 end)) AcrossCount,'--回落后主叫成功次数
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--回落前主叫联合附着时延
          ||' NVL(min(decode(testResult,1, (select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--回落前主叫联合附着时延
          ||' sum((case when ActivationTime>0  then 1 else 0 end)) MonoDirectionCount,'--联合附着主叫成功次数

          ||' NVL(min(decode(testResult,1, (select min(dateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.dateReceiveDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, dateReceiveDelay, 0)) maxDeActivationTime, '--被叫振铃时延
          ||' NVL(min(decode(testResult,1, (select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, DetachTime, 0)) RMaxDelay, '--被叫回落时延
          ||' sum(decode(callResult, 1, MinDelay, 0)) sumReceivetime, '--回落后被叫联合附着时延
          ||' NVL(min(decode(testResult,1, (select min(MinDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.MinDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, MinDelay, 0)) maxReceivetime, '--回落后被叫联合附着时延
          ||' sum((case when MinDelay>0  then 1 else 0 end)) ShortCRCount,'--回落后被叫成功次数
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sunDnsTime, '--回落前附着时延 (被叫)
          ||' NVL(min(decode(testResult,1, (select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxDnsTime, '--回落前附着时延 (被叫)
          ||' sum((case when DeActivationTime>0  then 1 else 0 end)) NonBeginCRCount,'--联合附着主叫成功次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime ' ;

      elsif(c_testCode=3005) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, DateReceiveDelay, 0)) RSumDelay, '--注销时延
          ||' NVL(min(decode(testResult,1,(select min(DateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DateReceiveDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, DateReceiveDelay, 0)) RMaxDelay, '--注销时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, Dnstime, 0)) sunDnsTime, '--LTE安全模式选择时延
          ||' NVL(min(decode(testResult,1,(select min(Dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, Dnstime, 0))  maxDnsTime , '--LTE安全模式选择时延
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumOperateTime, '--LTE上下文建立时延
          ||' NVL(min(decode(testResult,1,(select min(BreakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, BreakLine, 0))  maxOperateTime , '--LTE上下文建立时延
          ||' sum(decode(callResult, 1, AvgDelay, 0)) sumReceivetime, '--LTE上下文释放时延
          ||' NVL(min(decode(testResult,1,(select min(AvgDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AvgDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, AvgDelay, 0))  maxReceivetime , '--LTE上下文释放时延

          ||' sum(decode(callResult, 1, AttachTime, 0)) sumAttachTime, '--鉴权时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, AttachTime, 0))  maxAttachTime , '--鉴权时延


          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount, '---附着成功率 
          ||' sum((case when operateTime>0  then 1 else 0 end)) NotSPCount, '---注册成功率 
          ||' sum((case when  deActivationTime>0  then 1 else 0 end)) NoiseCount, '---去附着成功率 
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
        --  ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 ErrCount, 0 MonoDirectionCount,'
          ||' 0 AcrossCount,0 ShortCRCount,0 SilCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';

                  
      elsif(c_testCode=3006 or  c_testCode=3010 or c_testCode=3011 or c_testCode=3064 or c_testCode=3065 or  c_testCode=3073 or c_testCode=3074) then
        tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --无声音
          ||' sum(decode(testResult, 1, decode(callResult,6,1,0), 0)) ErrCount, ' --噪声
          
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1,(select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate , '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, DateReceiveDelay, 0)) sumAttachTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.DateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DateReceiveDelay>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, DateReceiveDelay, 0)) maxAttachTime , '--IMS注销时延

          ||' sum(decode(callResult, 1, Dnstime, 0)) sumActivationTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.Dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Dnstime>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, Dnstime, 0)) maxActivationTime , '--IMS注销时延
          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ThirdResponseEndTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, DetachTime, 0)) sumOperateTime, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DetachTime, 0))  maxOperateTime , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||' NVL(min(decode(testResult,1,(select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延
          ||' sum(decode(callResult, 1, ToSpDelay, 0)) sumDetachTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.ToSpDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ToSpDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, ToSpDelay, 0))  maxDetachTime , '--IMS注销时延
          
           ||' sum(decode(callResult, 1, Receivetime, 0)) sumDeActivationTime, '--volte时延
          ||' NVL(min(decode(testResult,1,(select min(zt.Receivetime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Receivetime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, Receivetime, 0))  maxDeActivationTime , '--IMS注销时延

          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount, '---附着成功率 
          ||' sum((case when operateTime>0  then 1 else 0 end)) NotSPCount, '---注册成功率 
          ||' sum((case when  deActivationTime>0  then 1 else 0 end)) NoiseCount, '---去附着成功率 
         ||' sum((case when  ResponseDelay>0  then 1 else 0 end)) BreakLineCount, '---VOLTE成功率 
          
        ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '
         -- ||' 0 ErrCount,'
          ||' 0 ShortCRCount ,0 NonBeginCRCount ';
          
          
  

    elsif(c_testCode=3007 or c_testCode=3018 or c_testCode=3021 or c_testCode=3066 or c_testCode=3078) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1,(select min(zt.ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(zt.OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(zt.DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, DateReceiveDelay, 0)) sumAttachTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.DateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DateReceiveDelay>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, DateReceiveDelay, 0)) maxAttachTime , '--IMS注销时延
          ||' sum(decode(callResult, 1, Dnstime, 0)) sumActivationTime, '--IMS话音挂机时延
          ||' NVL(min(decode(testResult,1,(select min(zt.Dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Dnstime>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, Dnstime, 0)) maxActivationTime , '--IMS话音挂机时延
          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(zt.AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(zt.ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ThirdResponseEndTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, DetachTime, 0)) sumOperateTime, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(zt.DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DetachTime, 0))  maxOperateTime , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||' NVL(min(decode(testResult,1,(select min(zt.ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延
         -- ||' sum(decode(callResult, 1, ToSpDelay, 0)) sumDeActivationTime, '--IMS注销时延
         -- ||' NVL(min(decode(testResult,1,(select min(zt.ToSpDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.ToSpDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
         -- ||' max(decode(callResult, 1, ToSpDelay, 0))  maxDeActivationTime , '--IMS注销时延
          ||' sum(decode(callResult, 1, TotalTime, 0)) sumDetachTime, '--IMS话音挂机
          ||' NVL(min(decode(testResult,1,(select min(zt.TotalTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.TotalTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, TotalTime, 0))  maxDetachTime , '--IMS话音挂机
         
        
          ||' sum(decode(callResult, 1, Receivetime, 0)) sumDeActivationTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.Receivetime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Receivetime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, Receivetime, 0))  maxDeActivationTime , '--IMS注销时延
          

          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount, '---附着成功率 
          ||' sum((case when operateTime>0  then 1 else 0 end)) NotSPCount, '---注册成功率 
          ||' sum((case when  deActivationTime>0  then 1 else 0 end)) NoiseCount, '---去附着成功率 
          ||' sum((case when  receivetime>0  then 1 else 0 end)) BreakLineCount, '---VOLTE成功率 
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

         
          ||' 0 MonoDirectionCount ,0 AcrossCount , 0 SilCount ,'
          ||' 0 ErrCount ,'
          ||' 0 ShortCRCount ,0 NonBeginCRCount ';

     /*elsif(c_testCode=3601 or c_testCode=3602 or c_testCode=3607) then
        tmp := ' sum(decode(callResult, 0, 0, 1)) test_Success_Count_, '
           || ' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
         -- ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --无声音
          
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumAttachTime, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) maxAttachTime, '--附着时延
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RSumDelay, '---上下文/默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RMaxDelay, '---上下文/默认承载建立时延
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sunDnsTime, '--VoLTE默认承载建立时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0))  maxDnsTime , '--VoLTE默认承载建立时延
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumOperateTime, '--VOLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0))  maxOperateTime , '--VOLTE语音专用承载建立时延
          ||' sum(decode(REGISTERESULT_R, 1,REGISTERDELAY_R, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) MaxDelay, '--IMS登陆时延
         ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumReceivetime, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0))  maxReceivetime , '--呼叫建立时延
  
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumErrPacketRate, '--语音挂机
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate , '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) maxErrPacketRate , '--语音挂机
         
          ||' sum(decode(callResult, 1, DEGISTERDELAY_R, 0)) sumActivationTime, '--IMS注销时延
          ||' NVL(min(decode(callResult,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, DEGISTERDELAY_R, 0)) maxActivationTime , '--IMS注销时延
          ||' sum(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) sumDetachTime, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_R,1,(select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime , '
          ||' max(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) maxDetachTime , '--LTE去附着总时延
                  
          ||'  sum(decode(ATTACHRESULT_R, 1, 1, 0)) RightCount, '---附着成功率 
          ||'  sum(decode(DEFBEAERRESULT_R, 1, 1, 0)) NotSPCount, '---上下文/默认承载建立
          ||'  sum(decode(VDEFBEAERRESULT_R, 1, 1, 0)) NoiseCount, '---VOLTE默认承载建立成功率 
          ||'  sum(decode(DEDBEAERRESULT_R, 1, 1, 0)) BreakLineCount, '---VOLTE语音专用承载建立成功率 
          
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) ErrCount, '---IMS登陆成功率 
          ||'  sum(decode(VOLTECALLRESULT_R, 1, 1, 0)) ShortCRCount, '---呼叫建立成功率 
          ||'  sum(decode(VOLTECANCELRESULT_R, 1, 1, 0)) RSuccessCount, '---话音挂机
          ||'  sum(decode(DETTACHRESULT_R, 1, 1, 0)) NonBeginCRCount, '---去附着成功 
          
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) registerCount_r, '---IMS注销 
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||'  0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumBreakLine ,0 maxBreakLine , 0 minBreakLine  ';
      
     elsif(c_testCode=3603 or c_testCode=3604 ) then
        tmp := ' sum(decode(callResult, 0, 0, 1)) test_Success_Count_, '
           || ' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
         -- ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
         
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumAttachTime, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) maxAttachTime, '--附着时延
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RSumDelay, '---上下文/默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RMaxDelay, '---上下文/默认承载建立时延
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sunDnsTime, '--VoLTE默认承载建立时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0))  maxDnsTime , '--VoLTE默认承载建立时延
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumOperateTime, '--VOLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0))  maxOperateTime , '--VOLTE语音专用承载建立时延
          ||' sum(decode(REGISTERESULT_R, 1,REGISTERDELAY_R, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) MaxDelay, '--IMS登陆时延
         ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumReceivetime, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0))  maxReceivetime , '--呼叫建立时延
  
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumErrPacketRate, '--语音挂机
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate , '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) maxErrPacketRate , '--语音挂机
         
          ||' sum(decode(callResult, 1, DEGISTERDELAY_R, 0)) sumActivationTime, '--IMS注销时延
          ||' NVL(min(decode(callResult,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, DEGISTERDELAY_R, 0)) maxActivationTime , '--IMS注销时延
          ||' sum(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) sumDetachTime, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_R,1,(select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime , '
          ||' max(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) maxDetachTime , '--LTE去附着总时延
                  
          ||'  sum(decode(ATTACHRESULT_R, 1, 1, 0)) RightCount, '---附着成功率 
          ||'  sum(decode(DEFBEAERRESULT_R, 1, 1, 0)) NotSPCount, '---上下文/默认承载建立
          ||'  sum(decode(VDEFBEAERRESULT_R, 1, 1, 0)) NoiseCount, '---VOLTE默认承载建立成功率 
          ||'  sum(decode(DEDBEAERRESULT_R, 1, 1, 0)) BreakLineCount, '---VOLTE语音专用承载建立成功率 
          
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) ErrCount, '---IMS登陆成功率 
          ||'  sum(decode(VOLTECALLRESULT_R, 1, 1, 0)) ShortCRCount, '---呼叫建立成功率 
          ||'  sum(decode(VOLTECANCELRESULT_R, 1, 1, 0)) RSuccessCount, '---话音挂机
          ||'  sum(decode(DETTACHRESULT_R, 1, 1, 0)) NonBeginCRCount, '---去附着成功 
          
           ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) registerCount_r, '---IMS注销 
           
          ||' sum(decode(callResult, 1, callerValue, 0)) sumBreakLine, '--MOS
          ||' NVL(min(decode(callResult,1,(select min(zt.callerValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.callerValue>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, callerValue, 0)) maxBreakLine , '--MOS
          
          
          
         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 MonoDirectionCount ,0 AcrossCount ,0 SilCount ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime ';

      elsif(c_testCode=3605 or c_testCode=3606 ) then
        tmp := ' sum(decode(callResult, 0, 0, 1)) test_Success_Count_, '
           || ' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
         -- ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
         
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumAttachTime, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) maxAttachTime, '--附着时延
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RSumDelay, '---上下文/默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RMaxDelay, '---上下文/默认承载建立时延
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sunDnsTime, '--VoLTE默认承载建立时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0))  maxDnsTime , '--VoLTE默认承载建立时延
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumOperateTime, '--VOLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0))  maxOperateTime , '--VOLTE语音专用承载建立时延
          ||' sum(decode(REGISTERESULT_R, 1,REGISTERDELAY_R, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) MaxDelay, '--IMS登陆时延
         ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumReceivetime, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0))  maxReceivetime , '--呼叫建立时延
  
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumErrPacketRate, '--语音挂机
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate , '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) maxErrPacketRate , '--语音挂机
         
          ||' sum(decode(callResult, 1, DEGISTERDELAY_R, 0)) sumActivationTime, '--IMS注销时延
          ||' NVL(min(decode(callResult,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, DEGISTERDELAY_R, 0)) maxActivationTime , '--IMS注销时延
          ||' sum(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) sumDetachTime, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_R,1,(select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime , '
          ||' max(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) maxDetachTime , '--LTE去附着总时延
                  
          ||'  sum(decode(ATTACHRESULT_R, 1, 1, 0)) RightCount, '---附着成功率 
          ||'  sum(decode(DEFBEAERRESULT_R, 1, 1, 0)) NotSPCount, '---上下文/默认承载建立
          ||'  sum(decode(VDEFBEAERRESULT_R, 1, 1, 0)) NoiseCount, '---VOLTE默认承载建立成功率 
          ||'  sum(decode(DEDBEAERRESULT_R, 1, 1, 0)) BreakLineCount, '---VOLTE语音专用承载建立成功率 
          
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) ErrCount, '---IMS登陆成功率 
          ||'  sum(decode(VOLTECALLRESULT_R, 1, 1, 0)) ShortCRCount, '---呼叫建立成功率 
          ||'  sum(decode(VOLTECANCELRESULT_R, 1, 1, 0)) RSuccessCount, '---话音挂机
          ||'  sum(decode(DETTACHRESULT_R, 1, 1, 0)) NonBeginCRCount, '---去附着成功 
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) registerCount_r, '---IMS注销 
          
          ||' NVL(min(decode(callResult, 1, (select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '  --最小丢包率
          ||' max(decode(callResult, 1, lostPacketRate,2, lostPacketRate, 0)) maxDeActivationTime, '  --最大丢包率
          ||' sum(decode(callResult, 1, lostPacketRate,2,lostPacketRate, 0)) sumDeActivationTime, '
        
 
          ||' NVL(min(decode(callResult,1, (select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_r, '
          ||' max(decode(callResult, 1, errPacketRate,2,errPacketRate, 0)) maxDefbeaerDelay_r, '  --最大错包率
          ||' sum(decode(callResult, 1, errPacketRate,2,errPacketRate, 0)) sumDefbeaerDelay_r, '  --最大错包率
    
          
          ||' NVL(min(decode(callResult,1,(select min(Times) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.Times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(Times) from z_testresult zt where zt.taskid=t2.taskid   and zt.Times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_r, '
          ||' max(decode(callResult, 1, Times,2,Times, 0)) maxVdefbeaerDelay_r , '  --最大时延
          ||' sum(decode(callResult, 1, Times,2, times, 0)) sumVdefbeaerDelay_r , '  --平均时延
          
          ||' NVL(min(decode(callResult,1, (select min(SocketTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.SocketTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(SocketTime) from z_testresult zt where zt.taskid=t2.taskid   and zt.SocketTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, SocketTime,2,SocketTime, 0)) maxBreakLine, '  --最大抖动
          ||' sum(decode(callResult, 1, SocketTime,2,SocketTime, 0)) sumBreakLine, '  --平均抖动
          
          
          
         ||' 0 defbeaerCount_r ,'
         ||' 0 vdefbeaerCount_r  ,'
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

         ||' 0 MonoDirectionCount ,0 AcrossCount ,0 SilCount ';
          
     elsif(c_testCode=3108)  then
        tmp := ' sum(decode(callResult, 0, 0, 1)) test_Success_Count_, '
           || ' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
           ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
           ||' 0 sum(decode(callResult, 1, 0, 1)) FailureCount, '
         
          ||' sum(decode(DefbeaerResult_r, 1, DEFBEAERDELAY_R, 0)) sunDnsTime, '--Gx 会话释放
          ||' NVL(min(decode(DefbeaerResult_r,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.DefbeaerResult_r=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(DefbeaerResult_r, 1, DEFBEAERDELAY_R, 0))  maxDnsTime , '--Gx 会话释放
          
          ||' sum(decode(IDENTITYRESULT_R, 1, IDENTITYDELAY_R, 0)) sumOperateTime, '--Rx 会话释放时延
          ||' NVL(min(decode(IDENTITYRESULT_R,1,(select min(IDENTITYDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.IDENTITYRESULT_R=1 and zt.IDENTITYDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(IDENTITYRESULT_R, 1, IDENTITYDELAY_R, 0))  maxOperateTime , '--Rx 会话释放时延
          
          ||' sum(decode(AUTHRESULT_R, 1,AUTHDELAY_R, 0)) sumDelay, ' --IMS默认承载接口
          ||' NVL(min(decode(AUTHRESULT_R,1,(select min(AUTHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.AUTHRESULT_R=1 and zt.AUTHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(AUTHRESULT_R, 1, AUTHDELAY_R, 0)) MaxDelay, '--IMS默认承载接口
       
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumReceivetime, '-- Gx默认承载接口
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.ATTACHRESULT_R=1 and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0))  maxReceivetime , '-- Gx默认承载接口
  
          ||' sum(decode(SECURITYRESULT_R, 1, SECURITYDELAY_R, 0)) sumErrPacketRate, '--接口会话建立
          ||' NVL(min(decode(SECURITYRESULT_R,1,(select min(SECURITYDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.SECURITYDELAY_R=1  and zt.SECURITYDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate , '
          ||' max(decode(SECURITYRESULT_R, 1, SECURITYDELAY_R, 0)) maxErrPacketRate , '--接口会话建立
         
         
         
                        
          ||'  sum(decode(SECURITYRESULT_R, 1, 1, 0)) RightCount, '---接口会话建立成功率 
          ||'  sum(decode(ATTACHRESULT_R, 1, 1, 0)) NotSPCount, '---Gx默认承载接口
          ||'  sum(decode(AUTHRESULT_R, 1, 1, 0)) NoiseCount, '----IMS默认承载接口
          ||'  sum(decode(IDENTITYRESULT_R, 1, 1, 0)) BreakLineCount, '---Rx 会话释放
          ||'  sum(decode(DefbeaerResult_r, 1, 1, 0)) ErrCount, '---Gx 会话释放 
          
          

         ||' 0 registerCount_r, 0 NonBeginCRCount, 0 ShortCRCount ,'
         ||' 0 sumBreakLine, 0  minBreakLine, 0  maxBreakLine, ' 
         ||' 0 sumActivationTime, 0  minActivationTime, 0  maxActivationTime, '
         ||' 0 sumDetachTime, 0  minDetachTime, 0  maxDetachTime, '
         ||' 0 sumAttachTime, 0  minAttachTime, 0  maxAttachTime, '
         ||' 0 RSumDelay, 0  RMinDelay, 0  RMaxDelay, '
         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '
         ||' 0 MonoDirectionCount ,0 AcrossCount ,0 SilCount ,'
         ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime ';
       */
       
        elsif(c_testCode=8001 or c_testCode=8002 or c_testCode=8003 or c_testCode=3401 or  c_testCode=3708 or c_testCode=3709 or c_testCode=3710 or c_testCode=3711 or  c_testCode=3081 or c_testCode=3082 or c_testCode=3068 or c_testCode=3083 or  c_testCode=3084 or  c_testCode=3085 or c_testCode=3075 or c_testCode=3076 or c_testCode=3601 or c_testCode=3602 or c_testCode=3603 or c_testCode=3604 or c_testCode=3605 or c_testCode=3606 or c_testCode=3607 or c_testCode=3108 or c_testCode=3701 or c_testCode=3702 or c_testCode=3703 or c_testCode=3704 or c_testCode=3705 or c_testCode=3706 or c_testCode=3707) then
        tmp := --' sum(decode(callResult, 0, 0, 1)) test_Success_Count_, '
           ' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 2, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||'  sum(decode(ATTACHRESULT_R, 1, 1, 0)) attachCount_r, '
          ||'  sum(decode(DEFBEAERRESULT_R, 1, 1, 0)) defbeaerCount_r, '
          ||'  sum(decode(VDEFBEAERRESULT_R, 1, 1, 0)) vdefbeaerCount_r, '
          ||'  sum(decode(DEDBEAERRESULT_R, 1, 1, 0)) dedbeaerCount_r, '
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) registerCount_r, '
          ||'  sum(decode(VOLTECALLRESULT_R, 1, 1, 0))  volteCallCount_r, '
          ||'  sum(decode(VOLTECANCELRESULT_R, 1, 1, 0))  volteCancelCount_r, '
          ||'  sum(decode(DEGISTERESULT_R, 1, 1, 0)) degisterCount_r, ' 
          ||'  sum(decode(DETTACHRESULT_R, 1, 1, 0)) dettachCount_r, '
          ||'  sum(decode(IDENTITYRESULT_R, 1, 1, 0)) identityCount_r, '
          ||'  sum(decode(AUTHRESULT_R, 1, 1, 0)) authCount_r, '
          ||'  sum(decode(SECURITYRESULT_R, 1, 1, 0)) securityCount_r, '
          ||'  sum(decode(ATTACHRESULT_D, 1, 1, 0)) attachCount_d, '
          ||'  sum(decode(DEFBEAERRESULT_D, 1, 1, 0)) defbeaerCount_d, '
          ||'  sum(decode(VDEFBEAERRESULT_D, 1, 1, 0)) vdefbeaerCount_d, '
          ||'  sum(decode(DEDBEAERRESULT_D, 1, 1, 0)) dedbeaerCount_d, '
          ||'  sum(decode(REGISTERESULT_D, 1, 1, 0)) registerCount_d, '
          ||'  sum(decode(VOLTECALLRESULT_D, 1, 1, 0))  volteCallCount_d, '
          ||'  sum(decode(VOLTECANCELRESULT_D, 1, 1, 0))  volteCancelCount_d, '
          ||'  sum(decode(DEGISTERESULT_D, 1, 1, 0)) degisterCount_d, '
          ||'  sum(decode(DETTACHRESULT_D, 1, 1, 0))  dettachCount_d, '
          ||'  sum(decode(IDENTITYRESULT_D, 1, 1, 0)) identityCount_d, '
          ||'  sum(decode(AUTHRESULT_D, 1, 1, 0)) authCount_d, '
          ||'  sum(decode(SECURITYRESULT_D, 1, 1, 0)) securityCount_d, '
          
          ||'  sum(decode(TAUSTARTRESULT_R, 1, 1, 0)) taustartCount_r, '
          ||'  sum(decode(TAUSTARTRESULT_D, 1, 1, 0)) taustartCount_d, '
          
          ||' sum(decode(SmsResult_r, 1, 1, 0)) test_Success_Count_, '
           --------------------------主叫---------------
           ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
           ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
           ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --无声音
             ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) NoiseCount, '--回声
          
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumAttachDelay_r, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.ATTACHRESULT_R=1 and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachDelay_r, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) maxAttachDelay_r, '--附着时延
         
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) sumDefbeaerDelay_r, '---默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.DEFBEAERRESULT_R=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_r, '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) maxDefbeaerDelay_r, '---默认承载建立时延
        
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sumVdefbeaerDelay_r, '--VoLTE默认承载建立时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.VDEFBEAERRESULT_R=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_r, '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0))  maxVdefbeaerDelay_r , '--VoLTE默认承载建立时延
         
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumDedbeaerDelay_r, '--VOLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.DEDBEAERRESULT_R=1 and zt.DEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_r, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0))  maxDedbeaerDelay_r , '--VOLTE语音专用承载建立时延
         
          ||' sum(decode(REGISTERESULT_R, 1,REGISTERDELAY_R, 0)) sumRegisterDelay_r, ' --IMS登陆时延
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.REGISTERESULT_R=1 and zt.REGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_r, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) maxRegisterDelay_r, '--IMS登陆时延
        
          ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumVoltecallDelay_r, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.VOLTECALLRESULT_R=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVoltecallDelay_r, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0))  maxVoltecallDelay_r , '--呼叫建立时延
  
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumVoltecancelDelay_r, '--语音挂机
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.VOLTECANCELRESULT_R=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVoltecancelDelay_r , '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) maxVoltecancelDelay_r , '--语音挂机
         
          ||' sum(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0)) sumDegisterDelay_r, '--IMS注销时延
          ||' NVL(min(decode(DEGISTERESULT_R,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.DEGISTERESULT_R=1 and zt.DEGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_r, '
          ||' max(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0)) maxDegisterDelay_r , '--IMS注销时延
          
          ||' sum(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) sumDettachDelay_r, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_R,1,(select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.DETTACHRESULT_R=1 and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDettachDelay_r , '
          ||' max(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) maxDettachDelay_r , '--LTE去附着总时延
          
          ||' sum(decode(IDENTITYRESULT_R, 1, IDENTITYDELAY_R, 0)) sumIdentityDelay_r, '--身份认证时延
          ||' NVL(min(decode(IDENTITYRESULT_R,1,(select min(IDENTITYDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.IDENTITYRESULT_R=1 and zt.IDENTITYDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minIdentityDelay_r , '
          ||' max(decode(IDENTITYRESULT_R, 1, IDENTITYDELAY_R, 0)) maxIdentityDelay_r , '--身份认证时延
          
          ||' sum(decode(AUTHRESULT_R, 1, AUTHDELAY_R, 0)) sumAuthDelay_r, '--鉴权时延
          ||' NVL(min(decode(AUTHRESULT_R,1,(select min(AUTHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.AUTHRESULT_R=1 and zt.AUTHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAuthDelay_r , '
          ||' max(decode(AUTHRESULT_R, 1, AUTHDELAY_R, 0)) maxAuthDelay_r , '--鉴权时延
          
          ||' sum(decode(SECURITYRESULT_R, 1, SECURITYDELAY_R, 0)) sumSecurityDelay_r, '--安全模式选择时延
          ||' NVL(min(decode(SECURITYRESULT_R,1,(select min(SECURITYDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.SECURITYRESULT_R=1 and zt.SECURITYDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minSecurityDelay_r , '
          ||' max(decode(SECURITYRESULT_R, 1, SECURITYDELAY_R, 0)) maxSecurityDelay_r , '--安全模式选择时延
          
          
          ||' sum(decode(TAUSTARTRESULT_R, 1, TAUSTARTDELAY_R, 0)) sumTauStartDelay_r, '--TAU时延
          ||' NVL(min(decode(TAUSTARTRESULT_R,1,(select min(TAUSTARTDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.TAUSTARTRESULT_R=1 and zt.TAUSTARTDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minTauStartDelay_r , '
          ||' max(decode(TAUSTARTRESULT_R, 1, TAUSTARTDELAY_R, 0)) maxTauStartDelay_r , '--TAU时延
           --------------------------被叫---------------
          
          ||' sum(decode(ATTACHRESULT_D, 1, ATTACHDELAY_D, 0)) sumAttachDelay_d, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_D,1,(select min(ATTACHDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.ATTACHRESULT_D=1 and zt.ATTACHDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachDelay_d, '
          ||' max(decode(ATTACHRESULT_D, 1, ATTACHDELAY_D, 0)) maxAttachDelay_d, '--附着时延
         
          ||' sum(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) sumDefbeaerDelay_d, '---默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_D,1,(select min(DEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.DEFBEAERRESULT_D=1 and zt.DEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_d, '
          ||' max(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) maxDefbeaerDelay_d, '---默认承载建立时延
        
          ||' sum(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0)) sumVdefbeaerDelay_d, '--VoLTE默认承载建立时延
          ||' NVL(min(decode(VDEFBEAERRESULT_D,1,(select min(VDEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.VDEFBEAERRESULT_R=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_d, '
          ||' max(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0))  maxVdefbeaerDelay_d , '--VoLTE默认承载建立时延
         
          ||' sum(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0)) sumDedbeaerDelay_d, '--VOLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_D,1,(select min(DEDBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.DEDBEAERRESULT_D=1 and zt.DEDBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_d, '
          ||' max(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0))  maxDedbeaerDelay_d , '--VOLTE语音专用承载建立时延
         
          ||' sum(decode(REGISTERESULT_D, 1,REGISTERDELAY_D, 0)) sumRegisterDelay_d, ' --IMS登陆时延
          ||' NVL(min(decode(REGISTERESULT_D,1,(select min(REGISTERDELAY_d) from z_testresult zt where zt.taskid=t2.taskid and zt.REGISTERESULT_D=1 and zt.REGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_d, '
          ||' max(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0)) maxRegisterDelay_d, '--IMS登陆时延
        
          ||' sum(decode(VOLTECALLRESULT_D, 1, VOLTECALLDELAY_D, 0)) sumVoltecallDelay_d, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_D,1,(select min(VOLTECALLDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.VOLTECALLRESULT_D=1 and zt.VOLTECALLDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVoltecallDelay_d, '
          ||' max(decode(VOLTECALLRESULT_D, 1, VOLTECALLDELAY_D, 0))  maxVoltecallDelay_d , '--呼叫建立时延
  
          ||' sum(decode(VOLTECANCELRESULT_d, 1, VOLTECANCELDELAY_D, 0)) sumVoltecancelDelay_d, '--语音挂机
          ||' NVL(min(decode(VOLTECANCELRESULT_D,1,(select min(VOLTECANCELDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.VOLTECANCELRESULT_D=1 and zt.VOLTECANCELDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVoltecancelDelay_d , '
          ||' max(decode(VOLTECANCELRESULT_D, 1, VOLTECANCELDELAY_D, 0)) maxVoltecancelDelay_d , '--语音挂机
         
          ||' sum(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0)) sumDegisterDelay_d, '--IMS注销时延
          ||' NVL(min(decode(DEGISTERESULT_D,1,(select min(zt.DEGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.DEGISTERESULT_D=1 and zt.DEGISTERDELAY_D>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_d, '
          ||' max(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0)) maxDegisterDelay_d , '--IMS注销时延
          
          ||' sum(decode(DETTACHRESULT_D, 1, DETTACHDELAY_D, 0)) sumDettachDelay_d, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_D,1,(select min(DETTACHDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.DETTACHRESULT_D=1 and zt.DETTACHDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDettachDelay_d , '
          ||' max(decode(DETTACHRESULT_D, 1, DETTACHDELAY_D, 0)) maxDettachDelay_d , '--LTE去附着总时延
          
          ||' sum(decode(IDENTITYRESULT_D, 1, IDENTITYDELAY_D, 0)) sumIdentityDelay_D, '--身份认证时延
          ||' NVL(min(decode(IDENTITYRESULT_D,1,(select min(IDENTITYDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.IDENTITYRESULT_D=1 and zt.IDENTITYDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minIdentityDelay_d , '
          ||' max(decode(IDENTITYRESULT_D, 1, IDENTITYDELAY_D, 0)) maxIdentityDelay_d , '--身份认证时延
          
          ||' sum(decode(AUTHRESULT_D, 1, AUTHDELAY_D, 0)) sumAuthDelay_d, '--鉴权时延
          ||' NVL(min(decode(AUTHRESULT_D,1,(select min(AUTHDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.AUTHRESULT_D=1 and zt.AUTHDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAuthDelay_d , '
          ||' max(decode(AUTHRESULT_D, 1, AUTHDELAY_D, 0)) maxAuthDelay_d , '--鉴权时延
          
          ||' sum(decode(SECURITYRESULT_D, 1, SECURITYDELAY_D, 0)) sumSecurityDelay_d, '--安全模式选择时延
          ||' NVL(min(decode(SECURITYRESULT_D,1,(select min(SECURITYDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.SECURITYRESULT_D=1 and zt.SECURITYDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minSecurityDelay_d , '
          ||' max(decode(SECURITYRESULT_D, 1, SECURITYDELAY_D, 0)) maxSecurityDelay_d , '--安全模式选择时延
          
           ||' sum(decode(TAUSTARTRESULT_D, 1, TAUSTARTDELAY_D, 0)) sumTauStartDelay_d, '--TAU时延
          ||' NVL(min(decode(TAUSTARTRESULT_D,1,(select min(TAUSTARTDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.TAUSTARTRESULT_D=1 and zt.TAUSTARTDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minTauStartDelay_d , '
          ||' max(decode(TAUSTARTRESULT_D, 1, TAUSTARTDELAY_D, 0)) maxTauStartDelay_d , '--TAU时延
          
          ||' sum(decode(callResult, 1, callerValue, 0)) sumOperateTime, '--MOS
          ||' NVL(min(decode(callResult,1,(select min(zt.callerValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.callerValue>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, callerValue, 0)) maxOperateTime , '--MOS
          
          ||' sum(decode(callResult, 1, CalledValue, 0)) sumAttachTime, '--被叫mos
          ||' NVL(min(decode(callResult,1,(select min(zt.CalledValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.CalledValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, CalledValue, 0))  maxAttachTime , '--mos
          
          ||' NVL(min(decode(callResult, 1, (select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '  --最小丢包率
          ||' max(decode(callResult, 1, lostPacketRate,2, lostPacketRate, 0)) maxReceivetime, '  --最大丢包率
          ||' sum(decode(callResult, 1, lostPacketRate,2,lostPacketRate, 0)) sumReceivetime, '
        
 
          ||' NVL(min(decode(callResult,1, (select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, errPacketRate,2,errPacketRate, 0)) maxErrPacketRate, '  --最大错包率
          ||' sum(decode(callResult, 1, errPacketRate,2,errPacketRate, 0)) sumErrPacketRate, '  --最大错包率
    
          
          ||' NVL(min(decode(callResult,1,(select min(avgdelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.avgdelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(Times) from z_testresult zt where zt.taskid=t2.taskid   and zt.Times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, avgdelay, 0)) RMaxDelay , '  --最大时延
          ||' sum(decode(callResult, 1, avgdelay, 0)) RSumDelay , '  --平均时延
          
          ||' NVL(min(decode(callResult,1, (select min(breakline) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.breakline>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')),2,(select min(SocketTime) from z_testresult zt where zt.taskid=t2.taskid   and zt.SocketTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, breakline, 0)) maxBreakLine, '  --最大抖动
          ||' sum(decode(callResult, 1, breakline, 0)) sumBreakLine, '  --平均抖动
          
          ||' sum(decode(SmsResult_r, 1, SMSTIME_R, 0)) sumDelay, '--彩印时延
          ||' NVL(min(decode(SmsResult_r,1,(select min(SMSTIME_R) from z_testresult zt where zt.taskid=t2.taskid and zt.SmsResult_r=2 and zt.SMSTIME_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay , '
          ||' max(decode(SmsResult_r, 1, SMSTIME_R, 0)) MaxDelay , '--彩印时延
          
          ||' sum(decode(callResult, 1, Times, 0)) sunDnsTime, '--来电与彩印时间差
          ||' NVL(min(decode(callResult,1,(select min(Times) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.Times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime , '
          ||' max(decode(callResult, 1, Times, 0)) maxDnsTime , '--来电与彩印时间差
          
         ||' sum(case when  DEDBEAERLOCALPORT_r>0 and DEDBEAERREMOTEPORT_r>0 then 1 else 0 end ) NotSPCount, '
          ||' sum(case when  SECURITYRESULT_r>0 and IDENTITYRESULT_r>0 then 1 else 0 end ) RightCount, '
          

          ||' 0 ErrCount, 0 BreakLineCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          --||' 0 sumDelay , 0 MinDelay , 0 MaxDelay ,'
         -- ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime ';
                              
     elsif(c_testCode=3062 or c_testCode=3063) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
           || ' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
         -- ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumAttachTime, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) maxAttachTime, '--附着时延
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RSumDelay, '---上下文/默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) RMaxDelay, '---上下文/默认承载建立时延
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sunDnsTime, '--VoLTE默认承载建立时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0))  maxDnsTime , '--VoLTE默认承载建立时延
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumOperateTime, '--VOLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0))  maxOperateTime , '--VOLTE语音专用承载建立时延
          ||' sum(decode(REGISTERESULT_R, 1,REGISTERDELAY_R, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) MaxDelay, '--IMS登陆时延
         ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumReceivetime, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0))  maxReceivetime , '--呼叫建立时延
  
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumErrPacketRate, '--语音挂机
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate , '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) maxErrPacketRate , '--语音挂机
         
          ||' sum(decode(callResult, 1, DEGISTERDELAY_R, 0)) sumActivationTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, DEGISTERDELAY_R, 0)) maxActivationTime , '--IMS注销时延
          ||' sum(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) sumDetachTime, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_R,1,(select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime , '
          ||' max(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) maxDetachTime , '--LTE去附着总时延
                  
          
          ||'  sum(decode(ATTACHRESULT_R, 1, 1, 0)) RightCount, '---附着成功率 
          ||'  sum(decode(DEFBEAERRESULT_R, 1, 1, 0)) NotSPCount, '---上下文/默认承载建立
          ||'  sum(decode(VDEFBEAERRESULT_R, 1, 1, 0)) NoiseCount, '---VOLTE默认承载建立成功率 
          ||'  sum(decode(DEDBEAERRESULT_R, 1, 1, 0)) BreakLineCount, '---VOLTE语音专用承载建立成功率 
          ||'  sum(decode(REGISTERESULT_R, 1, 1, 0)) ErrCount, '---IMS登陆成功率 
          ||'  sum(decode(VOLTECALLRESULT_R, 1, 1, 0)) ShortCRCount, '---呼叫建立成功率 
          ||'  sum(decode(VOLTECANCELRESULT_R, 1, 1, 0)) AcrossCount, '---话音挂机
          ||'  sum(decode(DETTACHRESULT_R, 1, 1, 0)) NonBeginCRCount, '---去附着成功 
          ||'  sum(decode(DEGISTERESULT_R, 1, 1, 0)) SilCount, '---IMS注销
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

    
          ||' 0 MonoDirectionCount , 0 RSuccessCount  ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumBreakLine ,0 maxBreakLine , 0 minBreakLine  ';
          
       elsif(c_testCode=3350 or c_testCode=3351 ) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, ATTACHDELAY_R, 0)) sumBreakLine, '--PS域CCR-I总时延
          ||' NVL(min(decode(testResult,1,(select min(zt.ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ATTACHDELAY_R, 0)) maxBreakLine, '
        
          ||' sum(decode(callResult, 1,DEDBEAERDELAY_R, 0)) sumDelay, ' --PS域CCR-U
          ||' NVL(min(decode(testResult,1,(select min(zt.DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, DEDBEAERDELAY_R, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, DETTACHDELAY_R, 0)) sumErrPacketRate, '--PS域CCR-T
          ||' NVL(min(decode(testResult,1,(select min(zt.DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DETTACHDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DETTACHDELAY_R, 0)) maxErrPacketRate , '
          
          ||' sum(decode(callResult, 1, VDEFBEAERDELAY_R, 0)) sumAttachTime, '--IMS域CCR-I时延
          ||' NVL(min(decode(testResult,1,(select min(zt.VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, VDEFBEAERDELAY_R, 0)) maxAttachTime , '
          
          ||' sum(decode(callResult, 1, DEDBEAERDELAY_R, 0)) sumActivationTime, '--IMS域CCR-U
          ||' NVL(min(decode(testResult,1,(select min(zt.DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, DEDBEAERDELAY_R, 0)) maxActivationTime , '
          
          ||' sum(decode(callResult, 1, RELDEDBEAERDELAY_R, 0)) RSumDelay, '---IMS域CCR-T
          ||' NVL(min(decode(testResult,1,(select min(zt.RELDEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.RELDEDBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, RELDEDBEAERDELAY_R, 0)) RMaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

                     
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime , 0 maxDeActivationTime , 0 minDeActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime ,'
             
          ||' 0 MonoDirectionCount ,0 AcrossCount , 0 SilCount ,'
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount ,'
          ||' 0 ShortCRCount ,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';
          
      elsif(c_testCode=3008) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
         -- ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
         -- ||' NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
         -- ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, CallerValue, 0)) sumActivationTime, ' --主叫MOS
          ||' NVL(min(decode(callResult,1,(select min(CallerValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.CallerValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, CallerValue, 0)) maxActivationTime, '--主叫MOS
          ||' sum(decode(callResult, 1, Dnstime, 0)) sumBreakLine, '--IMS话音挂机时延
          ||' NVL(min(decode(testResult,1,(select min(Dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Dnstime>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, Dnstime, 0)) maxBreakLine , '--IMS话音挂机时延

          ||' sum(decode(callResult, 1, DateReceiveDelay, 0)) sumAttachTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(DateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DateReceiveDelay>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, DateReceiveDelay, 0)) maxAttachTime , '--IMS注销时延

          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ThirdResponseEndTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, DetachTime, 0)) sumOperateTime, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DetachTime, 0))  maxOperateTime , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||' NVL(min(decode(testResult,1,(select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延

          ||' sum(decode(callResult, 1, CalledValue, 0)) sumDetachTime, '--被叫MOS
          ||' NVL(min(decode(callResult,1,(select min(CalledValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.CalledValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, CalledValue, 0)) maxDetachTime, '
        --  ||' sum(decode(callResult, 1, ToSpDelay, 0)) sumDeActivationTime, '--MS注销时延
        --  ||' NVL(min(decode(testResult,1,(select min(ToSpDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.ToSpDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
         -- ||' max(decode(callResult, 1, ToSpDelay, 0))  maxDeActivationTime , '--MS注销时延

         ||' sum(decode(callResult, 1, Receivetime, 0)) sumDeActivationTime, '--IMS注销时延
          ||' NVL(min(decode(testResult,1,(select min(zt.Receivetime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.Receivetime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, Receivetime, 0))  maxDeActivationTime , '--IMS注销时延
        
          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount, '---附着成功率 
          ||' sum((case when operateTime>0  then 1 else 0 end)) NotSPCount, '---注册成功率 
          ||' sum((case when  deActivationTime>0  then 1 else 0 end)) NoiseCount, '---去附着成功率 
          ||' sum((case when  receivetime>0  then 1 else 0 end)) BreakLineCount, '---VOLTE成功率 
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          ||' 0 MonoDirectionCount ,0 AcrossCount , 0 SilCount ,'
          ||' 0 ErrCount,'
          ||' 0 ShortCRCount ,0 NonBeginCRCount ';

    elsif(c_testCode=3009) then
             tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(testResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
           ||' NVL(min(decode(testResult,1,(select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(testResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(testResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(testResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(testResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
       --   ||' sum(decode(testResult, 1, Dnstime, 0)) sumOperateTime, '--话音挂机
        --  ||' NVL(min(decode(testResult,1,(select min(Dnstime) from z_testresult zt where zt.taskid=t2.taskid  and zt.Dnstime>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
        ---  ||' max(decode(testResult, 1, Dnstime, 0)) maxOperateTime , '--话音挂机

          --被叫--
          ||' sum(decode(testResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(testResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.ThirdResponseEndTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(testResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延

         /* ||' sum(decode(callResult, 1, DetachTime, 0)) sumOperateTime, '--LTE去附着总时延
          --||' NVL(min(decode(callResult, 1, DetachTime, null)), 0)  minOperateTime , '--LTE去附着总时延
           ||' NVL(min(decode(testResult,1,(select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DetachTime, 0))  maxOperateTime , '--LTE去附着总时延
          */

          ||' sum(decode(testResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||' NVL(min(decode(testResult,1,(select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(testResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延
         
          ||' NVL(min(decode(testResult, 1, (select min(lostPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.lostPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '  --最小丢包率
          ||' max(decode(testResult, 1, lostPacketRate, 0)) maxAttachTime, '  --最大丢包率
          ||' sum(decode(testResult, 1, lostPacketRate, 0)) sumAttachTime, '
        
 
          ||' NVL(min(decode(testResult,1, (select min(errPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.errPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(testResult, 1, errPacketRate, 0)) maxDetachTime, '  --最大错包率
          ||' sum(decode(testResult, 1, errPacketRate, 0)) sumDetachTime, '  --最大错包率
    
          
          ||' NVL(min(decode(testResult,1,(select min(Times) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.Times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(testResult, 1, Times, 0)) maxActivationTime , '  --最大时延
          ||' sum(decode(testResult, 1, Times, 0)) sumActivationTime , '  --平均时延
          
          ||' NVL(min(decode(testResult,1, (select min(SocketTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.SocketTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(testResult, 1, SocketTime, 0)) maxDeActivationTime, '  --最大抖动
          ||' sum(decode(testResult, 1, SocketTime, 0)) sumDeActivationTime, '  --平均抖动

         ||' sum(decode(callResult, 1, receivetime, 0)) sumOperateTime, '--volte专用承载时延
         ||' NVL(min(decode(testResult,1,(select min(zt.receivetime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.receivetime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
         ||' max(decode(callResult, 1, receivetime, 0))  maxOperateTime , '--专用承载时延
       
          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount, '---附着成功率 
          ||' sum((case when operateTime>0  then 1 else 0 end)) SilCount, '---注册成功率 
          ||' sum((case when  deActivationTime>0  then 1 else 0 end)) NoiseCount, '---去附着成功率 
          ||' sum((case when  receivetime>0  then 1 else 0 end)) BreakLineCount, '---VOLTE成功率 
          ||' sum((case when errPacketRate>0  then 1 else 0 end)) AcrossCount, '
          ||' sum((case when sendPacket-recvPacket>0  then 1 else 0 end)) NotSPCount, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 ErrCount, 0 MonoDirectionCount,'
          ||' 0 ShortCRCount,0 NonBeginCRCount ';
          

    elsif(c_testCode=3012 or c_testCode=3013 or c_testCode=3017 or c_testCode=3019 or c_testCode=3020 or c_testCode=3022 or c_testCode=3079) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1, (select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1, (select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) RSumDelay, '--LTE鉴权时延
          ||' NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.ResponseTime>0 and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, ResponseTime, 0)) RMaxDelay, '--LTE鉴权时延
          ||' sum(decode(callResult, 1,DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1, (select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||' NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延
         
          ||' sum((case when activationTime>0  then 1 else 0 end)) RightCount, '---附着成功率 
          ||' sum((case when operateTime>0  then 1 else 0 end)) NotSPCount, '---注册成功率 
          ||' sum((case when  deActivationTime>0  then 1 else 0 end)) NoiseCount, '---去附着成功率 
          ||' sum((case when  breakLine>0  then 1 else 0 end)) BreakLineCount, '---承载建立时延
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
        
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 ErrCount, 0 MonoDirectionCount,'
          ||' 0 AcrossCount,0 ShortCRCount,0 SilCount,0 NonBeginCRCount ';

     elsif(c_testCode=3014) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1,  (select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,  (select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1,SendPacket, 0)) sumDeActivationTime, '--控制面切换中断时延
          ||' NVL(min(decode(testResult,1,  (select min(SendPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.SendPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, SendPacket, 0))  maxDeActivationTime , '--控制面切换中断时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--延呼叫建立时延
          ||' NVL(min(decode(testResult,1,  (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--延呼叫建立时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,  (select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, MaxDelay, 0)) sumActivationTime, '--主叫ATU时延
          ||' NVL(min(decode(testResult,1,  (select min(MaxDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.MaxDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, MaxDelay, 0))  maxActivationTime , '--主叫ATU时延
          ||' sum(decode(callResult, 1, TotalTime, 0)) sumAttachTime, '--话音挂机时延
          ||' NVL(min(decode(testResult,1,  (select min(TotalTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.TotalTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, TotalTime, 0))  maxAttachTime , '--话音挂机时延
          ||' sum(decode(callResult, 1, ToSpDelay, 0)) sumDetachTime, '--用户面切换中断时延
          ||' NVL(min(decode(testResult,1,  (select min(ToSpDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ToSpDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, ToSpDelay, 0))  maxDetachTime , '--用户面切换中断时延

          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,  (select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,  (select min(ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ThirdResponseEndTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, DetachTime, 0)) sumOperateTime, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,  (select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DetachTime, 0))  maxOperateTime , '--LTE去附着总时延
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 MonoDirectionCount, 0 AcrossCount, 0 SilCount, '
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount ,'
          ||' 0 ShortCRCount ,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';

      elsif(c_testCode=3015) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||'  NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||'  NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||'  NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          /*||' sum(decode(callResult, 1, SendPacket, 0)) sumAttachTime, '--主叫切换时延
          ||' NVL(min(decode(testResult,1, (select min(SendPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.SendPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, SendPacket, 0))  maxAttachTime , '--主叫切换时延*/
          ||' sum(decode(callResult, 1, dnstime, 0)) sumAttachTime, '--话音挂机时延
          ||'  NVL(min(decode(testResult,1,(select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, dnstime, 0)) maxAttachTime , '--话音挂机时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||'  NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延

          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ThirdResponseEndTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, DetachTime, 0)) sumOperateTime, '--LTE去附着总时延
          ||'  NVL(min(decode(testResult,1,(select min(DetachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DetachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DetachTime, 0))  maxOperateTime , '--LTE去附着总时延

          ||' sum(decode(callResult, 1, RecvPacket, 0)) sumDeActivationTime, '--被叫控制面切换中断时延
          ||'  NVL(min(decode(testResult,1, (select min(RecvPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.RecvPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, RecvPacket, 0))  maxDeActivationTime , '--被叫控制面切换中断时延
          ||' sum(decode(callResult, 1,ErrPacketRate, 0)) sumDetachTime, '--被叫ATU总时延
          ||' NVL(min(decode(testResult,1, (select min(ErrPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.ErrPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, ErrPacketRate, 0))  maxDetachTime  , '--被ATU总时延
          ||' sum(decode(callResult, 1, DateReceiveDelay, 0)) sumActivationTime, '--被叫用户面切换中断时延
          ||' NVL(min(decode(testResult,1, (select min(DateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DateReceiveDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, DateReceiveDelay, 0))  maxActivationTime , '--被叫用户面切换中断时延
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 MonoDirectionCount ,0 AcrossCount , 0 SilCount ,'
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount ,'
          ||' 0 ShortCRCount ,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';
    elsif(c_testCode=3016) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||'  NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||'  NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, SendPacket, 0)) sumErrPacketRate, '--控制面切换中断时延
          ||'  NVL(min(decode(testResult,1,(select min(SendPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.SendPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, SendPacket, 0)) maxErrPacketRate , '--控制面切换中断时延
          ||' sum(decode(callResult, 1, dnstime, 0)) sumAttachTime, '--话音挂机时延
          ||'  NVL(min(decode(testResult,1,(select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, dnstime, 0)) maxAttachTime , '--话音挂机时延

         ||' sum(decode(callResult, 1, DateReceiveDelay, 0)) sumOperateTime, '--用户面切换中断时延
         ||'  NVL(min(decode(testResult,1,(select min(DateReceiveDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DateReceiveDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
         ||' max(decode(callResult, 1, DateReceiveDelay, 0))  maxOperateTime , '--用户面切换中断时延

          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--振铃时延
          ||'  NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--振铃时延
          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, ThirdResponseEndTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(ThirdResponseEndTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ThirdResponseEndTime>0  and zt.ThirdResponseEndTime>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ThirdResponseEndTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, RecvPacket, 0)) sumDeActivationTime, '--被叫控制面切换中断时延
          ||'  NVL(min(decode(testResult,1, (select min(RecvPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.RecvPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, RecvPacket, 0))  maxDeActivationTime , '--被叫控制面切换中断时延
          ||' sum(decode(callResult, 1,ErrPacketRate, 0)) sumDetachTime, '--被叫ATU总时延
          ||' NVL(min(decode(testResult,1, (select min(ErrPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ErrPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, ErrPacketRate, 0))  maxDetachTime  , '--被ATU总时延
          ||' sum(decode(callResult, 1, ToSpDelay, 0)) sumActivationTime, '--被叫用户面切换中断时延
          ||' NVL(min(decode(testResult,1, (select min(ToSpDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ToSpDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, ToSpDelay, 0))  maxActivationTime , '--被叫用户面切换中断时延
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 MonoDirectionCount ,0 AcrossCount , 0 SilCount ,'
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount ,'
          ||' 0 ShortCRCount ,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';
          
       elsif (c_testCode=3101 or c_testCode=3102  or c_testCode=3103 or c_testCode=3104 or c_testCode=3105) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(RESPONSETIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.RESPONSETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';


     elsif(c_testCode=3023 or c_testCode=3024 or c_testCode=3025 or c_testCode=3026 or c_testCode=3027 or  c_testCode=3028 or c_testCode=3029 or c_testCode=3030 or c_testCode=3031 or c_testCode=3032 or c_testCode=3033 or c_testCode=3034) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sumReceivetime, '--提交时延
          ||'  NVL(min(decode(testResult,1, (select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minReceivetime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxReceivetime , '--提交时延
          ||' sum(decode(callResult, 1, SendPacket, 0)) sumOperateTime, '--全程时延
          ||'  NVL(min(decode(testResult,1,(select min(SendPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.SendPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, SendPacket, 0))  maxOperateTime , '--全程时延
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||'  NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumErrPacketRate, '--默认承载时延
          ||'  NVL(min(decode(testResult,1,(select min(BreakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, BreakLine, 0)) maxErrPacketRate , '--默认承载时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||'  NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumAttachTime, '--去附着时延
          ||'  NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxAttachTime , '--去附着时延

          --被叫--
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '---附着时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '---附着时延
          ||' sum(decode(callResult, 1, RecvPacket, 0)) sumDeActivationTime, '--默认承载建立时延
          ||'  NVL(min(decode(testResult,1, (select min(RecvPacket) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.RecvPacket>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, RecvPacket, 0))  maxDeActivationTime , '--默认承载建立时延
          ||' sum(decode(callResult, 1, secondResponseTime, 0)) sunDnsTime, '--IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(secondResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.TALKSTATUS=2 and zt.secondResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, secondResponseTime, 0))  maxDnsTime , '--IMS登陆时延
          ||' sum(decode(callResult, 1, detachTime, 0)) sumActivationTime, '--去附着时延(
          ||' NVL(min(decode(testResult,1, (select min(detachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.detachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, detachTime, 0))  maxActivationTime , '--去附着时延(

          ||' sum(decode(callResult, 1,ErrPacketRate, 0)) sumDetachTime, '--位置更新时延
          ||' NVL(min(decode(testResult,1, (select min(ErrPacketRate) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ErrPacketRate>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, ErrPacketRate, 0))  maxDetachTime  , '--位置更新时延
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '



          ||' 0 MonoDirectionCount ,0 AcrossCount , 0 SilCount ,'
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount ,'
          ||' 0 ShortCRCount ,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';

    elsif (c_testCode=3106) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, ' --成功次数
          ||' sum(decode(callResult, 1, 1,6,1,0)) SuccessCount, ' --成功次数
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' --失败次数
          ||' sum(decode(callResult, 1, ActivationTime, 0)) sumDelay, '--平均业务时延
          ||' NVL(min(decode(callResult,1, (select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) MaxDelay, '--最大业务时延
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) AcrossCount, ' --错配次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) NoiseCount, ' --漏配次数
          ||' sum(decode(testResult, 1, decode(callResult,4,1,0), 0)) ErrCount, ' --多配次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) ShortCRCount, ' --无响应次数
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 MonoDirectionCount, 0 BreakLineCount , 0 NonBeginCRCount , 0 SilCount ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 RightCount, 0 NotSPCount, 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
    elsif (c_testCode=3107) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, ActivationTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, ActivationTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';


     elsif(c_testCode=3035 or c_testCode=3036 or c_testCode=3037) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(callResult, 1, activationTime, 0)) sumBreakLine, '--附着时延
          ||' NVL(min(decode(testResult,1,(select min(ActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(callResult, 1, ActivationTime, 0)) maxBreakLine, '--附着时延
          ||' sum(decode(callResult, 1,OperateTime, 0)) sumDelay, ' --IMS登陆时延
          ||' NVL(min(decode(testResult,1,(select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, OperateTime, 0)) MaxDelay, '--IMS登陆时延
          ||' sum(decode(callResult, 1, AttachTime, 0)) RSumDelay, '--注销时延
          ||' NVL(min(decode(testResult,1,(select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, AttachTime, 0)) RMaxDelay, '--注销时延
          ||' sum(decode(callResult, 1, DeActivationTime, 0)) sumErrPacketRate, '--LTE去附着总时延
          ||' NVL(min(decode(testResult,1,(select min(DeActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DeActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minErrPacketRate, '
          ||' max(decode(callResult, 1, DeActivationTime, 0)) maxErrPacketRate , '--LTE去附着总时延
          ||' sum(decode(callResult, 1, ResponseTime, 0)) sunDnsTime, '--延呼叫建立
          ||' NVL(min(decode(testResult,1,(select min(ResponseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ResponseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, ResponseTime, 0))  maxDnsTime , '--延呼叫建立
          ||' sum(decode(callResult, 1, Dnstime, 0)) sumOperateTime, '--话音挂机
          ||' NVL(min(decode(testResult,1,(select min(Dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, Dnstime, 0))  maxOperateTime , '--话音挂机
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumReceivetime ,0 maxReceivetime , 0 minReceivetime , '
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 ErrCount, 0 RightCount, 0 NotSPCount, 0 MonoDirectionCount,'
          ||' 0 AcrossCount,0 ShortCRCount,0 SilCount,0 NoiseCount,0 NonBeginCRCount ,'
          ||' 0 BreakLineCount ';
        elsif (c_testCode=3201 or c_testCode=3202) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, responseTime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(responseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.responseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, responseTime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
      elsif (c_testCode=3203) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, dnstime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, dnstime, 0)) MaxDelay, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';

     elsif (c_testCode=3204 or c_testCode=3206) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '
          ||' sum(decode(testResult, 1, dnstime, 0)) sumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, dnstime, 0)) MaxDelay, '
          
          ||' sum(decode(testResult, 1, times, 0)) RSumDelay, '
          ||' NVL(min(decode(testResult,1, (select min(times) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, times, 0)) RMaxDelay, '
          
           ||' sum(decode(testResult, 1, sockettimeall, 0)) sumBreakLine, '
          ||' NVL(min(decode(testResult,1, (select min(sockettimeall) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.sockettimeall>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(testResult, 1, sockettimeall, 0)) maxBreakLine, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 MonoDirectionCount, 0 BreakLineCount ';


      elsif (c_testCode=3301 or c_testcode=3302  or c_testCode=3303  or c_testCode=3304 ) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          
          ||' sum(decode(callResult, 1, attachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(callResult,1, (select min(attachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.attachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, attachTime, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, detachTime, 0)) sumDetachTime, '
          ||' NVL(min(decode(callResult,1, (select min(detachTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.detachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, detachTime, 0)) maxDetachTime, '

          ||' sum(decode(callResult, 1, activationTime, 0)) sumActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, activationTime, 0)) maxActivationTime, '
          
          ||' sum(decode(callResult, 1, deActivationTime, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(deActivationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.deActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, deActivationTime, 0)) maxDeActivationTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumDelay , 0 MinDelay , 0 MaxDelay , '
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , 0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
       elsif (c_testCode=3038 or c_testCode=3039 or c_testCode=3077) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
            
          ||' sum((case when attachTime>0  then 1 else 0 end)) RightCount, '
          ||' sum((case when activationTime>0  then 1 else 0 end)) NoiseCount, '
          ||' sum((case when deActivationTime>0  then 1 else 0 end)) NonBeginCRCount, '
          ||' sum((case when detachTime>0  then 1 else 0 end)) BreakLineCount, '
          
          ||' sum(decode(callResult, 1, attachTime, 0)) sumAttachTime, '
          ||' NVL(min(decode(callResult,1, (select min(attachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.attachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, attachTime, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, detachTime, 0)) sumDetachTime, '
          ||' NVL(min(decode(callResult,1, (select min(detachTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.detachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, detachTime, 0)) maxDetachTime, '

          ||' sum(decode(callResult, 1, activationTime, 0)) sumActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, activationTime, 0)) maxActivationTime, '
          
          ||' sum(decode(callResult, 1, deActivationTime, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(deActivationTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.deActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, deActivationTime, 0)) maxDeActivationTime, '
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumDelay , 0 MinDelay , 0 MaxDelay , '
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , '--0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

          
       elsif (c_testCode=3040) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          ||' sum(decode(callResult, 1, activationTime, 0)) sumActivationTime, '---主叫LTE附着总时延
          ||' NVL(min(decode(callResult,1, (select min(activationTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.activationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, activationTime, 0)) maxActivationTime, '
          ||' sum(decode(callResult, 1, operateTime, 0)) sumOperateTime, ' ---主叫IMS登陆时延
          ||' NVL(min(decode(callResult,1, (select min(operateTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.operateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, operateTime, 0)) maxOperateTime, '
          ||' sum(decode(callResult, 1, responseTime, 0)) sumDelay, '----振铃时延
          ||' NVL(min(decode(callResult,1, (select min(responseTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.responseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, responseTime, 0)) MaxDelay, '
          ||' sum(decode(callResult, 1, deActivationTime, 0)) sumDeActivationTime, '---主叫LTE去附着时延
          ||' NVL(min(decode(callResult,1, (select min(deActivationTime) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.deActivationTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, deActivationTime, 0)) maxDeActivationTime, '

          ||' sum(decode(callResult, 1, mindelay, 0)) sunDnsTime, '---彩印
          ||' NVL(min(decode(callResult,1, (select min(mindelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.mindelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, mindelay, 0)) maxDnsTime, '
          
          
          ||' sum(decode(callResult, 1, maxDelay, 0)) sumAttachTime, '---彩印
          ||' NVL(min(decode(callResult,1, (select min(maxDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.maxDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, maxDelay, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, times, 0)) sumDetachTime, '---彩印
          ||' NVL(min(decode(callResult,1, (select min(times) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, times, 0)) maxDetachTime, '
 
        ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , 0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
      elsif (c_testCode=3041) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          ||' sum(decode(callResult, 1, ATTACHDELAY_D, 0)) sumActivationTime, '---附着时延
          ||' NVL(min(decode(callResult,1, (select min(ATTACHDELAY_D) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.ATTACHDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, ATTACHDELAY_D, 0)) maxActivationTime, '
         
          ||' sum(decode(callResult, 1, DEFBEAERDELAY_D, 0)) sumOperateTime, ' ---承载建立
          ||' NVL(min(decode(callResult,1, (select min(DEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DEFBEAERDELAY_D, 0)) maxOperateTime, '
          
          ||' sum(decode(callResult, 1, SMSTIME_D, 0)) sumDelay, '----MT
          ||' NVL(min(decode(callResult,1, (select min(SMSTIME_D) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.SMSTIME_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, SMSTIME_D, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, VDEFBEAERDELAY_D, 0)) sunDnsTime, '----VoLTE默认承载建立
          ||' NVL(min(decode(callResult,1, (select min(VDEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.VDEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, VDEFBEAERDELAY_D, 0)) maxDnsTime, '
          
          ||' sum(decode(callResult, 1, REGISTERDELAY_D, 0)) sumAttachTime, '----MS登陆
          ||' NVL(min(decode(callResult,1, (select min(REGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.REGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, REGISTERDELAY_D, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, DEGISTERDELAY_D, 0)) sumDetachTime, '----IMS注销
          ||' NVL(min(decode(callResult,1, (select min(DEGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DEGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, DEGISTERDELAY_D, 0)) maxDetachTime, '
          
          ||' sum(decode(callResult, 1, DETTACHDELAY_D, 0)) sumDeActivationTime, '---主叫LTE去附着时延
          ||' NVL(min(decode(callResult,1, (select min(DETTACHDELAY_D) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DETTACHDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, DETTACHDELAY_D, 0)) maxDeActivationTime, '


         ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , 0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
          
       elsif (c_testCode=3042) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(testResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          ||' sum(decode(callResult, 1, ATTACHDELAY_R, 0)) sumActivationTime, '---附着时延
          ||' NVL(min(decode(callResult,1, (select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, ATTACHDELAY_R, 0)) maxActivationTime, '
         
          ||' sum(decode(callResult, 1, DEFBEAERDELAY_R, 0)) sumOperateTime, ' ---承载建立
          ||' NVL(min(decode(callResult,1, (select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, DEFBEAERDELAY_R, 0)) maxOperateTime, '
          
          ||' sum(decode(callResult, 1, SMSTIME_R, 0)) sumDelay, '----MT
          ||' NVL(min(decode(callResult,1, (select min(SMSTIME_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.SMSTIME_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, SMSTIME_R, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, VDEFBEAERDELAY_R, 0)) sunDnsTime, '----VoLTE默认承载建立
          ||' NVL(min(decode(callResult,1, (select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(callResult, 1, VDEFBEAERDELAY_R, 0)) maxDnsTime, '
          
          ||' sum(decode(callResult, 1, REGISTERDELAY_R, 0)) sumAttachTime, '----MS登陆
          ||' NVL(min(decode(callResult,1, (select min(REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.REGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, REGISTERDELAY_R, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, DEGISTERDELAY_R, 0)) sumDetachTime, '----IMS注销
          ||' NVL(min(decode(callResult,1, (select min(DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DEGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, DEGISTERDELAY_R, 0)) maxDetachTime, '
          
          ||' sum(decode(callResult, 1, DETTACHDELAY_R, 0)) sumDeActivationTime, '---主叫LTE去附着时延
          ||' NVL(min(decode(callResult,1, (select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, DETTACHDELAY_R, 0)) maxDeActivationTime, '

          ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , 0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
    elsif (c_testCode=3071 or c_testCode=3072) then
        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 0, 1, 0)) FailureCount, '
                   ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(HOMEDIARESULT_R, 1, 1, 0)) AcrossCount, '--提交
          ||' sum(decode(callResult, 1, times, 0)) sumDelay, '--提交
          ||' NVL(min(decode(callResult,1,(select min(times) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.times>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(callResult, 1, times, 0)) MaxDelay, '
          
          ||' sum(decode(callResult, 1, totalTime, 0)) RSumDelay, '--全程
          ||' NVL(min(decode(callResult,1,(select min(totalTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.totalTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(callResult, 1, totalTime, 0)) RMaxDelay, '

          ||' sum(decode(callResult, 1, responseTime, 0)) sumOperateTime, '--现网时延
          ||' NVL(min(decode(callResult,1,(select min(responseTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.responseTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(callResult, 1, responseTime, 0)) maxOperateTime, '
          
          ||' sum(decode(DEFBEAERRESULT_R,1, 1, 0)) defbeaerCount_r, '--主叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) sumDefbeaerDelay_r, '--主叫默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_r , '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) maxDefbeaerDelay_r , '--主叫默认承载建立时延
         
          ||' sum(decode(VDEFBEAERDELAY_R,1,1, 0)) vdefbeaerCount_r, '--主叫IMS 默认承载
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sumVdefbeaerDelay_r, '--主叫IMS 默认承载时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_r , '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) maxVdefbeaerDelay_r , '--主叫IMS 默认承载时延
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_r, '--主叫IMS登陆   
          ||' sum(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) sumRegisterDelay_r, '--主叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(zt.REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_r, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) maxRegisterDelay_r , '--主叫IMS登陆
          
          ||' sum(decode(ATTACHRESULT_R,1,1, 0)) NoiseCount, ' 
          ||' sum(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) sumAttachTime, '--附着时延
          ||' NVL(min(decode(ATTACHRESULT_R,1,(select min(ATTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.ATTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(ATTACHRESULT_R, 1, ATTACHDELAY_R, 0)) maxAttachTime, '--附着时延   
         
          ||' sum(decode(DETTACHRESULT_R,1,1, 0)) RightCount, '
          ||' sum(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) sumDetachTime, '--LTE去附着总时延
          ||' NVL(min(decode(DETTACHRESULT_R,1,(select min(DETTACHDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DETTACHDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime , '
          ||' max(decode(DETTACHRESULT_R, 1, DETTACHDELAY_R, 0)) maxDetachTime , '--LTE去附着总时延
          
          
          
        --  ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
       --   ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
        -- ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '
          
          || ' 0 sunDnsTime ,0 maxDnsTime ,0 minDnsTime, '
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          --||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          --||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '

          ||' 0 ErrCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount ,'
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, 0 MonoDirectionCount,0 BreakLineCount,'
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';


     /*elsif (c_testCode=3701 or c_testCode=3704) then
          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          ||' sum(decode(testResult, 1, decode(callResult,4,1,8,1,0), 0)) MonoDirectionCount, ' --单通次数
          ||' sum(decode(testResult, 1, decode(callResult,3,1,0), 0)) AcrossCount, ' --串话次数
          ||' sum(decode(testResult, 1, decode(callResult,5,1,0), 0)) SilCount, ' --无声音
          ||' sum(decode(testResult, 1, decode(callResult,2,1,0), 0)) NoiseCount, '--回声
         
          ||' sum(decode(VOLTECALLRESULT_R,1, 1, 0)) ShortCRCount, '--呼叫建立
          ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumBreakLine, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(zt.VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) maxBreakLine, '--呼叫建立时延
          
          ||' sum(decode(VOLTECANCELRESULT_R,1, 1, 0)) RightCount, '--话音挂机
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumDelay, '--话音挂机时延
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(zt.VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) MaxDelay, '--话音挂机时延
          
          ||' sum(decode(DEFBEAERRESULT_R,1, 1, 0)) defbeaerCount_r, '--主叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) sumDefbeaerDelay_r, '--主叫默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(zt.DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_r , '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) maxDefbeaerDelay_r , '--主叫默认承载建立时延
         
   
          ||' sum(decode(VDEFBEAERRESULT_R,1,1, 0)) vdefbeaerCount_r, '--主叫IMS 默认承载
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sumVdefbeaerDelay_r, '--主叫IMS 默认承载时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(zt.VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_r , '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) maxVdefbeaerDelay_r , '--主叫IMS 默认承载时延
         
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) dedbeaerCount_r, '--VoLTE语音专用承载建立   
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumDedbeaerDelay_r, '--VoLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(zt.DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_r, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) maxDedbeaerDelay_r , '--VoLTE语音专用承载建立时延

          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_r, '--主叫IMS登陆   
          ||' sum(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) sumRegisterDelay_r, '--主叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(zt.REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.REGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_r, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) maxRegisterDelay_r , '--主叫IMS登陆
         
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) degisterCount_r, '--主叫IMS注销
          ||' sum(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0)) sumDegisterDelay_r, '--主叫IMS注销
          ||' NVL(min(decode(DEGISTERESULT_R,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_r, '
          ||' max(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0))  maxDegisterDelay_r , '--主叫IMS注销
          
         
          --被叫--
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) defbeaerCount_d, '--被叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) sumDefbeaerDelay_d, '---被叫默认承载建立
          ||' NVL(min(decode(DEFBEAERRESULT_D,1,(select min(zt.DEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_d, '
          ||' max(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) maxDefbeaerDelay_d, '---被叫默认承载建立
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) vdefbeaerCount_d, '--被叫IMS默认承载建立
          ||' sum(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0)) sumVdefbeaerDelay_d, '--被叫IMS默认承载建立
          ||' NVL(min(decode(VDEFBEAERRESULT_D,1,(select min(zt.VDEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_d, '
          ||' max(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0))  maxVdefbeaerDelay_d , '--被叫IMS默认承载建立
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) dedbeaerCount_d, '--被叫VoLTE语音专用承载
          ||' sum(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0)) sumDedbeaerDelay_d, '--被叫VoLTE语音专用承载
          ||' NVL(min(decode(DEDBEAERRESULT_D,1,(select min(zt.DEDBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_d, '
          ||' max(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0))  maxDedbeaerDelay_d , '--被叫VoLTE语音专用承载
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_d, '--被叫IMS登陆
          ||' sum(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0)) sumRegisterDelay_d, '--被叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_D,1,(select min(zt.REGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_d, '
          ||' max(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0))  maxRegisterDelay_d , '--被叫IMS登陆
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) degisterCount_d, '--被叫IMS注销
          ||' sum(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0)) sumDegisterDelay_d, '--被叫IMS注销
          ||' NVL(min(decode(DEGISTERESULT_D,1,(select min(zt.DEGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_d, '
          ||' max(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0))  maxDegisterDelay_d , '--被叫IMS注销
          
          
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 ErrCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 BreakLineCount ';
          
      elsif (c_testCode=3703 or c_testCode=3706) then
          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          
          ||' sum(decode(VOLTECALLRESULT_R,1, 1, 0)) ShortCRCount, '--呼叫建立
          ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumBreakLine, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) maxBreakLine, '--呼叫建立时延
          
          ||' sum(decode(VOLTECANCELRESULT_R,1, 1, 0)) RightCount, '--话音挂机
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumDelay, '--话音挂机时延
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) MaxDelay, '--话音挂机时延
          
          ||' sum(decode(DEFBEAERRESULT_R,1, 1, 0)) defbeaerCount_r, '--主叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) sumDefbeaerDelay_r, '--主叫默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_r , '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) maxDefbeaerDelay_r , '--主叫默认承载建立时延
         
   
          ||' sum(decode(VDEFBEAERRESULT_R,1,1, 0)) vdefbeaerCount_r, '--主叫IMS 默认承载
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sumVdefbeaerDelay_r, '--主叫IMS 默认承载时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_r , '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) maxVdefbeaerDelay_r , '--主叫IMS 默认承载时延
         
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) dedbeaerCount_r, '--VoLTE语音专用承载建立   
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumDedbeaerDelay_r, '--VoLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(zt.DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_r, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) maxDedbeaerDelay_r , '--VoLTE语音专用承载建立时延

          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_r, '--主叫IMS登陆   
          ||' sum(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) sumRegisterDelay_r, '--主叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(zt.REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_r, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) maxRegisterDelay_r , '--主叫IMS登陆
         
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) degisterCount_r, '--主叫IMS注销
          ||' sum(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0)) sumDegisterDelay_r, '--主叫IMS注销
          ||' NVL(min(decode(DEGISTERESULT_R,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_r, '
          ||' max(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0))  maxDegisterDelay_r , '--主叫IMS注销
          
         
          --被叫--
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) defbeaerCount_d, '--被叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) sumDefbeaerDelay_d, '---被叫默认承载建立
          ||' NVL(min(decode(DEFBEAERRESULT_D,1,(select min(DEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_d, '
          ||' max(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) maxDefbeaerDelay_d, '---被叫默认承载建立
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) vdefbeaerCount_d, '--被叫IMS默认承载建立
          ||' sum(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0)) sumVdefbeaerDelay_d, '--被叫IMS默认承载建立
          ||' NVL(min(decode(VDEFBEAERRESULT_D,1,(select min(VDEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_d, '
          ||' max(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0))  maxVdefbeaerDelay_d , '--被叫IMS默认承载建立
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) dedbeaerCount_d, '--被叫VoLTE语音专用承载
          ||' sum(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0)) sumDedbeaerDelay_d, '--被叫VoLTE语音专用承载
          ||' NVL(min(decode(DEDBEAERRESULT_D,1,(select min(DEDBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_d, '
          ||' max(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0))  maxDedbeaerDelay_d , '--被叫VoLTE语音专用承载
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_d, '--被叫IMS登陆
          ||' sum(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0)) sumRegisterDelay_d, '--被叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_D,1,(select min(REGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_d, '
          ||' max(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0))  maxRegisterDelay_d , '--被叫IMS登陆
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) degisterCount_d, '--被叫IMS注销
          ||' sum(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0)) sumDegisterDelay_d, '--被叫IMS注销
          ||' NVL(min(decode(DEGISTERESULT_D,1,(select min(zt.DEGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_d, '
          ||' max(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0))  maxDegisterDelay_d , '--被叫IMS注销
          
     
          ||' sum(decode(callResult, 1, CallerValue, 0)) sumDetachTime, '--mos
          ||' NVL(min(decode(callResult,1,(select min(zt.CallerValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.CallerValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, CallerValue, 0))  maxDetachTime , '--mos
          ||' sum(decode(callResult, 1, CalledValue, 0)) sumAttachTime, '--mos
          ||' NVL(min(decode(callResult,1,(select min(zt.CalledValue) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.CalledValue>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, CalledValue, 0))  maxAttachTime , '--mos
          
          ||' 0 MonoDirectionCount, 0 AcrossCount,0 SilCount ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 NoiseCount, 0 ErrCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 BreakLineCount ';
          
      elsif (c_testCode=3702 or c_testCode=3705) then
          tmp := ' sum(decode(callResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(callResult, 1, 0, 1)) FailureCount, '
          
          ||' sum(decode(VOLTECALLRESULT_R,1, 1, 0)) ShortCRCount, '--呼叫建立
          ||' sum(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) sumBreakLine, '--呼叫建立时延
          ||' NVL(min(decode(VOLTECALLRESULT_R,1,(select min(zt.VOLTECALLDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECALLDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minBreakLine, '
          ||' max(decode(VOLTECALLRESULT_R, 1, VOLTECALLDELAY_R, 0)) maxBreakLine, '--呼叫建立时延
          
          ||' sum(decode(VOLTECANCELRESULT_R,1, 1, 0)) RightCount, '--话音挂机
          ||' sum(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) sumDelay, '--话音挂机时延
          ||' NVL(min(decode(VOLTECANCELRESULT_R,1,(select min(zt.VOLTECANCELDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VOLTECANCELDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(VOLTECANCELRESULT_R, 1, VOLTECANCELDELAY_R, 0)) MaxDelay, '--话音挂机时延
          
          ||' sum(decode(DEFBEAERRESULT_R,1, 1, 0)) defbeaerCount_r, '--主叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) sumDefbeaerDelay_r, '--主叫默认承载建立时延
          ||' NVL(min(decode(DEFBEAERRESULT_R,1,(select min(zt.DEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_r , '
          ||' max(decode(DEFBEAERRESULT_R, 1, DEFBEAERDELAY_R, 0)) maxDefbeaerDelay_r , '--主叫默认承载建立时延
         
   
          ||' sum(decode(VDEFBEAERRESULT_R,1,1, 0)) vdefbeaerCount_r, '--主叫IMS 默认承载
          ||' sum(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) sumVdefbeaerDelay_r, '--主叫IMS 默认承载时延
          ||' NVL(min(decode(VDEFBEAERRESULT_R,1,(select min(zt.VDEFBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_r , '
          ||' max(decode(VDEFBEAERRESULT_R, 1, VDEFBEAERDELAY_R, 0)) maxVdefbeaerDelay_r , '--主叫IMS 默认承载时延
         
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) dedbeaerCount_r, '--VoLTE语音专用承载建立   
          ||' sum(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) sumDedbeaerDelay_r, '--VoLTE语音专用承载建立时延
          ||' NVL(min(decode(DEDBEAERRESULT_R,1,(select min(zt.DEDBEAERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_r, '
          ||' max(decode(DEDBEAERRESULT_R, 1, DEDBEAERDELAY_R, 0)) maxDedbeaerDelay_r , '--VoLTE语音专用承载建立时延

          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_r, '--主叫IMS登陆   
          ||' sum(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) sumRegisterDelay_r, '--主叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_R,1,(select min(zt.REGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_R>0   and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_r, '
          ||' max(decode(REGISTERESULT_R, 1, REGISTERDELAY_R, 0)) maxRegisterDelay_r , '--主叫IMS登陆
         
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) degisterCount_r, '--主叫IMS注销
          ||' sum(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0)) sumDegisterDelay_r, '--主叫IMS注销
          ||' NVL(min(decode(DEGISTERESULT_R,1,(select min(zt.DEGISTERDELAY_R) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEGISTERDELAY_R>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_r, '
          ||' max(decode(DEGISTERESULT_R, 1, DEGISTERDELAY_R, 0))  maxDegisterDelay_r , '--主叫IMS注销
          
         
          --被叫--
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) defbeaerCount_d, '--被叫默认承载建立
          ||' sum(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) sumDefbeaerDelay_d, '---被叫默认承载建立
          ||' NVL(min(decode(DEFBEAERRESULT_D,1,(select min(DEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDefbeaerDelay_d, '
          ||' max(decode(DEFBEAERRESULT_D, 1, DEFBEAERDELAY_D, 0)) maxDefbeaerDelay_d, '---被叫默认承载建立
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) vdefbeaerCount_d, '--被叫IMS默认承载建立
          ||' sum(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0)) sumVdefbeaerDelay_d, '--被叫IMS默认承载建立
          ||' NVL(min(decode(VDEFBEAERRESULT_D,1,(select min(VDEFBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.VDEFBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minVdefbeaerDelay_d, '
          ||' max(decode(VDEFBEAERRESULT_D, 1, VDEFBEAERDELAY_D, 0))  maxVdefbeaerDelay_d , '--被叫IMS默认承载建立
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) dedbeaerCount_d, '--被叫VoLTE语音专用承载
          ||' sum(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0)) sumDedbeaerDelay_d, '--被叫VoLTE语音专用承载
          ||' NVL(min(decode(DEDBEAERRESULT_D,1,(select min(DEDBEAERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.DEDBEAERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDedbeaerDelay_d, '
          ||' max(decode(DEDBEAERRESULT_D, 1, DEDBEAERDELAY_D, 0))  maxDedbeaerDelay_d , '--被叫VoLTE语音专用承载
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) registerCount_d, '--被叫IMS登陆
          ||' sum(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0)) sumRegisterDelay_d, '--被叫IMS登陆
          ||' NVL(min(decode(REGISTERESULT_D,1,(select min(REGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.REGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minRegisterDelay_d, '
          ||' max(decode(REGISTERESULT_D, 1, REGISTERDELAY_D, 0))  maxRegisterDelay_d , '--被叫IMS登陆
          
          ||' sum(decode(DEDBEAERRESULT_R, 1, 0)) degisterCount_d, '--被叫IMS注销
          ||' sum(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0)) sumDegisterDelay_d, '--被叫IMS注销
          ||' NVL(min(decode(DEGISTERESULT_D,1,(select min(zt.DEGISTERDELAY_D) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.DEGISTERDELAY_D>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDegisterDelay_d, '
          ||' max(decode(DEGISTERESULT_D, 1, DEGISTERDELAY_D, 0))  maxDegisterDelay_d , '--被叫IMS注销
          
     
          ||' sum(decode(callResult, 1, AvgDelay, 0)) sumDetachTime, '--时延
          ||' NVL(min(decode(callResult,1,(select min(zt.AvgDelay) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.AvgDelay>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, AvgDelay, 0))  maxDetachTime , '--时延
          ||' sum(decode(callResult, 1, BreakLine, 0)) sumAttachTime, '--抖动
          ||' NVL(min(decode(callResult,1,(select min(zt.BreakLine) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.BreakLine>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, BreakLine, 0))  maxAttachTime , '--抖动
          
          ||' 0 MonoDirectionCount, 0 AcrossCount,0 SilCount ,'
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 NoiseCount, 0 ErrCount, 0 NonBeginCRCount, '
          ||' 0 NotSPCount , 0 RSumDelay , 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 BreakLineCount ';
          */
     elsif (c_testCode=6001 or c_testcode=6002  or c_testCode=6003  or c_testCode=6004 or c_testCode=6005  or c_testCode=6006  or c_testCode=6007  or c_testCode=6008  or c_testCode=6009) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          
          ||' sum(decode(callResult, 1, dnstime, 0)) sumAttachTime, '
          ||' NVL(min(decode(callResult,1, (select min(dnstime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.dnstime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(callResult, 1, dnstime, 0)) maxAttachTime, '
          
          ||' sum(decode(callResult, 1, t1.duration, 0)) sumDetachTime, '
          ||' NVL(min(decode(callResult,1, (select min(t1.duration) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.DURATION>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(callResult, 1, t1.duration, 0)) maxDetachTime, '

          ||' sum(decode(callResult, 1, receivetime, 0)) sumActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(receivetime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1    and zt.receivetime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(callResult, 1, receivetime, 0)) maxActivationTime, '
          
          ||' sum(decode(callResult, 1, Sockettimeall, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(callResult,1, (select min(Sockettimeall) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1   and zt.Sockettimeall>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(callResult, 1, Sockettimeall, 0)) maxDeActivationTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '



          ||' 0 sumDelay , 0 MinDelay , 0 MaxDelay , '
          ||' 0 sunDnsTime , 0 maxDnsTime , 0 minDnsTime ,'
          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 AcrossCount, 0  ShortCRCount, 0 SilCount ,0 NotSPCount,'
          ||' 0 ErrCount, 0 MonoDirectionCount , 0 BreakLineCount ,0 RightCount ,0 NoiseCount , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';
          
          
      elsif (c_testCode=7003 or c_testcode=7005  or c_testCode=7013  or c_testCode=7014 or c_testCode=7015) then
         tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, ' 
          
          ||' sum(decode(attachResult_r, 1, 1, 0)) AcrossCount, '--附着
          ||' sum(decode(attachResult_r, 1, attachDelay_r, 0)) sumAttachTime, '
          ||' NVL(min(decode(attachResult_r,1, (select min(attachDelay_r) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1  and zt.attachDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minAttachTime, '
          ||' max(decode(attachResult_r, 1, attachDelay_r, 0)) maxAttachTime, '
          
          
          ||' sum(decode(defbeaerResult_r, 1, 1, 0)) ShortCRCount, '--默认承载建立
          ||' sum(decode(defbeaerResult_r, 1, t1.defbeaerDelay_r, 0)) sumDetachTime, '
          ||' NVL(min(decode(defbeaerResult_r,1, (select min(t1.defbeaerDelay_r) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1   and zt.defbeaerDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDetachTime, '
          ||' max(decode(defbeaerResult_r, 1, t1.defbeaerDelay_r, 0)) maxDetachTime, '

          ||' sum(decode(vdefbeaerResult_r, 1, 1, 0)) SilCount, '--VoLTE IMS默认承载
          ||' sum(decode(vdefbeaerResult_r, 1, vdefbeaerDelay_r, 0)) sumActivationTime, '
          ||' NVL(min(decode(vdefbeaerResult_r,1, (select min(vdefbeaerDelay_r) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1   and zt.vdefbeaerDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minActivationTime, '
          ||' max(decode(vdefbeaerResult_r, 1, vdefbeaerDelay_r, 0)) maxActivationTime, '
          
          
          ||' sum(decode(REGISTERESULT_R, 1, 1, 0)) NotSPCount, '--VoLTE IMS登录
          ||' sum(decode(REGISTERESULT_R, 1, registerDelay_r, 0)) sumDeActivationTime, '
          ||' NVL(min(decode(REGISTERESULT_R,1, (select min(registerDelay_r) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1   and zt.registerDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDeActivationTime, '
          ||' max(decode(REGISTERESULT_R, 1, registerDelay_r, 0)) maxDeActivationTime, '


          ||' sum(decode(volteCallResult_r, 1, 1, 0)) ErrCount, '--VVoLTE呼叫---
          ||' sum(decode(volteCallResult_r, 1, volteCallDelay_r, 0)) sumDelay, '
          ||' NVL(min(decode(volteCallResult_r,1, (select min(volteCallDelay_r) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1   and zt.volteCallDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(volteCallResult_r, 1, volteCallDelay_r, 0)) MaxDelay, '
          
          
          ||' sum(decode(volteCancelResult_r, 1, 1, 0)) RightCount, '--VVoLTE呼叫
          ||' sum(decode(volteCancelResult_r, 1, volteCancelDelay_r, 0)) sunDnsTime, '
          ||' NVL(min(decode(volteCancelResult_r,1, (select min(volteCancelDelay_r) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1    and zt.volteCancelDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(volteCancelResult_r, 1, volteCancelDelay_r, 0)) maxDnsTime, '
          
          
          ||' sum(decode(DEGISTERESULT_R, 1, 1, 0)) NoiseCount, '--VoLTE IMS注销
          ||' sum(decode(DEGISTERESULT_R, 1, degisterDelay_r, 0)) sumOperateTime, '
          ||' NVL(min(decode(DEGISTERESULT_R,1, (select min(degisterDelay_r) from z_testresult zt where zt.taskid=t2.taskid  and zt.callResult=1   and zt.degisterDelay_r>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minOperateTime, '
          ||' max(decode(DEGISTERESULT_R, 1, degisterDelay_r, 0)) maxOperateTime, '
          
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '

          
          
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 MonoDirectionCount , 0 BreakLineCount  , 0 NonBeginCRCount ,'
          ||' 0 RSuccessCount, 0 RSumDelay, 0 RMinDelay, 0 RMaxDelay, '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine ';

       elsif (c_testCode=4001 or c_testCode=4002  or c_testCode=4003 or c_testCode=4004 or c_testCode=4005 or c_testCode=4006 or c_testCode=4007 or c_testCode=4008) then

        tmp := ' sum(decode(testResult, 1, 1, 0)) test_Success_Count_, '
          ||' sum(decode(callResult, 1, 1, 0)) SuccessCount, '--成功次数
          ||' sum(decode(callResult, 1, 1, 0)) RSuccessCount, '
          ||' sum(decode(testResult, 0, 1, 0)) FailureCount, '--失败次数
          ||' sum(decode(testResult, 1, AttachTime, 0)) sumDelay, '--平均业务时延
          ||' NVL(min(decode(testResult,1, (select min(AttachTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.AttachTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) MinDelay, '
          ||' max(decode(testResult, 1, AttachTime, 0)) MaxDelay, '--最大业务时延
          ||' sum(decode(testResult, 1, OperateTime, 0)) sunDnsTime, '--平均登陆时延
          ||' NVL(min(decode(testResult,1, (select min(OperateTime) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1 and zt.OperateTime>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) minDnsTime, '
          ||' max(decode(testResult, 1, OperateTime, 0)) maxDnsTime, '--最大登陆时延
          ||' sum(decode(testResult, 1, RESPONSETIME, 0)) RSumDelay, '--平均消息发送时
          ||' NVL(min(decode(testResult,1, (select min(RESPONSETIME) from z_testresult zt where zt.taskid=t2.taskid and zt.callResult=1  and zt.RESPONSETIME>0  and zt.startTime between to_date('''||c_startDate||''',''yyyy-mm-dd hh24:mi:ss'') and to_date('''||c_endDate||''',''yyyy-mm-dd hh24:mi:ss'')), null)), 0) RMinDelay, '
          ||' max(decode(testResult, 1, RESPONSETIME, 0)) RMaxDelay, '--最大消息发送时
          
           ||' 0 defbeaerCount_r , 0 maxDefbeaerDelay_r  , 0 minDefbeaerDelay_r  , 0  sumDefbeaerDelay_r  , '
         ||' 0 vdefbeaerCount_r  , 0 maxVdefbeaerDelay_r  , 0 minVdefbeaerDelay_r  , 0  sumVdefbeaerDelay_r  , '
         ||' 0 dedbeaerCount_r  , 0 maxDedbeaerDelay_r  , 0 minDedbeaerDelay_r  , 0  sumDedbeaerDelay_r  , '
         ||' 0 registerCount_r  , 0 maxRegisterDelay_r  , 0 minRegisterDelay_r  , 0  sumRegisterDelay_r  , '
         ||' 0 degisterCount_r  , 0 maxDegisterDelay_r  , 0 minDegisterDelay_r  , 0  sumDegisterDelay_r  , '
         ||' 0 defbeaerCount_d , 0 maxDefbeaerDelay_d , 0 minDefbeaerDelay_d , 0  sumDefbeaerDelay_d , '
         ||' 0 vdefbeaerCount_d , 0 maxVdefbeaerDelay_d , 0 minVdefbeaerDelay_d , 0  sumVdefbeaerDelay_d , '
         ||' 0 dedbeaerCount_d , 0 maxDedbeaerDelay_d , 0 minDedbeaerDelay_d , 0  sumDedbeaerDelay_d , '
         ||' 0 registerCount_d , 0 maxRegisterDelay_d , 0 minRegisterDelay_d , 0  sumRegisterDelay_d , '
         ||' 0 degisterCount_d , 0 maxDegisterDelay_d , 0 minDegisterDelay_d , 0  sumDegisterDelay_d , '


          ||' 0 sumOperateTime , 0 maxOperateTime , 0 minOperateTime ,'
          ||' 0 sumReceivetime , 0 maxReceivetime , 0 minReceivetime ,'
          ||' 0 sumDeActivationTime ,0 maxDeActivationTime , 0 minDeActivationTime , '
          ||' 0 sumActivationTime , 0 maxActivationTime , 0  minActivationTime ,'
          ||' 0 sumDetachTime , 0 maxDetachTime , 0 minDetachTime , '
          ||' 0 sumAttachTime , 0 maxAttachTime , 0 minAttachTime , '
          ||' 0 AcrossCount, 0 NoiseCount, 0 ErrCount, 0 RightCount, 0 ShortCRCount, 0 NonBeginCRCount, '
          ||' 0 SilCount, 0 NotSPCount , '
          ||' 0 sumErrPacketRate, 0 minErrPacketRate, 0 maxErrPacketRate, '
          ||' 0 sumBreakLine, 0 minBreakLine, 0 maxBreakLine , 0 MonoDirectionCount, 0 BreakLineCount ';
       -------------------------app stat  end----------------------------
    end if;
        if length(tmp)>0 then
      if (c_testCode=421 or c_testCode=810 or c_testCode=212) then --语音MOS测试 --20101230 Zhou.WeiFei 主被叫MOS平均值修改
 sqlstr := ' insert into Z_TaskStatXXXXXXXXXX(taskid,testCode,statDate,CallCount,SuccessCount,'
            ||' FailureCount,sumDelay,MinDelay,MaxDelay,MonoDirectionCount,BreakLineCount,'
            ||' Acrosscount,Noisecount,Errcount,Rightcount,ShortCRcount,NonBeginCRcount,Silcount,'
            ||' NotSPcount,SuccessRate,FailureRate,AveCount,AveDelay,MonoDirectionRate,BreakLineRate,'
            ||' RightRate,ShortCRRate,NonBeginCRRate,AcrossRate,NoiseRate,ErrRate,SilRate,NotSPRate,'
            ||' RSuccessCount,RSumDelay,RMinDelay,RMaxDelay,RSuccessRate,TRSuccessRate,RAveDelay,'
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,aveErrPacketRate,'
           -- ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine )'
            ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine ,'
            -----------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime,aveDnsTime ,'
            ||' sumOperateTime,maxOperateTime,minOperateTime,aveOperateTime,'
            ||' sumReceivetime,maxReceivetime,minReceivetime, aveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,aveDetachTime, '
            ||' sumAttachTime,maxAttachTime,minAttachTime ,aveAttachTime, '
            
             ||' defbeaerCount_r,defbeaerRate_r,maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,aveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,vdefbeaerRate_r,maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,aveVdefbeaerDelay_r,  '
             ||' dedbeaerCount_r,dedbeaerRate_r,maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,aveDedbeaerDelay_r ,'  
             ||' registerCount_r,registerRate_r,maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,aveRegisterDelay_r, '
             ||' degisterCount_r,degisterRate_r,maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,aveDegisterDelay_r,'
             ||' defbeaerCount_d,defbeaerRate_d,maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,aveDefbeaerDelay_d,'
             ||' vdefbeaerCount_d,vdefbeaerRate_d,maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,aveVdefbeaerDelay_d,'
             ||' dedbeaerCount_d,dedbeaerRate_d,maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,aveDedbeaerDelay_d,'
             ||' registerCount_d,registerRate_d,maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,aveRegisterDelay_d,'
             ||' degisterCount_d,degisterRate_d,maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,aveDegisterDelay_d  '
             
            ||' )'
            ---------------------------------------------
            ||' select taskID, testCode, stat_date, CallCount,'
            ||' SuccessCount, FailureCount, sumDelay, MinDelay,'
            ||' MaxDelay, MonoDirectionCount, BreakLineCount, AcrossCount, NoiseCount, ErrCount, '
            ||' RightCount, ShortCRCount, NonBeginCRCount, SilCount, NotSPCount, '
            ||' decode(CallCount,0,0,SuccessCount*100/CallCount) SuccessRate, '
            ||' decode(CallCount,0,0,FailureCount*100/CallCount) FailureRate, SuccessCount AveCount, '
            ||' decode(test_Success_Count_,0,0,sumDelay/test_Success_Count_) AveDelay, '
            ||' decode(CallCount,0,0,MonoDirectionCount*100/CallCount) MonoDirectionRate, '
            ||' decode(CallCount,0,0,BreakLineCount*100/CallCount) BreakLineRate, '
            ||' decode(CallCount,0,0,RightCount*100/CallCount) RightRate, '
            ||' decode(CallCount,0,0,ShortCRCount*100/CallCount) ShortCRRate, '
            ||' decode(CallCount,0,0,NonBeginCRCount*100/CallCount) NonBeginCRRate, '
            ||' decode(CallCount,0,0,AcrossCount*100/CallCount) AcrossRate, '
            ||' decode(CallCount,0,0,NoiseCount*100/CallCount) NoiseRate, '
            ||' decode(CallCount,0,0,ErrCount*100/CallCount) ErrRate, '
            ||' decode(CallCount,0,0,SilCount*100/CallCount) SilRate, '
            ||' decode(CallCount,0,0,NotSPCount*100/CallCount) NotSPRate, '
            ||' RSuccessCount, RSumDelay, RMinDelay, RMaxDelay, '
            ||' decode(test_Success_Count_,0,0,RSuccessCount*100/test_Success_Count_) RSuccessRate, '
            ||' decode(CallCount,0,0,RSuccessCount*100/CallCount) TRSuccessRate, '
            ||' decode(RSuccessCount,0,0,RSumDelay/RSuccessCount) RAveDelay, '
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,decode(SuccessCount,0,0,SumErrPacketRate/SuccessCount) AveErrPacketRate, '
            ||' sumBreakLine,minBreakLine,maxBreakLine,decode(SuccessCount,0,0,SumBreakLine/SuccessCount) AveBreakLine, '
            ------------------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime, decode(test_Success_Count_,0,0,sunDnsTime/test_Success_Count_) AveDnsTime,  '
            ||' sumOperateTime,maxOperateTime,minOperateTime,  decode(test_Success_Count_,0,0,sumOperateTime/test_Success_Count_) AveOperateTime, '
            ||' sumReceivetime,maxReceivetime,minReceivetime, decode(test_Success_Count_,0,0,sumReceivetime/test_Success_Count_) AveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , decode(test_Success_Count_,0,0,sumDeActivationTime/test_Success_Count_) aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, decode(test_Success_Count_,0,0,sumActivationTime/test_Success_Count_) aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,  decode(test_Success_Count_,0,0,sumDetachTime/test_Success_Count_) aveDetachTime,'
            ||' sumAttachTime,maxAttachTime,minAttachTime , decode(test_Success_Count_,0,0,sumAttachTime/test_Success_Count_) aveAttachTime ,'
            
            ||' defbeaerCount_r,decode(CallCount,0,0,defbeaerCount_r*100/CallCount) defbeaerRate_r, '
             ||' maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,decode(test_Success_Count_,0,0,sumDefbeaerDelay_r/test_Success_Count_) AveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,decode(CallCount,0,0,vdefbeaerCount_r*100/CallCount) vdefbeaerRate_r, '
             ||' maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_r/test_Success_Count_) AveVdefbeaerDelay_r, '
             ||' dedbeaerCount_r,decode(CallCount,0,0,dedbeaerCount_r*100/CallCount) dedbeaerRate_r, '
             ||' maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,decode(test_Success_Count_,0,0,sumDedbeaerDelay_r/test_Success_Count_) AveDedbeaerDelay_r, '
             ||' registerCount_r,decode(CallCount,0,0,registerCount_r*100/CallCount) registerRate_r, '
             ||' maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,decode(test_Success_Count_,0,0,sumRegisterDelay_r/test_Success_Count_) AveRegisterDelay_r, '
             ||' degisterCount_r,decode(CallCount,0,0,degisterCount_r*100/CallCount) degisterRate_r, '
             ||' maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,decode(test_Success_Count_,0,0,sumDegisterDelay_r/test_Success_Count_) AveDegisterDelay_r, '
             ||' defbeaerCount_d,decode(CallCount,0,0,defbeaerCount_d*100/CallCount) defbeaerRate_d, '
             ||' maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,decode(test_Success_Count_,0,0,sumDefbeaerDelay_d/test_Success_Count_) AveDefbeaerDelay_d, '
             ||' vdefbeaerCount_d,decode(CallCount,0,0,vdefbeaerCount_d*100/CallCount) vdefbeaerRate_d, '
             ||' maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_d/test_Success_Count_) AveVdefbeaerDelay_d, '
             ||' dedbeaerCount_d,decode(CallCount,0,0,dedbeaerCount_d*100/CallCount) dedbeaerRate_d, '
             ||' maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,decode(test_Success_Count_,0,0,sumDedbeaerDelay_d/test_Success_Count_) AveDedbeaerDelay_d, '
             ||' registerCount_d,decode(CallCount,0,0,registerCount_d*100/CallCount) registerRate_d, '
             ||' maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,decode(test_Success_Count_,0,0,sumRegisterDelay_d/test_Success_Count_) AveRegisterDelay_d, '
             ||' degisterCount_d,decode(CallCount,0,0,degisterCount_d*100/CallCount) degisterRate_d, '
             ||' maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,decode(test_Success_Count_,0,0,sumDegisterDelay_d/test_Success_Count_) AveDegisterDelay_d '
            ||' from ( select t2.taskID taskID, t2.testCode, trunc(t1.StartTime) stat_date, count(t1.ProgID) CallCount, '
                    || tmp ||' from Z_TestResultYYYYYYYYYY t1,Z_Taskinfo t2'
                    ||' where t1.taskID = t2.taskID '
                    ||' and t1.talkStatus <> 99 ' 
                    ||' and t1.testCode = '||c_testCode
                    ||' and t1.StartTime >= to_date(''SSSSDDDD'',''yyyy-mm-dd'')'
                    ||' and t1.StartTime < to_date(''EEEEDDDD'',''yyyy-mm-dd'')'
                    || tmp2
                    ||' group by t2.taskID, t2.testCode, trunc(t1.StartTime)'
            ||' ) a';
       elsif (c_testCode=722) then
    sqlstr := ' insert into Z_TaskStatXXXXXXXXXX(taskid,testCode,statDate,CallCount,SuccessCount,'
            ||' FailureCount,sumDelay,MinDelay,MaxDelay,MonoDirectionCount,BreakLineCount,'
            ||' Acrosscount,Noisecount,Errcount,Rightcount,ShortCRcount,NonBeginCRcount,Silcount,'
            ||' NotSPcount,SuccessRate,FailureRate,AveCount,AveDelay,MonoDirectionRate,BreakLineRate,'
            ||' RightRate,ShortCRRate,NonBeginCRRate,AcrossRate,NoiseRate,ErrRate,SilRate,NotSPRate,'
            ||' RSuccessCount,RSumDelay,RMinDelay,RMaxDelay,RSuccessRate,TRSuccessRate,RAveDelay,'
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,aveErrPacketRate,'
           -- ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine )'
            ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine ,'
            -----------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime,aveDnsTime ,'
            ||' sumOperateTime,maxOperateTime,minOperateTime,aveOperateTime,'
            ||' sumReceivetime,maxReceivetime,minReceivetime, aveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,aveDetachTime, '
            ||' sumAttachTime,maxAttachTime,minAttachTime ,aveAttachTime, '
            
             ||' defbeaerCount_r,defbeaerRate_r,maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,aveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,vdefbeaerRate_r,maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,aveVdefbeaerDelay_r,  '
             ||' dedbeaerCount_r,dedbeaerRate_r,maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,aveDedbeaerDelay_r ,'  
             ||' registerCount_r,registerRate_r,maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,aveRegisterDelay_r, '
             ||' degisterCount_r,degisterRate_r,maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,aveDegisterDelay_r,'
             ||' defbeaerCount_d,defbeaerRate_d,maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,aveDefbeaerDelay_d,'
             ||' vdefbeaerCount_d,vdefbeaerRate_d,maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,aveVdefbeaerDelay_d,'
             ||' dedbeaerCount_d,dedbeaerRate_d,maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,aveDedbeaerDelay_d,'
             ||' registerCount_d,registerRate_d,maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,aveRegisterDelay_d,'
             ||' degisterCount_d,degisterRate_d,maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,aveDegisterDelay_d  '
             
            ||' )'
            ---------------------------------------------
            ||' select taskID, testCode, stat_date, CallCount,'
            ||' SuccessCount, FailureCount, sumDelay, MinDelay,'
            ||' MaxDelay, MonoDirectionCount, BreakLineCount, AcrossCount, NoiseCount, ErrCount, '
            ||' RightCount, ShortCRCount, NonBeginCRCount, SilCount, NotSPCount, '
            ||' decode(CallCount,0,0,SuccessCount*100/CallCount) SuccessRate, '
            ||' decode(CallCount,0,0,FailureCount*100/CallCount) FailureRate, SuccessCount AveCount, '
            ||' decode(test_Success_Count_,0,0,sumDelay/test_Success_Count_) AveDelay, '
            ||' decode(CallCount,0,0,MonoDirectionCount*100/CallCount) MonoDirectionRate, '
            ||' decode(CallCount,0,0,BreakLineCount*100/CallCount) BreakLineRate, '
            ||' decode(CallCount,0,0,RightCount*100/CallCount) RightRate, '
            ||' decode(CallCount,0,0,ShortCRCount*100/CallCount) ShortCRRate, '
            ||' decode(CallCount,0,0,NonBeginCRCount*100/CallCount) NonBeginCRRate, '
            ||' decode(CallCount,0,0,AcrossCount*100/CallCount) AcrossRate, '
            ||' decode(CallCount,0,0,NoiseCount*100/CallCount) NoiseRate, '
            ||' decode(CallCount,0,0,ErrCount*100/CallCount) ErrRate, '
            ||' decode(CallCount,0,0,SilCount*100/CallCount) SilRate, '
            ||' decode(CallCount,0,0,NotSPCount*100/CallCount) NotSPRate, '
            ||' RSuccessCount, RSumDelay, RMinDelay, RMaxDelay, '
            ||' decode(test_Success_Count_,0,0,RSuccessCount*100/test_Success_Count_) RSuccessRate, '
            ||' decode(CallCount,0,0,RSuccessCount*100/CallCount) TRSuccessRate, '
            ||' decode(RSuccessCount,0,0,RSumDelay/RSuccessCount) RAveDelay, '
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,decode(SuccessCount,0,0,SumErrPacketRate/SuccessCount) AveErrPacketRate, '
            ||' sumBreakLine,minBreakLine,maxBreakLine,decode(SuccessCount,0,0,SumBreakLine/SuccessCount) AveBreakLine, '
            ------------------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime, decode(test_Success_Count_,0,0,sunDnsTime/test_Success_Count_) AveDnsTime,  '
            ||' sumOperateTime,maxOperateTime,minOperateTime,  decode(test_Success_Count_,0,0,sumOperateTime/test_Success_Count_) AveOperateTime, '
            ||' sumReceivetime,maxReceivetime,minReceivetime, decode(test_Success_Count_,0,0,sumReceivetime/test_Success_Count_) AveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , decode(test_Success_Count_,0,0,sumDeActivationTime/test_Success_Count_) aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, decode(test_Success_Count_,0,0,sumActivationTime/test_Success_Count_) aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,  decode(test_Success_Count_,0,0,sumDetachTime/test_Success_Count_) aveDetachTime,'
            ||' sumAttachTime,maxAttachTime,minAttachTime , decode(test_Success_Count_,0,0,sumAttachTime/test_Success_Count_) aveAttachTime ,'
            
            ||' defbeaerCount_r,decode(CallCount,0,0,defbeaerCount_r*100/CallCount) defbeaerRate_r, '
             ||' maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,decode(test_Success_Count_,0,0,sumDefbeaerDelay_r/test_Success_Count_) AveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,decode(CallCount,0,0,vdefbeaerCount_r*100/CallCount) vdefbeaerRate_r, '
             ||' maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_r/test_Success_Count_) AveVdefbeaerDelay_r, '
             ||' dedbeaerCount_r,decode(CallCount,0,0,dedbeaerCount_r*100/CallCount) dedbeaerRate_r, '
             ||' maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,decode(test_Success_Count_,0,0,sumDedbeaerDelay_r/test_Success_Count_) AveDedbeaerDelay_r, '
             ||' registerCount_r,decode(CallCount,0,0,registerCount_r*100/CallCount) registerRate_r, '
             ||' maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,decode(test_Success_Count_,0,0,sumRegisterDelay_r/test_Success_Count_) AveRegisterDelay_r, '
             ||' degisterCount_r,decode(CallCount,0,0,degisterCount_r*100/CallCount) degisterRate_r, '
             ||' maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,decode(test_Success_Count_,0,0,sumDegisterDelay_r/test_Success_Count_) AveDegisterDelay_r, '
             ||' defbeaerCount_d,decode(CallCount,0,0,defbeaerCount_d*100/CallCount) defbeaerRate_d, '
             ||' maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,decode(test_Success_Count_,0,0,sumDefbeaerDelay_d/test_Success_Count_) AveDefbeaerDelay_d, '
             ||' vdefbeaerCount_d,decode(CallCount,0,0,vdefbeaerCount_d*100/CallCount) vdefbeaerRate_d, '
             ||' maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_d/test_Success_Count_) AveVdefbeaerDelay_d, '
             ||' dedbeaerCount_d,decode(CallCount,0,0,dedbeaerCount_d*100/CallCount) dedbeaerRate_d, '
             ||' maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,decode(test_Success_Count_,0,0,sumDedbeaerDelay_d/test_Success_Count_) AveDedbeaerDelay_d, '
             ||' registerCount_d,decode(CallCount,0,0,registerCount_d*100/CallCount) registerRate_d, '
             ||' maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,decode(test_Success_Count_,0,0,sumRegisterDelay_d/test_Success_Count_) AveRegisterDelay_d, '
             ||' degisterCount_d,decode(CallCount,0,0,degisterCount_d*100/CallCount) degisterRate_d, '
             ||' maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,decode(test_Success_Count_,0,0,sumDegisterDelay_d/test_Success_Count_) AveDegisterDelay_d '

         
            ||' from ( select t2.taskID taskID, t2.testCode, trunc(t1.StartTime) stat_date, count(t1.ProgID) CallCount, '
                    || tmp ||' from Z_TestResultYYYYYYYYYY t1,Z_Taskinfo t2'
                    ||' where t1.taskID = t2.taskID '
                    ||' and t1.talkStatus <> 99 ' 
                    ||' and t1.testCode = '||c_testCode
                    ||' and t1.StartTime >= to_date(''SSSSDDDD'',''yyyy-mm-dd'')'
                    ||' and t1.StartTime < to_date(''EEEEDDDD'',''yyyy-mm-dd'')'
                    || tmp2
                    ||' group by t2.taskID, t2.testCode, trunc(t1.StartTime)'
            ||' ) a';
     elsif  (c_testCode=1747 or c_testCode=1748) then
      sqlstr := ' insert into Z_TaskStatXXXXXXXXXX(taskid,testCode,statDate,CallCount,SuccessCount,'
            ||' FailureCount,sumDelay,MinDelay,MaxDelay,MonoDirectionCount,BreakLineCount,'
            ||' Acrosscount,Noisecount,Errcount,Rightcount,ShortCRcount,NonBeginCRcount,Silcount,'
            ||' NotSPcount,SuccessRate,FailureRate,AveCount,AveDelay,MonoDirectionRate,BreakLineRate,'
            ||' RightRate,ShortCRRate,NonBeginCRRate,AcrossRate,NoiseRate,ErrRate,SilRate,NotSPRate,'
            ||' RSuccessCount,RSumDelay,RMinDelay,RMaxDelay,RSuccessRate,TRSuccessRate,RAveDelay,'
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,aveErrPacketRate,'
           -- ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine )'
            ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine ,'
            -----------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime,aveDnsTime ,'
            ||' sumOperateTime,maxOperateTime,minOperateTime,aveOperateTime,'
            ||' sumReceivetime,maxReceivetime,minReceivetime, aveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,aveDetachTime, '
            ||' sumAttachTime,maxAttachTime,minAttachTime ,aveAttachTime, '
            
             ||' defbeaerCount_r,defbeaerRate_r,maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,aveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,vdefbeaerRate_r,maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,aveVdefbeaerDelay_r,  '
             ||' dedbeaerCount_r,dedbeaerRate_r,maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,aveDedbeaerDelay_r ,'  
             ||' registerCount_r,registerRate_r,maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,aveRegisterDelay_r, '
             ||' degisterCount_r,degisterRate_r,maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,aveDegisterDelay_r,'
             ||' defbeaerCount_d,defbeaerRate_d,maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,aveDefbeaerDelay_d,'
             ||' vdefbeaerCount_d,vdefbeaerRate_d,maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,aveVdefbeaerDelay_d,'
             ||' dedbeaerCount_d,dedbeaerRate_d,maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,aveDedbeaerDelay_d,'
             ||' registerCount_d,registerRate_d,maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,aveRegisterDelay_d,'
             ||' degisterCount_d,degisterRate_d,maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,aveDegisterDelay_d  '
             
            ||' )'
            ---------------------------------------------
            ||' select taskID, testCode, stat_date, CallCount,'
            ||' SuccessCount, FailureCount, sumDelay, MinDelay,'
            ||' MaxDelay, MonoDirectionCount, BreakLineCount, AcrossCount, NoiseCount, ErrCount, '
            ||' RightCount, ShortCRCount, NonBeginCRCount, SilCount, NotSPCount, '
            ||' decode(CallCount,0,0,SuccessCount*100/CallCount) SuccessRate, '
            ||' decode(CallCount,0,0,FailureCount*100/CallCount) FailureRate, SuccessCount AveCount, '
            ||' decode(test_Success_Count_,0,0,sumDelay/test_Success_Count_) AveDelay, '
            ||' decode(CallCount,0,0,MonoDirectionCount*100/CallCount) MonoDirectionRate, '
            ||' decode(CallCount,0,0,BreakLineCount*100/CallCount) BreakLineRate, '
            ||' decode(CallCount,0,0,RightCount*100/CallCount) RightRate, '
            ||' decode(CallCount,0,0,ShortCRCount*100/CallCount) ShortCRRate, '
            ||' decode(CallCount,0,0,NonBeginCRCount*100/CallCount) NonBeginCRRate, '
            ||' decode(CallCount,0,0,AcrossCount*100/CallCount) AcrossRate, '
            ||' decode(CallCount,0,0,NoiseCount*100/CallCount) NoiseRate, '
            ||' decode(CallCount,0,0,ErrCount*100/CallCount) ErrRate, '
            ||' decode(CallCount,0,0,SilCount*100/CallCount) SilRate, '
            ||' decode(CallCount,0,0,NotSPCount*100/CallCount) NotSPRate, '
            ||' RSuccessCount, RSumDelay, RMinDelay, RMaxDelay, '
            ||' decode(test_Success_Count_,0,0,RSuccessCount*100/test_Success_Count_) RSuccessRate, '
            ||' decode(CallCount,0,0,RSuccessCount*100/CallCount) TRSuccessRate, '
            ||' decode(RSuccessCount,0,0,RSumDelay/RSuccessCount) RAveDelay, '
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,decode(SuccessCount,0,0,SumErrPacketRate/SuccessCount) AveErrPacketRate, '
            ||' sumBreakLine,minBreakLine,maxBreakLine,decode(SuccessCount,0,0,SumBreakLine/SuccessCount) AveBreakLine, '
            ------------------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime, decode(test_Success_Count_,0,0,sunDnsTime/test_Success_Count_) AveDnsTime,  '
            ||' sumOperateTime,maxOperateTime,minOperateTime,  decode(test_Success_Count_,0,0,sumOperateTime/test_Success_Count_) AveOperateTime, '
            ||' sumReceivetime,maxReceivetime,minReceivetime, decode(test_Success_Count_,0,0,sumReceivetime/test_Success_Count_) AveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , decode(test_Success_Count_,0,0,sumDeActivationTime/test_Success_Count_) aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, decode(test_Success_Count_,0,0,sumActivationTime/test_Success_Count_) aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,  decode(test_Success_Count_,0,0,sumDetachTime/test_Success_Count_) aveDetachTime,'
            ||' sumAttachTime,maxAttachTime,minAttachTime , decode(test_Success_Count_,0,0,sumAttachTime/test_Success_Count_) aveAttachTime ,'
            
            ||' defbeaerCount_r,decode(CallCount,0,0,defbeaerCount_r*100/CallCount) defbeaerRate_r, '
             ||' maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,decode(test_Success_Count_,0,0,sumDefbeaerDelay_r/test_Success_Count_) AveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,decode(CallCount,0,0,vdefbeaerCount_r*100/CallCount) vdefbeaerRate_r, '
             ||' maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_r/test_Success_Count_) AveVdefbeaerDelay_r, '
             ||' dedbeaerCount_r,decode(CallCount,0,0,dedbeaerCount_r*100/CallCount) dedbeaerRate_r, '
             ||' maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,decode(test_Success_Count_,0,0,sumDedbeaerDelay_r/test_Success_Count_) AveDedbeaerDelay_r, '
             ||' registerCount_r,decode(CallCount,0,0,registerCount_r*100/CallCount) registerRate_r, '
             ||' maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,decode(test_Success_Count_,0,0,sumRegisterDelay_r/test_Success_Count_) AveRegisterDelay_r, '
             ||' degisterCount_r,decode(CallCount,0,0,degisterCount_r*100/CallCount) degisterRate_r, '
             ||' maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,decode(test_Success_Count_,0,0,sumDegisterDelay_r/test_Success_Count_) AveDegisterDelay_r, '
             ||' defbeaerCount_d,decode(CallCount,0,0,defbeaerCount_d*100/CallCount) defbeaerRate_d, '
             ||' maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,decode(test_Success_Count_,0,0,sumDefbeaerDelay_d/test_Success_Count_) AveDefbeaerDelay_d, '
             ||' vdefbeaerCount_d,decode(CallCount,0,0,vdefbeaerCount_d*100/CallCount) vdefbeaerRate_d, '
             ||' maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_d/test_Success_Count_) AveVdefbeaerDelay_d, '
             ||' dedbeaerCount_d,decode(CallCount,0,0,dedbeaerCount_d*100/CallCount) dedbeaerRate_d, '
             ||' maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,decode(test_Success_Count_,0,0,sumDedbeaerDelay_d/test_Success_Count_) AveDedbeaerDelay_d, '
             ||' registerCount_d,decode(CallCount,0,0,registerCount_d*100/CallCount) registerRate_d, '
             ||' maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,decode(test_Success_Count_,0,0,sumRegisterDelay_d/test_Success_Count_) AveRegisterDelay_d, '
             ||' degisterCount_d,decode(CallCount,0,0,degisterCount_d*100/CallCount) degisterRate_d, '
             ||' maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,decode(test_Success_Count_,0,0,sumDegisterDelay_d/test_Success_Count_) AveDegisterDelay_d '

            ------------------------------------------------
            ||' from ( select t2.taskID taskID, t2.testCode, trunc(t1.StartTime) stat_date, count(t1.ProgID) CallCount, '
                    || tmp ||' from Z_TestResultYYYYYYYYYY t1,Z_Taskinfo t2'
                    ||' where t1.taskID = t2.taskID '
                    ||' and t1.talkStatus <> 99 '
                    ||' and t1.testCode = '||c_testCode
                    ||' and t1.StartTime >= to_date(''SSSSDDDD'',''yyyy-mm-dd'')'
                    ||' and t1.StartTime < to_date(''EEEEDDDD'',''yyyy-mm-dd'')'
                    || tmp2
                    ||' group by t2.taskID, t2.testCode, trunc(t1.StartTime)'
            ||' ) a';
            
       /*elsif  (c_testCode=3601 or c_testCode=3607) then
             sqlstr := ' insert into Z_TaskStatXXXXXXXXXX(taskid,testCode,statDate,CallCount,SuccessCount,'
            ||' FailureCount,sumDelay,MinDelay,MaxDelay,MonoDirectionCount,BreakLineCount,'
            ||' Acrosscount,Noisecount,Errcount,Rightcount,ShortCRcount,NonBeginCRcount,Silcount,'
            ||' NotSPcount,SuccessRate,FailureRate,AveCount,AveDelay,MonoDirectionRate,BreakLineRate,'
            ||' RightRate,ShortCRRate,NonBeginCRRate,AcrossRate,NoiseRate,ErrRate,SilRate,NotSPRate,'
            ||' RSuccessCount,RSumDelay,RMinDelay,RMaxDelay,RSuccessRate,TRSuccessRate,RAveDelay,'
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,aveErrPacketRate,'
           -- ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine )'
            ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine ,'
            -----------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime,aveDnsTime ,'
            ||' sumOperateTime,maxOperateTime,minOperateTime,aveOperateTime,'
            ||' sumReceivetime,maxReceivetime,minReceivetime, aveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,aveDetachTime, '
            ||' sumAttachTime,maxAttachTime,minAttachTime ,aveAttachTime, '
            
             ||' defbeaerCount_r,defbeaerRate_r,maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,aveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,vdefbeaerRate_r,maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,aveVdefbeaerDelay_r,  '
             ||' dedbeaerCount_r,dedbeaerRate_r,maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,aveDedbeaerDelay_r ,'  
             ||' registerCount_r,registerRate_r,maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,aveRegisterDelay_r, '
             ||' degisterCount_r,degisterRate_r,maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,aveDegisterDelay_r,'
             ||' defbeaerCount_d,defbeaerRate_d,maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,aveDefbeaerDelay_d,'
             ||' vdefbeaerCount_d,vdefbeaerRate_d,maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,aveVdefbeaerDelay_d,'
             ||' dedbeaerCount_d,dedbeaerRate_d,maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,aveDedbeaerDelay_d,'
             ||' registerCount_d,registerRate_d,maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,aveRegisterDelay_d,'
             ||' degisterCount_d,degisterRate_d,maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,aveDegisterDelay_d  '
             
            ||' )'
            ---------------------------------------------
            ||' select taskID, testCode, stat_date, CallCount,'
            ||' SuccessCount, FailureCount, sumDelay, MinDelay,'
            ||' MaxDelay, MonoDirectionCount, BreakLineCount, AcrossCount, NoiseCount, ErrCount, '
            ||' RightCount, ShortCRCount, NonBeginCRCount, SilCount, NotSPCount, '
            ||' decode(CallCount,0,0,SuccessCount*100/CallCount) SuccessRate, '
            ||' decode(CallCount,0,0,FailureCount*100/CallCount) FailureRate, SuccessCount AveCount, '
            ||' decode(test_Success_Count_,0,0,SumDelay/test_Success_Count_) AveDelay, '
            ||' decode(CallCount,0,0,MonoDirectionCount*100/CallCount) MonoDirectionRate, '
            ||' decode(CallCount,0,0,BreakLineCount*100/CallCount) BreakLineRate, '
            ||' decode(CallCount,0,0,RightCount*100/CallCount) RightRate, '
            ||' decode(CallCount,0,0,ShortCRCount*100/CallCount) ShortCRRate, '
            ||' decode(CallCount,0,0,NonBeginCRCount*100/CallCount) NonBeginCRRate, '
            ||' decode(CallCount,0,0,AcrossCount*100/CallCount) AcrossRate, '
            ||' decode(CallCount,0,0,NoiseCount*100/CallCount) NoiseRate, '
            ||' decode(CallCount,0,0,ErrCount*100/CallCount) ErrRate, '
            ||' decode(CallCount,0,0,SilCount*100/CallCount) SilRate, '
            ||' decode(CallCount,0,0,NotSPCount*100/CallCount) NotSPRate, '
            ||' RSuccessCount, RSumDelay, RMinDelay, RMaxDelay, '
            ||' decode(test_Success_Count_,0,0,RSuccessCount*100/test_Success_Count_) RSuccessRate, '
            ||' decode(CallCount,0,0,RSuccessCount*100/CallCount) TRSuccessRate, '
            ||' decode(RSuccessCount,0,0,RSumDelay/RSuccessCount) RAveDelay, '
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,decode(SuccessCount,0,0,SumErrPacketRate/SuccessCount) AveErrPacketRate, '
            ||' sumBreakLine,minBreakLine,maxBreakLine,decode(SuccessCount,0,0,SumBreakLine/SuccessCount) AveBreakLine, '
            ------------------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime, decode(test_Success_Count_,0,0,sunDnsTime/test_Success_Count_) AveDnsTime,  '
            ||' sumOperateTime,maxOperateTime,minOperateTime,  decode(test_Success_Count_,0,0,sumOperateTime/test_Success_Count_) AveOperateTime, '
            ||' sumReceivetime,maxReceivetime,minReceivetime, decode(test_Success_Count_,0,0,sumReceivetime/test_Success_Count_) AveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , decode(test_Success_Count_,0,0,sumDeActivationTime/test_Success_Count_) aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, decode(test_Success_Count_,0,0,sumActivationTime/test_Success_Count_) aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,  decode(test_Success_Count_,0,0,sumDetachTime/test_Success_Count_) aveDetachTime,'
            ||' sumAttachTime,maxAttachTime,minAttachTime , decode(test_Success_Count_,0,0,sumAttachTime/test_Success_Count_) aveAttachTime ,'
            
            ||' defbeaerCount_r,decode(CallCount,0,0,defbeaerCount_r*100/CallCount) defbeaerRate_r, '
             ||' maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,decode(test_Success_Count_,0,0,sumDefbeaerDelay_r/test_Success_Count_) AveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,decode(CallCount,0,0,vdefbeaerCount_r*100/CallCount) vdefbeaerRate_r, '
             ||' maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_r/test_Success_Count_) AveVdefbeaerDelay_r, '
             ||' dedbeaerCount_r,decode(CallCount,0,0,dedbeaerCount_r*100/CallCount) dedbeaerRate_r, '
             ||' maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,decode(test_Success_Count_,0,0,sumDedbeaerDelay_r/test_Success_Count_) AveDedbeaerDelay_r, '
             ||' registerCount_r,decode(CallCount,0,0,registerCount_r*100/CallCount) registerRate_r, '
             ||' maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,decode(test_Success_Count_,0,0,sumRegisterDelay_r/test_Success_Count_) AveRegisterDelay_r, '
             ||' degisterCount_r,decode(CallCount,0,0,degisterCount_r*100/CallCount) degisterRate_r, '
             ||' maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,decode(test_Success_Count_,0,0,sumDegisterDelay_r/test_Success_Count_) AveDegisterDelay_r, '
             ||' defbeaerCount_d,decode(CallCount,0,0,defbeaerCount_d*100/CallCount) defbeaerRate_d, '
             ||' maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,decode(test_Success_Count_,0,0,sumDefbeaerDelay_d/test_Success_Count_) AveDefbeaerDelay_d, '
             ||' vdefbeaerCount_d,decode(CallCount,0,0,vdefbeaerCount_d*100/CallCount) vdefbeaerRate_d, '
             ||' maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_d/test_Success_Count_) AveVdefbeaerDelay_d, '
             ||' dedbeaerCount_d,decode(CallCount,0,0,dedbeaerCount_d*100/CallCount) dedbeaerRate_d, '
             ||' maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,decode(test_Success_Count_,0,0,sumDedbeaerDelay_d/test_Success_Count_) AveDedbeaerDelay_d, '
             ||' registerCount_d,decode(CallCount,0,0,registerCount_d*100/CallCount) registerRate_d, '
             ||' maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,decode(test_Success_Count_,0,0,sumRegisterDelay_d/test_Success_Count_) AveRegisterDelay_d, '
             ||' degisterCount_d,decode(CallCount,0,0,degisterCount_d*100/CallCount) degisterRate_d, '
             ||' maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,decode(test_Success_Count_,0,0,sumDegisterDelay_d/test_Success_Count_) AveDegisterDelay_d '

         
         ||' from ( select t2.taskID taskID, t2.testCode, trunc(t1.StartTime) stat_date, count(t1.ProgID) CallCount, '
                    || tmp ||' from Z_TestResultYYYYYYYYYY t1,Z_Taskinfo t2'
                    ||' where t1.taskID = t2.taskID '
                    ||' and t1.talkStatus <> 99 ' 
                    ||' and t1.testCode = '||c_testCode
                    ||' and t1.StartTime >= to_date(''SSSSDDDD'',''yyyy-mm-dd'')'
                    ||' and t1.StartTime < to_date(''EEEEDDDD'',''yyyy-mm-dd'')'
                    || tmp2
                    ||' group by t2.taskID, t2.testCode, trunc(t1.StartTime)'
            ||' ) a';*/
    elsif  (c_testCode=8001 or c_testCode=8002 or c_testCode=8003 or c_testCode=3401 or  c_testCode=3708 or c_testCode=3709 or c_testCode=3710 or c_testCode=3711 or  c_testCode=3081 or c_testCode=3082 or c_testCode=3068 or  c_testCode=3083 or  c_testCode=3084 or  c_testCode=3085 or c_testCode=3601 or c_testCode=3607 or c_testCode=3602 or c_testCode=3603 or c_testCode=3604 or c_testCode=3605 or c_testCode=3606 or c_testCode=3701 or c_testCode=3702 or c_testCode=3703 or c_testCode=3704 or c_testCode=3705 or c_testCode=3706 or c_testCode=3108 or c_testCode=3075 or c_testCode=3076 or c_testCode=3707) then
          sqlstr := ' insert into Z_TaskStatXXXXXXXXXX(taskid,testCode,statDate,CallCount,SuccessCount,'
            ||' FailureCount,sumDelay,MinDelay,MaxDelay,MonoDirectionCount,BreakLineCount,'
            ||' Acrosscount,Noisecount,Errcount,Rightcount,ShortCRcount,NonBeginCRcount,Silcount,'
            ||' NotSPcount,SuccessRate,FailureRate,AveCount,AveDelay,MonoDirectionRate,BreakLineRate,'
            ||' RightRate,ShortCRRate,NonBeginCRRate,AcrossRate,NoiseRate,ErrRate,SilRate,NotSPRate,'
            ||' RSuccessCount,RSumDelay,RMinDelay,RMaxDelay,RSuccessRate,TRSuccessRate,RAveDelay,'
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,aveErrPacketRate,'
           -- ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine )'
            ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine ,'
            -----------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime,aveDnsTime ,'
            ||' sumOperateTime,maxOperateTime,minOperateTime,aveOperateTime,'
            ||' sumReceivetime,maxReceivetime,minReceivetime, aveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,aveDetachTime, '
            ||' sumAttachTime,maxAttachTime,minAttachTime ,aveAttachTime, '
             
             ||' attachCount_r,attachRate_r,maxAttachDelay_r,minAttachDelay_r,sumAttachDelay_r,aveAttachDelay_r,'
             ||' defbeaerCount_r ,defbeaerRate_r,maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerhDelay_r,aveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r ,vdefbeaerRate_r,maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,aveVdefbeaerDelay_r,'
             ||' dedbeaerCount_r,dedbeaerRate_r,maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,aveDedbeaerDelay_r,'
             ||' registerCount_r,registerRate_r ,maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r,aveRegisterDelay_r,'
             ||' volteCallCount_r,volteCallRate_r,maxVolteCallDelay_r,minVolteCallDelay_r,sumVolteCallDelay_r,aveVolteCallDelay_r,'
             ||' volteCancelCount_r,volteCancelRate_r,maxVolteCancelDelay_r,minVolteCancelDelay_r,sumVolteCancelDelay_r,aveVolteCancelDelay_r,'
             ||' degisterCount_r,degisterRate_r,maxDegisterDelay_r,minDegisteDelay_r,sumDegisteDelay_r,aveDegisteDelay_r,'
             ||' dettachCount_r,dettachRate_r,maxDettachDelay_r,minDettachDelay_r,sumDettachDelay_r,aveDettachDelay_r,'
             ||' identityCount_r,identityRate_r,maxIdentityDelay_r,minIdentityDelay_r,sumIdentityDelay_r,aveIdentityDelay_r,'
             ||' authCount_r,authRate_r,maxAuthDelay_r,minAuthDelay_r,sumAuthDelay_r,aveAuthDelay_r,'
             ||' securityCount_r,securityRate_r,maxSecurityDelay_r,minSecurityDelay_r,sumSecurityDelay_r,aveSecurityDelay_r,'
             
             ||' taustartCount_r,taustartRate_r,maxtaustartDelay_r,mintaustartDelay_r,sumtaustartDelay_r,avetaustartDelay_r,'
             
             ||' attachCount_d,attachRate_d,maxAttachDelay_d,minAttachDelay_d,sumAttachDelay_d,aveAttachDelay_d,'
             ||' defbeaerCount_d ,defbeaerRate_d,maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerhDelay_d,aveDefbeaerDelay_d, '
             ||' vdefbeaerCount_d ,vdefbeaerRate_d,maxVdefbeaerDelay_d,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,aveVdefbeaerDelay_d,'
             ||' dedbeaerCount_d,dedbeaerRate_d,maxDedbeaerDelay_d,minDedbeaerDelay_d,sumDedbeaerDelay_d,aveDedbeaerDelay_d,'
             ||' registerCount_d,registerRate_d ,maxRegisterDelay_d,minRegisterDelay_d,sumRegisterDelay_d,aveRegisterDelay_d,'
             ||' volteCallCount_d,volteCallRate_d,maxVolteCallDelay_d,minVolteCallDelay_d,sumVolteCallDelay_d,aveVolteCallDelay_d,'
             ||' volteCancelCount_d,volteCancelRate_d,maxVolteCancelDelay_d,minVolteCancelDelay_d,sumVolteCancelDelay_d,aveVolteCancelDelay_d,'
             ||' degisterCount_d,degisterRate_d,maxDegisterDelay_d,minDegisteDelay_d,sumDegisteDelay_d,aveDegisteDelay_d,'
             ||' dettachCount_d,dettachRate_d,maxDettachDelay_d,minDettachDelay_d,sumDettachDelay_d,aveDettachDelay_d,'
             ||' identityCount_d,identityRate_d,maxIdentityDelay_d,minIdentityDelay_d,sumIdentityDelay_d,aveIdentityDelay_d,'
             ||' authCount_d,authRate_d,maxAuthDelay_d,minAuthDelay_d,sumAuthDelay_d,aveAuthDelay_d,'
             ||' securityCount_d,securityRate_d,maxSecurityDelay_d,minSecurityDelay_d,sumSecurityDelay_d,aveSecurityDelay_d, '
             ||' taustartCount_d,taustartRate_d,maxtaustartDelay_d,mintaustartDelay_d,sumtaustartDelay_d,avetaustartDelay_d'
             ||' )'
            
            ||' select taskID, testCode, stat_date, CallCount,'
            ||' SuccessCount, FailureCount, sumDelay, MinDelay,'
            ||' MaxDelay, MonoDirectionCount, BreakLineCount, AcrossCount, NoiseCount, ErrCount, '
            ||' RightCount, ShortCRCount, NonBeginCRCount, SilCount, NotSPCount, '
            ||' decode(CallCount,0,0,SuccessCount*100/CallCount) SuccessRate, '
            ||' decode(CallCount,0,0,FailureCount*100/CallCount) FailureRate, SuccessCount AveCount, '
            ||' decode(test_Success_Count_,0,0,sumDelay/test_Success_Count_) AveDelay, '
            ||' decode(CallCount,0,0,MonoDirectionCount*100/CallCount) MonoDirectionRate, '
            ||' decode(CallCount,0,0,BreakLineCount*100/CallCount) BreakLineRate, '
            ||' decode(CallCount,0,0,RightCount*100/CallCount) RightRate, '
            ||' decode(CallCount,0,0,ShortCRCount*100/CallCount) ShortCRRate, '
            ||' decode(CallCount,0,0,NonBeginCRCount*100/CallCount) NonBeginCRRate, '
            ||' decode(CallCount,0,0,AcrossCount*100/CallCount) AcrossRate, '
            ||' decode(CallCount,0,0,NoiseCount*100/CallCount) NoiseRate, '
            ||' decode(CallCount,0,0,ErrCount*100/CallCount) ErrRate, '
            ||' decode(CallCount,0,0,SilCount*100/CallCount) SilRate, '
            ||' decode(CallCount,0,0,NotSPCount*100/CallCount) NotSPRate, '
            ||' RSuccessCount, RSumDelay, RMinDelay, RMaxDelay, '
            ||' decode(test_Success_Count_,0,0,RSuccessCount*100/test_Success_Count_) RSuccessRate, '
            ||' decode(CallCount,0,0,RSuccessCount*100/CallCount) TRSuccessRate, '
            ||' decode(SuccessCount,0,0,RSumDelay/SuccessCount) RAveDelay, '
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,decode(RSuccessCount,0,0,SumErrPacketRate/RSuccessCount) AveErrPacketRate, '
            ||' sumBreakLine,minBreakLine,maxBreakLine,decode(SuccessCount,0,0,SumBreakLine/SuccessCount) AveBreakLine, '
            ------------------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime, decode(test_Success_Count_,0,0,sunDnsTime/test_Success_Count_) AveDnsTime,  '
            ||' sumOperateTime,maxOperateTime,minOperateTime,  decode(test_Success_Count_,0,0,sumOperateTime/test_Success_Count_) AveOperateTime, '
            ||' sumReceivetime,maxReceivetime,minReceivetime, decode(RSuccessCount,0,0,sumReceivetime/RSuccessCount) AveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , decode(test_Success_Count_,0,0,sumDeActivationTime/test_Success_Count_) aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, decode(test_Success_Count_,0,0,sumActivationTime/test_Success_Count_) aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,  decode(test_Success_Count_,0,0,sumDetachTime/test_Success_Count_) aveDetachTime,'
            ||' sumAttachTime,maxAttachTime,minAttachTime , decode(test_Success_Count_,0,0,sumAttachTime/test_Success_Count_) aveAttachTime ,'
        

        ||' attachCount_r,decode(CallCount,0,0,attachCount_r*100/CallCount) attachRate_r, '
        ||' maxAttachDelay_r,minAttachDelay_r,sumAttachDelay_r, decode(attachCount_r,0,0,sumAttachDelay_r/attachCount_r) AveAttachDelay_r, '
        ||' defbeaerCount_r,decode(CallCount,0,0,defbeaerCount_r*100/CallCount) defbeaerRate_r, '
        ||' maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,decode(defbeaerCount_r,0,0,sumDefbeaerDelay_r/defbeaerCount_r) AveDefbeaerDelay_r, '
        ||' vdefbeaerCount_r,decode(CallCount,0,0,vdefbeaerCount_r*100/CallCount) vdefbeaerRate_r, '
        ||' maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,decode(vdefbeaerCount_r,0,0,sumVdefbeaerDelay_r/vdefbeaerCount_r) AveVdefbeaerDelay_r, '
        ||' dedbeaerCount_r,decode(CallCount,0,0,dedbeaerCount_r*100/CallCount) dedbeaerRate_r, '
        ||' maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,decode(dedbeaerCount_r,0,0,sumDedbeaerDelay_r/dedbeaerCount_r) AveDedbeaerDelay_r, '
        ||' registerCount_r,decode(CallCount,0,0,registerCount_r*100/CallCount) registerRate_r, '
        ||' maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r,decode(registerCount_r,0,0,sumRegisterDelay_r/registerCount_r) AveRegisterDelay_r, '
        ||' volteCallCount_r,decode(CallCount,0,0,volteCallCount_r*100/CallCount) volteCallRate_r, '
        ||' maxVoltecallDelay_r,minVoltecallDelay_r,sumVoltecallDelay_r,decode(volteCallCount_r,0,0,sumVoltecallDelay_r/volteCallCount_r) AveVoltecallDelay_r, '
        ||' volteCancelCount_r,decode(CallCount,0,0,volteCancelCount_r*100/CallCount) volteCancelRate_r, '
        ||' maxVoltecancelDelay_r,minVoltecancelDelay_r,sumVoltecancelDelay_r,decode(volteCancelCount_r,0,0,sumVoltecancelDelay_r/volteCancelCount_r) AveVoltecancelDelay_r, '
        ||' degisterCount_r,decode(CallCount,0,0,degisterCount_r*100/CallCount) degisterRate_r, '
        ||' maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,decode(degisterCount_r,0,0,sumDegisterDelay_r/degisterCount_r) AveDegisterDelay_r, '
        ||' dettachCount_r,decode(CallCount,0,0,dettachCount_r*100/CallCount) dettachRate_r, '
        ||' maxDettachDelay_r,minDettachDelay_r,sumDettachDelay_r,decode(dettachCount_r,0,0,sumDettachDelay_r/dettachCount_r) AveDettachDelay_r, '
        ||' identityCount_r,decode(CallCount,0,0,identityCount_r*100/CallCount) identityRate_r, '
        ||' maxIdentityDelay_r,minIdentityDelay_r,sumIdentityDelay_r,decode(identityCount_r,0,0,sumIdentityDelay_r/identityCount_r) AveIdentityDelay_r, '
        ||' authCount_r,decode(CallCount,0,0,authCount_r*100/CallCount) authRate_r, '
        ||' maxAuthDelay_r,minAuthDelay_r,sumAuthDelay_r,decode(authCount_r,0,0,sumAuthDelay_r/authCount_r) AveAuthDelay_r, '
        ||' securityCount_r,decode(CallCount,0,0,securityCount_r*100/CallCount) securityRate_r, '
        ||' maxSecurityDelay_r,minSecurityDelay_r,sumSecurityDelay_r,decode(securityCount_r,0,0,sumSecurityDelay_r/securityCount_r) AveSecurityDelay_r, '
        
        ||' taustartCount_r,decode(CallCount,0,0,taustartCount_r*100/CallCount) taustartRate_r, '
        ||' maxtaustartDelay_r,mintaustartDelay_r,sumtaustartDelay_r,decode(taustartCount_r,0,0,sumtaustartDelay_r/taustartCount_r) AvetaustartDelay_r, '
      
        
        ||' attachCount_d,decode(CallCount,0,0,attachCount_d*100/CallCount) attachRate_d, '
        ||' maxAttachDelay_d,minAttachDelay_d,sumAttachDelay_d, decode(attachCount_d,0,0,sumAttachDelay_d/attachCount_d) AveAttachDelay_d, '
        ||' defbeaerCount_d,decode(CallCount,0,0,defbeaerCount_d*100/CallCount) defbeaerRate_d, '
        ||' maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,decode(defbeaerCount_d,0,0,sumDefbeaerDelay_d/defbeaerCount_d) AveDefbeaerDelay_d, '
        ||' vdefbeaerCount_d,decode(CallCount,0,0,vdefbeaerCount_d*100/CallCount) vdefbeaerRate_d, '
        ||' maxVdefbeaerDelay_d,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,decode(vdefbeaerCount_d,0,0,sumVdefbeaerDelay_d/vdefbeaerCount_d) AveVdefbeaerDelay_d, '
        ||' dedbeaerCount_d,decode(CallCount,0,0,dedbeaerCount_d*100/CallCount) dedbeaerRate_d, '
        ||' maxDedbeaerDelay_d,minDedbeaerDelay_d,sumDedbeaerDelay_d,decode(dedbeaerCount_d,0,0,sumDedbeaerDelay_d/dedbeaerCount_d) AveDedbeaerDelay_d, '
        ||' registerCount_d,decode(CallCount,0,0,registerCount_d*100/CallCount) registerRate_d, '
        ||' maxRegisterDelay_d,minRegisterDelay_d,sumRegisterDelay_d,decode(registerCount_d,0,0,sumRegisterDelay_d/registerCount_d) AveRegisterDelay_d, '
        ||' volteCallCount_d,decode(CallCount,0,0,volteCallCount_d*100/CallCount) volteCallRate_d, '
        ||' maxVoltecallDelay_d,minVoltecallDelay_d,sumVoltecallDelay_d,decode(volteCallCount_d,0,0,sumVoltecallDelay_d/volteCallCount_d) AveVoltecallDelay_d, '
        ||' volteCancelCount_d,decode(CallCount,0,0,volteCancelCount_d*100/CallCount) volteCancelRate_d, '
        ||' maxVoltecancelDelay_d,minVoltecancelDelay_d,sumVoltecancelDelay_d,decode(volteCancelCount_d,0,0,sumVoltecancelDelay_d/volteCancelCount_d) AveVoltecancelDelay_d, '
        ||' degisterCount_d,decode(CallCount,0,0,degisterCount_d*100/CallCount) degisterRate_d, '
        ||' maxDegisterDelay_d,minDegisterDelay_d,sumDegisterDelay_d,decode(degisterCount_d,0,0,sumDegisterDelay_d/degisterCount_d) AveDegisterDelay_d, '
        ||' dettachCount_d,decode(CallCount,0,0,dettachCount_d*100/CallCount) dettachRate_d, '
        ||' maxDettachDelay_d,minDettachDelay_d,sumDettachDelay_d,decode(dettachCount_d,0,0,sumDettachDelay_d/dettachCount_d) AveDettachDelay_d, '
        ||' identityCount_d,decode(CallCount,0,0,identityCount_d*100/CallCount) identityRate_d, '
        ||' maxIdentityDelay_d,minIdentityDelay_d,sumIdentityDelay_d,decode(identityCount_d,0,0,sumIdentityDelay_d/identityCount_d) AveIdentityDelay_d, '
        ||' authCount_d,decode(CallCount,0,0,authCount_d*100/CallCount) authRate_d, '
        ||' maxAuthDelay_d,minAuthDelay_d,sumAuthDelay_d,decode(authCount_d,0,0,sumAuthDelay_d/authCount_d) AveAuthDelay_d, '
        ||' securityCount_d,decode(CallCount,0,0,securityCount_d*100/CallCount) securityRate_d, '
        ||' maxSecurityDelay_d,minSecurityDelay_d,sumSecurityDelay_d,decode(securityCount_d,0,0,sumSecurityDelay_d/securityCount_d) AveSecurityDelay_d ,'
        
        ||' taustartCount_d,decode(CallCount,0,0,taustartCount_d*100/CallCount) taustartRate_d, '
        ||' maxtaustartDelay_d,mintaustartDelay_d,sumtaustartDelay_d,decode(taustartCount_d,0,0,sumtaustartDelay_d/taustartCount_d) AvetaustartDelay_d '
      

            ---------------------------------------------------------
            ||' from ( select t2.taskID taskID, t2.testCode, trunc(t1.StartTime) stat_date, count(t1.ProgID) CallCount, '
                    || tmp ||' from Z_TestResultYYYYYYYYYY t1,Z_Taskinfo t2'
                    ||' where t1.taskID = t2.taskID '
                    ||' and t1.talkStatus <> 99 ' 
                    ||' and t1.testCode = '||c_testCode
                    ||' and t1.StartTime >= to_date(''SSSSDDDD'',''yyyy-mm-dd'')'
                    ||' and t1.StartTime < to_date(''EEEEDDDD'',''yyyy-mm-dd'')'
                    || tmp2
                    ||' group by t2.taskID, t2.testCode, trunc(t1.StartTime)'
            ||' ) a';
        else
          sqlstr := ' insert into Z_TaskStatXXXXXXXXXX(taskid,testCode,statDate,CallCount,SuccessCount,'
            ||' FailureCount,sumDelay,MinDelay,MaxDelay,MonoDirectionCount,BreakLineCount,'
            ||' Acrosscount,Noisecount,Errcount,Rightcount,ShortCRcount,NonBeginCRcount,Silcount,'
            ||' NotSPcount,SuccessRate,FailureRate,AveCount,AveDelay,MonoDirectionRate,BreakLineRate,'
            ||' RightRate,ShortCRRate,NonBeginCRRate,AcrossRate,NoiseRate,ErrRate,SilRate,NotSPRate,'
            ||' RSuccessCount,RSumDelay,RMinDelay,RMaxDelay,RSuccessRate,TRSuccessRate,RAveDelay,'
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,aveErrPacketRate,'
           -- ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine )'
            ||' sumBreakLine,minBreakLine,maxBreakLine,aveBreakLine ,'
            -----------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime,aveDnsTime ,'
            ||' sumOperateTime,maxOperateTime,minOperateTime,aveOperateTime,'
            ||' sumReceivetime,maxReceivetime,minReceivetime, aveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,aveDetachTime, '
            ||' sumAttachTime,maxAttachTime,minAttachTime ,aveAttachTime, '
            
             ||' defbeaerCount_r,defbeaerRate_r,maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,aveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,vdefbeaerRate_r,maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,aveVdefbeaerDelay_r,  '
             ||' dedbeaerCount_r,dedbeaerRate_r,maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,aveDedbeaerDelay_r ,'  
             ||' registerCount_r,registerRate_r,maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,aveRegisterDelay_r, '
             ||' degisterCount_r,degisterRate_r,maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,aveDegisterDelay_r,'
             ||' defbeaerCount_d,defbeaerRate_d,maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,aveDefbeaerDelay_d,'
             ||' vdefbeaerCount_d,vdefbeaerRate_d,maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,aveVdefbeaerDelay_d,'
             ||' dedbeaerCount_d,dedbeaerRate_d,maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,aveDedbeaerDelay_d,'
             ||' registerCount_d,registerRate_d,maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,aveRegisterDelay_d,'
             ||' degisterCount_d,degisterRate_d,maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,aveDegisterDelay_d  '
             
            ||' )'
            ---------------------------------------------
            ||' select taskID, testCode, stat_date, CallCount,'
            ||' SuccessCount, FailureCount, sumDelay, MinDelay,'
            ||' MaxDelay, MonoDirectionCount, BreakLineCount, AcrossCount, NoiseCount, ErrCount, '
            ||' RightCount, ShortCRCount, NonBeginCRCount, SilCount, NotSPCount, '
            ||' decode(CallCount,0,0,SuccessCount*100/CallCount) SuccessRate, '
            ||' decode(CallCount,0,0,FailureCount*100/CallCount) FailureRate, SuccessCount AveCount, '
            ||' decode(test_Success_Count_,0,0,sumDelay/test_Success_Count_) AveDelay, '
            ||' decode(CallCount,0,0,MonoDirectionCount*100/CallCount) MonoDirectionRate, '
            ||' decode(CallCount,0,0,BreakLineCount*100/CallCount) BreakLineRate, '
            ||' decode(CallCount,0,0,RightCount*100/CallCount) RightRate, '
            ||' decode(CallCount,0,0,ShortCRCount*100/CallCount) ShortCRRate, '
            ||' decode(CallCount,0,0,NonBeginCRCount*100/CallCount) NonBeginCRRate, '
            ||' decode(CallCount,0,0,AcrossCount*100/CallCount) AcrossRate, '
            ||' decode(CallCount,0,0,NoiseCount*100/CallCount) NoiseRate, '
            ||' decode(CallCount,0,0,ErrCount*100/CallCount) ErrRate, '
            ||' decode(CallCount,0,0,SilCount*100/CallCount) SilRate, '
            ||' decode(CallCount,0,0,NotSPCount*100/CallCount) NotSPRate, '
            ||' RSuccessCount, RSumDelay, RMinDelay, RMaxDelay, '
            ||' decode(test_Success_Count_,0,0,RSuccessCount*100/test_Success_Count_) RSuccessRate, '
            ||' decode(CallCount,0,0,RSuccessCount*100/CallCount) TRSuccessRate, '
            ||' decode(RSuccessCount,0,0,RSumDelay/RSuccessCount) RAveDelay, '
            ||' sumErrPacketRate,minErrPacketRate,maxErrPacketRate,decode(SuccessCount,0,0,SumErrPacketRate/SuccessCount) AveErrPacketRate, '
            ||' sumBreakLine,minBreakLine,maxBreakLine,decode(SuccessCount,0,0,SumBreakLine/SuccessCount) AveBreakLine, '
            ------------------------------------------------
            ||' sunDnsTime,maxDnsTime,minDnsTime, decode(test_Success_Count_,0,0,sunDnsTime/test_Success_Count_) AveDnsTime,  '
            ||' sumOperateTime,maxOperateTime,minOperateTime,  decode(test_Success_Count_,0,0,sumOperateTime/test_Success_Count_) AveOperateTime, '
            ||' sumReceivetime,maxReceivetime,minReceivetime, decode(test_Success_Count_,0,0,sumReceivetime/test_Success_Count_) AveReceivetime, '
            ||' sumDeActivationTime ,maxDeActivationTime,minDeActivationTime , decode(test_Success_Count_,0,0,sumDeActivationTime/test_Success_Count_) aveDeActivationTime,'
            ||' sumActivationTime,maxActivationTime, minActivationTime, decode(test_Success_Count_,0,0,sumActivationTime/test_Success_Count_) aveActivationTime,'
            ||' sumDetachTime,maxDetachTime,minDetachTime ,  decode(test_Success_Count_,0,0,sumDetachTime/test_Success_Count_) aveDetachTime,'
            ||' sumAttachTime,maxAttachTime,minAttachTime , decode(test_Success_Count_,0,0,sumAttachTime/test_Success_Count_) aveAttachTime ,'
            
            ||' defbeaerCount_r,decode(CallCount,0,0,defbeaerCount_r*100/CallCount) defbeaerRate_r, '
             ||' maxDefbeaerDelay_r,minDefbeaerDelay_r,sumDefbeaerDelay_r,decode(test_Success_Count_,0,0,sumDefbeaerDelay_r/test_Success_Count_) AveDefbeaerDelay_r, '
             ||' vdefbeaerCount_r,decode(CallCount,0,0,vdefbeaerCount_r*100/CallCount) vdefbeaerRate_r, '
             ||' maxVdefbeaerDelay_r,minVdefbeaerDelay_r,sumVdefbeaerDelay_r,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_r/test_Success_Count_) AveVdefbeaerDelay_r, '
             ||' dedbeaerCount_r,decode(CallCount,0,0,dedbeaerCount_r*100/CallCount) dedbeaerRate_r, '
             ||' maxDedbeaerDelay_r,minDedbeaerDelay_r,sumDedbeaerDelay_r,decode(test_Success_Count_,0,0,sumDedbeaerDelay_r/test_Success_Count_) AveDedbeaerDelay_r, '
             ||' registerCount_r,decode(CallCount,0,0,registerCount_r*100/CallCount) registerRate_r, '
             ||' maxRegisterDelay_r,minRegisterDelay_r,sumRegisterDelay_r ,decode(test_Success_Count_,0,0,sumRegisterDelay_r/test_Success_Count_) AveRegisterDelay_r, '
             ||' degisterCount_r,decode(CallCount,0,0,degisterCount_r*100/CallCount) degisterRate_r, '
             ||' maxDegisterDelay_r,minDegisterDelay_r,sumDegisterDelay_r,decode(test_Success_Count_,0,0,sumDegisterDelay_r/test_Success_Count_) AveDegisterDelay_r, '
             ||' defbeaerCount_d,decode(CallCount,0,0,defbeaerCount_d*100/CallCount) defbeaerRate_d, '
             ||' maxDefbeaerDelay_d,minDefbeaerDelay_d,sumDefbeaerDelay_d,decode(test_Success_Count_,0,0,sumDefbeaerDelay_d/test_Success_Count_) AveDefbeaerDelay_d, '
             ||' vdefbeaerCount_d,decode(CallCount,0,0,vdefbeaerCount_d*100/CallCount) vdefbeaerRate_d, '
             ||' maxVdefbeaerDelay_d ,minVdefbeaerDelay_d,sumVdefbeaerDelay_d,decode(test_Success_Count_,0,0,sumVdefbeaerDelay_d/test_Success_Count_) AveVdefbeaerDelay_d, '
             ||' dedbeaerCount_d,decode(CallCount,0,0,dedbeaerCount_d*100/CallCount) dedbeaerRate_d, '
             ||' maxDedbeaerDelay_d ,minDedbeaerDelay_d ,sumDedbeaerDelay_d,decode(test_Success_Count_,0,0,sumDedbeaerDelay_d/test_Success_Count_) AveDedbeaerDelay_d, '
             ||' registerCount_d,decode(CallCount,0,0,registerCount_d*100/CallCount) registerRate_d, '
             ||' maxRegisterDelay_d ,minRegisterDelay_d , sumRegisterDelay_d,decode(test_Success_Count_,0,0,sumRegisterDelay_d/test_Success_Count_) AveRegisterDelay_d, '
             ||' degisterCount_d,decode(CallCount,0,0,degisterCount_d*100/CallCount) degisterRate_d, '
             ||' maxDegisterDelay_d ,minDegisterDelay_d , sumDegisterDelay_d,decode(test_Success_Count_,0,0,sumDegisterDelay_d/test_Success_Count_) AveDegisterDelay_d '

            ------------------------------------------------
            ||' from ( select t2.taskID taskID, t2.testCode, trunc(t1.StartTime) stat_date, count(t1.ProgID) CallCount, '
                    || tmp ||' from Z_TestResultYYYYYYYYYY t1,Z_Taskinfo t2'
                    ||' where t1.taskID = t2.taskID '
                    ||' and t1.talkStatus <> 99 ' 
                    ||' and t1.testCode = '||c_testCode
                    ||' and t1.StartTime >= to_date(''SSSSDDDD'',''yyyy-mm-dd'')'
                    ||' and t1.StartTime < to_date(''EEEEDDDD'',''yyyy-mm-dd'')'
                    || tmp2
                    ||' group by t2.taskID, t2.testCode, trunc(t1.StartTime)'
            ||' ) a';
          end if;

      --dbms_output.put_line(sqlstr);
      if vNormalFLag = 1 then
        execute immediate replace(replace(replace(replace(sqlstr,'XXXXXXXXXX',''),'YYYYYYYYYY',''), 'SSSSDDDD', c_startDate), 'EEEEDDDD', c_endDate);
      end if;
      if vJTFLag = 1 and c_testCode in (401, 420, 421) then
         execute immediate replace(replace(replace(replace(sqlstr,'XXXXXXXXXX','Report'),'YYYYYYYYYY','Report_'||c_testCode), 'SSSSDDDD', c_JT_startDate), 'EEEEDDDD', c_JT_endDate);
      end if;

    end if;

  end;

-----------------------------------2017-04-25---表分区创建------------------

 procedure creatTablePartition
  is
    v_startDate       varchar2(200);
    v_partNum         varchar2(200);
    v_dpartNum        varchar2(200);
    vcut             number;
  begin
    -------------------备份结果话单 2个月以为---------------------
      select  to_char(sysdate+2,'YYYY-MM-DD'),'part_'||to_char(sysdate+2,'YYYYMMDD') into v_startDate,v_partNum  from dual;
      select  'part_'||to_char(sysdate-60,'YYYYMMDD') into v_dpartNum from dual;
       select count(*) into vcut from user_tab_partitions where upper(table_name)=upper('z_testResult') and Lower(partition_name) = Lower(v_partNum);
         if vcut = 0 then
            execute   immediate 'alter table z_testResult add partition '  ||v_partNum ||' values less than(to_date('''||v_startDate||''',''yyyy-mm-dd'')) tablespace TABLESPACE_TNITS';
         end if;
       select count(*) into vcut from user_tab_partitions where upper(table_name)=upper('z_testResult') and Lower(partition_name) = Lower(v_dpartNum);
         if vcut >0 then
           execute   immediate 'alter table z_testResult drop partition '||v_dpartNum||' update global indexes';
         end if;
       -----------------------备份历史话单 2个月以前-------------------
      select  to_char(sysdate-58,'YYYY-MM-DD'),'part_'||to_char(sysdate-58,'YYYYMMDD') into v_startDate,v_partNum  from dual;
      select  'part_'||to_char(sysdate-120,'YYYYMMDD') into v_dpartNum from dual;
       select count(*) into vcut from user_tab_partitions where upper(table_name)=upper('z_testResult_bak') and Lower(partition_name) = Lower(v_partNum);
         if vcut = 0 then
            execute   immediate 'alter table z_testResult_bak add partition '  ||v_partNum ||' values less than(to_date('''||v_startDate||''',''yyyy-mm-dd'')) tablespace TABLESPACE_TNITS';
         end if;
       select count(*) into vcut from user_tab_partitions where upper(table_name)=upper('z_testResult_bak') and Lower(partition_name) = Lower(v_dpartNum);
         if vcut >0 then
           execute   immediate 'alter table z_testResult_bak drop partition '||v_dpartNum||' update global indexes';
         end if; 
         
      commit;  
    Exception when others then
      rollback;
     -- dbms_output.put_line(sqlerrm);
 end;
end pkg_tnits_stat;


/
