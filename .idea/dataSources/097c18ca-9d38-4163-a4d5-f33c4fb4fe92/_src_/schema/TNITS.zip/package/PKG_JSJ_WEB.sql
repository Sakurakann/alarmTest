CREATE package PKG_JSJ_WEB is

  -- Author  : yuxinrong
  -- Created : 2016/9/10 13:31:51
  -- Purpose : 
  type rc_class is ref cursor;
  
  procedure SP_S_ModuleQueryBYRole(
    a_roleID        in number,
    a_isMenu        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

end PKG_JSJ_WEB;
/
