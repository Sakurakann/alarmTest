CREATE package body PKG_PGW_WEB is

  -- Private type declarations
  ---type <TypeName> is <Datatype>;
  
  -- Private constant declarations
  ---<ConstantName> constant <Datatype> := <Value>;

  -- Private variable declarations
  ---<VariableName> <Datatype>;

  -- Function and procedure implementations
 /*
  function <FunctionName>(<Parameter> <Datatype>) return <Datatype> is
    <LocalVariable> <Datatype>;
  begin
    <Statement>;
    return(<Result>);
  end;

begin
  */
  -- Initialization
 --- <Statement>;
 
     procedure sp_z_bill_detailCount(
       c_startTime   in varchar2,
       c_endTime     in varchar2,
       c_phone       in varchar2,
       c_def         in varchar2,
       Message         out varchar2,
       ResultCursor    out rc_class
     )is
       whereStr        VARCHAR2(2000) := ' 1=1 '; 
     begin
       Message := '查询任务成功!';
       if c_def is not null then whereStr :=whereStr  || ' and '|| c_def; end if;
       whereStr :=whereStr || ' and istdate between to_date(''' ||c_startTime||''',''yyyy-mm-dd hh24:mi'') and to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi'') ';
       if c_phone is not null then whereStr :=whereStr || ' and msisdn= '''|| c_phone || ''''; end if;
       open ResultCursor for 
            'select count(1) as executeNum from z_bill@tnitspgw where '|| whereStr ;
     exception when others then
       Message := '查询任务失败! '||substr(sqlerrm,1,100);
       open ResultCursor for select Message sqlmsg from dual;
     end sp_z_bill_detailCount;
     
     procedure sp_z_bill_detailQueryPage(
       c_startTime   in varchar2,
       c_endTime     in varchar2,
       c_phone       in varchar2,
       c_def         in varchar2,
       c_rowStart      in number,
       c_rowEnd        in number,
       Message         out varchar2,
       ResultCursor    out rc_class
     )is
       whereStr        VARCHAR2(2000) := ' 1=1 ';
     begin
       Message := '查询任务成功!';
       if c_def is not null then whereStr :=whereStr  || ' and '|| c_def; end if;
       whereStr :=whereStr || ' and istdate between to_date(''' ||c_startTime||''',''yyyy-mm-dd hh24:mi'') and to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi'') ';
       if c_phone is not null then whereStr :=whereStr || ' and msisdn= '''|| c_phone || ''''; end if;
       open ResultCursor for 
            'select * from (select rownum rownum_,b.* from (select (case when a.phone_type=1 and a.billtype=5 then '|| '''更新承载 ''' ||'when a.phone_type=1 and a.billtype=4 then '||'''删除承载 '''||' when a.phone_type=1 and a.billtype=1 then '||'''创建承载 '''||'  when a.phone_type=0 and a.billtype=5 then '||'''更新PDP '''||' when a.phone_type=0 and a.billtype=4 then '||'''删除PDP'''||' when a.phone_type=0 and a.billtype=1 then '||'''创建PDP'''||' else '' '' end) as actiontype ,'
            ||'(case when a.phone_type=1  then '||'''容错PGW'''||' when a.phone_type=0 then '||'''容错GGSN'''||' else '' '' end) as nename ,'
            ||'a.*  from z_bill@tnitspgw a where '|| whereStr || ' order by istdate desc ) b) where rownum_>='||c_rowStart|| ' and rownum_<='||c_rowEnd;
     exception when others then
       Message := '查询任务失败! '||substr(sqlerrm,1,100);
       open ResultCursor for select Message sqlmsg from dual;
     end sp_z_bill_detailQueryPage;
     
     procedure sp_z_billstatCount(
       c_startTime in varchar2,
       c_endTime   in varchar2,
        c_def         in varchar2,
       Message         out varchar2,
       ResultCursor    out rc_class
     )is
       whereStr     varchar2(2000) := ' 1=1 ';
     begin
       Message := '查询任务成功!';
     --  if c_phone is not null then whereStr :=whereStr || ' and msisdn= '''|| c_phone || ''''; end if;
       if c_def is not null then whereStr :=whereStr  || ' and '|| c_def; end if;
       whereStr :=whereStr || ' and statetime between to_date(''' ||c_startTime||''',''yyyy-mm-dd hh24:mi'') and to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi'') ';
       open ResultCursor for 
            'select count(1) as executeNum from z_billstat@tnitspgw where '|| whereStr;
     end sp_z_billstatCount;
     
     procedure sp_z_billstatChartQuery(
       c_startTime in varchar2,
       c_endTime   in varchar2,
        c_def         in varchar2,
        c_rowStart in number,
       c_rowEnd    in number,
       Message         out varchar2,
       ResultCursor    out rc_class
     )is
      whereStr        VARCHAR2(2000) := ' 1=1 ';
     begin 
       Message := '查询任务成功!';
     --  if c_phone is not null then whereStr :=whereStr || ' and msisdn= '''|| c_phone || ''''; end if;
       if c_def is not null then whereStr :=whereStr  || ' and '|| c_def; end if;
       whereStr :=whereStr || ' and statetime between to_date(''' ||c_startTime||''',''yyyy-mm-dd hh24:mi'') and to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi'') ';
       open ResultCursor for 
            ' select * from (select rownum rownum_,a.* from (select * from z_billstat@tnitspgw  where '|| whereStr ||' order by statetime ) a) where rownum_>='||c_rowStart|| ' and rownum_<='||c_rowEnd ||' order by  rownum_';
     end sp_z_billstatChartQuery;
     
     procedure sp_z_apnbillstatCount(
       c_startTime in varchar2,
       c_endTime   in varchar2,
       c_apn       in varchar2,
        c_def         in varchar2,
       Message         out varchar2,
       ResultCursor    out rc_class
     )is
       whereStr     varchar2(2000) := ' 1=1 ';
     begin
       Message := '查询任务成功!';
     --  if c_phone is not null then whereStr :=whereStr || ' and msisdn= '''|| c_phone || ''''; end if;
       if c_def is not null then whereStr :=whereStr  || ' and '|| c_def; end if;
       if c_apn is not null then whereStr :=whereStr  || ' and apn='''||c_apn||''''; end if;
       whereStr :=whereStr || ' and statetime between to_date(''' ||c_startTime||''',''yyyy-mm-dd hh24:mi'') and to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi'') ';
       open ResultCursor for 
            'select count(1) as executeNum from z_apn_billstat@tnitspgw where '|| whereStr;
     end sp_z_apnbillstatCount;
     
     procedure sp_z_apnbillstatChartQuery(
       c_startTime in varchar2,
       c_endTime   in varchar2,
        c_apn       in varchar2,
        c_def         in varchar2,
        c_rowStart in number,
       c_rowEnd    in number,
       Message         out varchar2,
       ResultCursor    out rc_class
     )is
      whereStr        VARCHAR2(2000) := ' 1=1 ';
     begin 
       Message := '查询任务成功!';
     --  if c_phone is not null then whereStr :=whereStr || ' and msisdn= '''|| c_phone || ''''; end if;
       if c_def is not null then whereStr :=whereStr  || ' and '|| c_def; end if;
       if c_apn is not null then whereStr :=whereStr  || ' and apn='''||c_apn||''''; end if;
       whereStr :=whereStr || ' and statetime between to_date(''' ||c_startTime||''',''yyyy-mm-dd hh24:mi'') and to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi'') ';
       open ResultCursor for 
            ' select * from (select rownum rownum_,a.* from (select * from z_apn_billstat@tnitspgw  where '|| whereStr ||' order by statetime ) a) where rownum_>='||c_rowStart|| ' and rownum_<='||c_rowEnd ||' order by  rownum_';
     end sp_z_apnbillstatChartQuery;
     
end PKG_PGW_WEB;
/
