CREATE package build_partition is

  -- Author  : CHEN
  -- Created : 2011-2-22 12:35:57
  -- Purpose :

  -- 删除分区
  procedure   drop_partition(v_table_name in varchar2);

  -- 增加分区
  procedure   add_partition(v_table_name in varchar2 ,
                             v_tablespace_name_in in varchar2 default null,
                               v_date in date
                               );
  -- 增加分区
  procedure   init_partitions(v_start_date in date, v_end_date in date);


end build_partition;


/
