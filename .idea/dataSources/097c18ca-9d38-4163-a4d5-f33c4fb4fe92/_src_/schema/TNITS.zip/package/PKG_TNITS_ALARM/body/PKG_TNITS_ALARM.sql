CREATE package body pkg_tnits_alarm is



--目前版本信息如下：
--修改日期 2013-09-26
--修改日期 2014-01-14 修改告警组名称长度
--修改日期 2014-02-28 修改
--修改日期 2014-12-05 修改 z_alarm表增加alarm_neName，alarm_num，remark，remark1四个字段
--修改日期 2015-01-06 修改 群组告警插入时alarmNumber 字段填组号  群号


  procedure ALarmCheck(
    a_cycle   number --单位：小时
  ) is
    vCount    number;
  begin
    select count(*) into vCount from Z_Alarm where taskID>0 and istdate between sysdate-a_cycle/24 and sysdate;
    if vCount = 0 then
      select count(*) into vCount from Z_AlarmHis where taskID>0 and istdate between sysdate-a_cycle/24 and sysdate;
    end if;
    if vCount = 0 then
        insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam)
                     values(SEQ_Z_ALARM_ID.Nextval, -1, '告警分析程序'||a_cycle||'小时内未提交告警！', -1, '', 0,
                            '平台告警', 6, '', '告警分析程序'||a_cycle||'小时内未提交告警！', 0,
                            -1, '', 1, -1, -1);
        commit;
    end if;
  exception when others then
    rollback;
  end;


  -----------------------------黑龙江告警修改-----------------
  procedure Alarm_Generation(
    a_taskID        in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number, --是否告警：0-清除告警 1-告警 2-关联告警，3-取消关联告警
    a_alarmFlag in number, --是否出过port  pool告警  0--未出  0x01--port  0x02-pool  0x03--port+pool
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    v_groupalarmDetail   Z_Alarm.alarmDetail%type;
    vZ_TaskInfo     Z_TaskInfo%ROWTYPE;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    ALARM_POOL_FLAG	  integer;
    RELATION_ALARM_FLAG   integer;
    SS_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_nename      varchar2(50) := '';
    v_groupname   varchar2(50) := '';
    v_grouppara   varchar2(80) := '';
    valarmcount    number:=0;
    vacount         number:=0;
    vacount2        number:=0;
    vacount3        number:=0;
    vacount4        number:=0;
    vacount5        number:=0;
    vacount6        number:=0;
    vacount7        number:=0;
    vacount8		number:=0;
    v_sendflag       number:=0;
    v_alarm_type    number:=0;
    v_alarm_time    number:=0;
    v_group_id      number:=0;
    v_taskid        number:=0;
    v_allcount      number:=0;
    
    v_zonghe_alarm_flag number:=0;
    
    v_port_alarm_nomal_flag      number:=0;
    v_pool_alarm_nomal_flag      number:=0;
	
	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
	
    --用于群组告警
    v_Group_Task_Policy      varchar2(80) := '';
    v_Group_Task_State_Policy varchar2(80) := '';
    v_Group_Each_Task_Policy      varchar2(80) := '';
    v_Policy_Count_Group     number:=0;
    v_Policy_Count_Group_Each    number:=0;
    v_Policy_Point_Group_Each    number:=0;
    v_Policy_Id_Group        number:=0;
    v_groupalarmtype         number:=0;
    v_Task_State_Count_Group number:=0;
    v_Task_Id_Group          number:=0;
    v_Task_State_Group       number:=0;
    v_Task_Total_State_Group  number:=0;
    v_Task_Real_State_Group  number:=0;
    v_Task_Look_State_Group  number:=0;
    v_Task_Policy_State_Group  number:=0;
    v_Policy_Count_Group_Check number:=0;
    v_Policy_Task_State_Group number:=0;
    vZ_AlarmPolicy_Group  Z_AlarmPolicy%ROWTYPE;
    --v_Group_Id_Insert_Alarm  Z_Alarm.id%type;
    v_Nomal_Alarm_Flag       number:=0;
    v_Group_Alarm_Flag       number:=0;

    v_Policy_Id_Group_Each   number:=0;
    v_groupalarmReasonFlag   number:=0;
    v_group_alarm_detail_flag number:=0;
    
    v_group_alarm_parm_count0 number:=0;
    v_group_alarm_parm_count1 number:=0;
    
    v_groupalarmReason   Z_Alarm.alarmDetail%type;
    v_groupalarmReasonDetail   Z_Alarm.alarmDetail%type;
    v_groupalarmReasonDetailEach   Z_Alarm.alarmDetail%type;

    begin
    select count(*) into vCount from Z_TaskInfo where taskID = a_taskID and alarmFlag > 0 and deleteFlag = 0;
    if vCount = 0 then -- 过滤不存在的任务
       return;
    end if;

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_taskID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;
    
    --增加AMALRM_POOL_FLAG=1 401 420 421只送pool告警到亿阳 普通告警只web显示不送亿阳 AMALRM_POOL_FLAG=0两种告警都送亿阳
	select NVL(paramValue,0) into ALARM_POOL_FLAG from S_Param where paramName = 'ALARM_POOL_FLAG';
	--增加port  pool出告警后普通告警是否出参数
	select NVL(paramValue,0) into v_pool_alarm_nomal_flag from S_Param where paramName = 'POOL_ALARAM_FLAG';
	select NVL(paramValue,0) into v_port_alarm_nomal_flag from S_Param where paramName = 'DUAN_ALARAM_FLAG';
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';
	
	if v_alarm_interval>0 then

		select count(*) into v_alarm_count from Z_Alarm  where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
		if v_alarm_count>0 then
			insert into Z_AlarmHis select * from Z_Alarm  where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
		    delete from Z_Alarm  where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			commit;
		end if;
	end if;

    select count(*) into vCount from Z_Alarm where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
    if vCount > 0 then
      select * into vZ_Alarm from Z_Alarm where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;

      if a_alarmKB = 1 or a_alarmKB = 2 then  --有告警

        --add by wxl 2010-01-05
        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_taskID > 0 then
          select * into vZ_TaskInfo from Z_TaskInfo where taskID = a_taskID;
          v_allcount:=vZ_Alarm.reCount+1;
          --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
          --v_upAlarmStr := '【'||v_allcount||'次重复告警】';
          v_alarmDetail := v_upAlarmStr || '[' || a_taskID || ':' ||vZ_TaskInfo.Taskname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
        else
          v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
        end if;

        update Z_Alarm set alarmDetail = v_alarmDetail,
        					alarm_neName = a_locationNeName,
        					alarm_num = a_errorCause,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1= a_failurecause
         where ID = vZ_Alarm.ID;

      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
 
 
       --组告警清除过程
       select count(*) into vcount from Z_TASK_ALARM_GROUP p,Z_ALARM_GROUP z where z.GROUPID=p.GROUPID  and  p.taskid=a_taskID;
       if  vcount>0 and a_alarmKB =3 then
              v_Nomal_Alarm_Flag :=1;
              DECLARE CURSOR ResultGroup IS -- 一个任务可以归属于多个组，搜索这个任务归属的组，每个组去查询策略
              select GROUPID from Z_TASK_ALARM_GROUP z  where z.taskid=a_taskID;
              BEGIN
              open ResultGroup;
              LOOP
                  FETCH ResultGroup INTO v_group_id;
                  exit when ResultGroup%notfound;
                     v_Group_Task_Policy := '';
                     --select alarmflag into v_Group_Alarm_Flag from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and rownum=1;
                     select alarmflag into v_Group_Alarm_Flag from Z_ALARM_GROUP where GROUPID = v_group_id;
                     v_Nomal_Alarm_Flag := v_Nomal_Alarm_Flag * v_Group_Alarm_Flag;
                     select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and taskid=a_taskID;
                     select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group from dual;

                     for N in 0..v_Policy_Count_Group-1 loop  -- 挨个查询策略，查找是否某个组有此任务的此策略的告警条件，若找不到返回
                         select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
                         if v_Policy_Id_Group = a_policyID then -- 找到某个组有此任务的此策略的告警条件
                            v_groupname := '';
                            select GROUPNAME,alarmparam,alarmtype into v_groupname,v_grouppara,v_groupalarmtype from Z_ALARM_GROUP where groupid = v_group_id;
                        
                            select count(*) into vacount4 from Z_ALARM  where taskname=v_groupname and taskid = -11 and alarmstate=0;

                            --if vacount4>0 then -- 有此组的组告警，如果没有，跳过组告警，还要考虑限定策略情况（未写）
                               if v_groupalarmtype = 1 then      -- 组告警统计类策略的处理
                                   select SF_StrArrayStr(alarmparam,'@',0) into  vacount5 from z_alarm_group where GROUPID=v_group_id;
                                   DECLARE CURSOR CleanCursor IS
                                    select TASKID from Z_TASK_ALARM_GROUP where GROUPID=v_group_id;
                                    BEGIN
                                    open CleanCursor;
                                    LOOP
                                        FETCH CleanCursor INTO v_taskid;
                                        exit when CleanCursor%notfound;
                                           select count(*) into vacount6 from Z_ALARM  where taskid=v_taskid and alarmstate=0;
                                           if vacount6>0 then
                                              vacount7:=vacount7+1;
                                           end if;
                                    END LOOP;

                                    close CleanCursor;
                                    end;
                                    if vacount7<=vacount5 then
                                       update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_groupname and taskid = -11;
                                       groups_alarm(v_group_id, v_groupname, 0);
                                    end if;
                               elsif v_groupalarmtype = 2 then      --限定类策略处理
                                  v_Task_Total_State_Group := 0;
                                  v_Policy_Task_State_Group :=0;
                                  select Get_StrArrayLength(v_grouppara,'$') into v_Task_State_Count_Group from dual; --查询组内有多少任务策略

                                  for N in 0..v_Task_State_Count_Group-1 loop     -- 对每个任务策略进行处理
                                      select SF_StrArrayStr(v_grouppara,'$',N) into  v_Group_Task_State_Policy from dual;
                                      select SF_StrArrayStr(v_Group_Task_State_Policy,'#',0) into  v_Task_Id_Group from dual;
                                      select SF_StrArrayStr(v_Group_Task_State_Policy,'#',1) into  v_Task_State_Group from dual; -- 读取每个任务的任务id和状态
                                      v_Task_Real_State_Group := 0;                -- 每个任务在组内真实的告警状态  0未告警 1告警  原因：策略的告警状态只要有一个告警，就满足条件
                                      v_Task_Look_State_Group := 0;                --当前任务状态初始为告警，0 告警 1未告警 原因：全部满足条件才告警
                                      if v_Task_State_Group = 1 and v_Task_Id_Group != a_taskID then --任务策略中要求告警的处理
                                         v_Group_Task_Policy := '';
                                         v_Task_Look_State_Group := 1;              -- 组内非本次任务的状态置为不告警
                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数

                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
                                             v_Task_Policy_State_Group := 0;
                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
                                                if vcount>0 then
                                                   v_Task_Policy_State_Group := 1;
                                                end if;
                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
                                         end loop;
                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
                                            v_Task_Look_State_Group := 0;
                                         end if;
                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group != a_taskID then ----任务策略中不要求告警的处理
                                         v_Group_Task_Policy := '';
                                         v_Task_Look_State_Group := 0;              -- 组内非本次任务的状态置为不告警
                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数

                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
                                             v_Task_Policy_State_Group := 0;
                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
                                                if vcount>0 then
                                                   v_Task_Policy_State_Group := 1;
                                                end if;
                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
                                         end loop;
                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
                                            v_Task_Look_State_Group := 1; -- 要求不告警的任务有告警
                                         end if;
                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group = a_taskID then -- 组内本次任务的状态置为不告警
                                         v_Policy_Task_State_Group := 1; -- 记录状态
                                      end if;
                                      v_Task_Total_State_Group := v_Task_Total_State_Group+v_Task_Look_State_Group;
                                   end loop ;

                                   if v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 0 then  --本次任务告警其他全部任务满足状态条件才清除告警
                                      if vacount4>0 then
                                         update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_groupname and taskid = -11;
                                         groups_alarm(v_group_id, v_groupname, 0);
                                      end if;
                                   elsif v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 1 then  --本次任务不告警其他全部任务满足状态条件进行告警
                                      if vacount4=0 then
                                         v_groupalarmDetail := '[' || v_group_id ||':'||'组告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
                                         insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                                         alarmParam,sendFlag,State,alarm_neName,alarm_num)
                                         values(SEQ_Z_ALARM_ID.Nextval, -11, v_groupname, v_groupname, v_group_id,
                                                         '数据告警',5,'[组关联告警]'||v_groupname, v_groupalarmDetail, 1,
                                                         v_grouppara,0,0,a_locationNeName,a_errorCause);
                                         groups_alarm(v_group_id, v_groupname, 1);
                                      end if;
                                   end if; -- if v_Task_Total_State_Group = 0 then
                                 elsif v_groupalarmtype = 3 then      --综合类策略处理 add by psc 20150915
                                  v_Task_Total_State_Group := 0;
                                  v_Policy_Task_State_Group :=0;
                                  v_zonghe_alarm_flag :=0;
                                  select Get_StrArrayLength(v_grouppara,'$') into v_Task_State_Count_Group from dual; --查询组内有多少任务策略
                                  for N in 0..v_Task_State_Count_Group-1 loop     -- 对每个任务策略进行处理
                                      select SF_StrArrayStr(v_grouppara,'$',N) into  v_Group_Task_State_Policy from dual;
                                      v_group_alarm_parm_count0:=0;
                                      select Get_StrArrayLength(v_Group_Task_State_Policy,'#') into v_group_alarm_parm_count0 from dual; 
                                      select Get_StrArrayLength(v_Group_Task_State_Policy,'@') into v_group_alarm_parm_count1 from dual;
                                      if v_group_alarm_parm_count0>1 then			--限定
                                      	   	select SF_StrArrayStr(v_Group_Task_State_Policy,'#',0) into  v_Task_Id_Group from dual;
		                                      select SF_StrArrayStr(v_Group_Task_State_Policy,'#',1) into  v_Task_State_Group from dual; -- 读取每个任务的任务id和状态
		                                      v_Task_Real_State_Group := 0;                -- 每个任务在组内真实的告警状态  0未告警 1告警  原因：策略的告警状态只要有一个告警，就满足条件
		                                      v_Task_Look_State_Group := 0;                --当前任务状态初始为告警，0 告警 1未告警 原因：全部满足条件才告警
		                                      if v_Task_State_Group = 1 and v_Task_Id_Group != a_taskID then --任务策略中要求告警的处理
		                                         v_Group_Task_Policy := '';
		                                         v_Task_Look_State_Group := 1;              -- 组内非本次任务的状态置为不告警
		                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
		                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数
		
		                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
		                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
		                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
		                                             v_Task_Policy_State_Group := 0;
		                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
		                                                if vcount>0 then
		                                                   v_Task_Policy_State_Group := 1;
		                                                   goto exit_task_policy_loop3;
		                                                end if;
		                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
		                                         end loop;
		                                         <<exit_task_policy_loop3>>
		                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
		                                            v_Task_Look_State_Group := 0;
		                                         end if;
		                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group != a_taskID then ----任务策略中不要求告警的处理
		                                         v_Group_Task_Policy := '';
		                                         v_Task_Look_State_Group := 0;              -- 组内非本次任务的状态置为不告警
		                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
		                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数
		
		                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
		                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
		                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
		                                             v_Task_Policy_State_Group := 0;
		                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
		                                                if vcount>0 then
		                                                   v_Task_Policy_State_Group := 1;
		                                                   goto exit_task_policy_loop4;
		                                                end if;
		                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
		                                         end loop;
		                                         <<exit_task_policy_loop4>>
		                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
		                                            v_Task_Look_State_Group := 1; -- 要求不告警的任务有告警
		                                         end if;
		                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group = a_taskID then -- 组内本次任务的状态置为不告警
		                                         v_Policy_Task_State_Group := 1; -- 记录状态
		                                      end if;
		                                      v_Task_Total_State_Group := v_Task_Total_State_Group+v_Task_Look_State_Group;
		                                   --end loop ;
		
		                                   if v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 0 then  --本次任务告警其他全部任务满足状态条件才清除告警
		                                      if vacount4>0 then
		                                         v_zonghe_alarm_flag := 0;
		                                      --   update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_groupname and taskid = -11;
		                                      --   groups_alarm(v_group_id, v_groupname, 0);
		                                      else
                                              v_zonghe_alarm_flag := 1;
                                              if v_group_alarm_detail_flag = 1 then
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
                                              else
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
                                             end if;
		                                      end if;
		                                   elsif v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 1 then  --本次任务不告警其他全部任务满足状态条件进行告警
		                                      if vacount4=0 then
		                                         v_zonghe_alarm_flag :=1;
		                                         if v_group_alarm_detail_flag = 1 then
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
                                              else
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
                                             end if;
		                                        -- v_groupalarmDetail := '[' || v_group_id ||':'||'组告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
		                                       --  insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
		                                        --                 alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
		                                       --                  alarmParam,sendFlag,State,alarm_neName,alarm_num)
		                                      --   values(SEQ_Z_ALARM_ID.Nextval, -11, v_groupname, v_groupname, v_group_id,
		                                     --                    '数据告警',5,'[组关联告警]'||v_groupname, v_groupalarmDetail, 1,
		                                     --                    v_grouppara,0,0,a_locationNeName,a_errorCause);
		                                     --    groups_alarm(v_group_id, v_groupname, 1);
		                                      end if;
		                                   end if; -- if v_Task_Total_State_Group = 0 then
                                      elsif v_group_alarm_parm_count1>1 then		--统计
                                      		select SF_StrArrayStr(v_Group_Task_State_Policy,'@',0) into  vacount5 from z_alarm_group where GROUPID=v_group_id;
			                                   DECLARE CURSOR CleanCursor IS
			                                    select TASKID from Z_TASK_ALARM_GROUP where GROUPID=v_group_id;
			                                    BEGIN
			                                    open CleanCursor;
			                                    LOOP
			                                        FETCH CleanCursor INTO v_taskid;
			                                        exit when CleanCursor%notfound;
			                                           
			                                           select Get_StrArrayLength(v_Group_Task_State_Policy,v_taskid) into vacount8 from dual;
			                                           if vacount8<= 0 then
				                                           select count(*) into vacount6 from Z_ALARM  where taskid=v_taskid and alarmstate=0;
				                                           if vacount6>0 then
				                                              vacount7:=vacount7+1;
				                                           end if;
				                                        end if;
			                                    END LOOP;
			
			                                    close CleanCursor;
			                                    end;
			                                    if vacount7<=vacount5 then
			                                       update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_groupname and taskid = -11;
			                                       groups_alarm(v_group_id, v_groupname, 0);
			                                    elsif (vacount7>=vacount5) and  v_zonghe_alarm_flag=1 and vacount4=0 then
			                                       	v_groupalarmDetail := '[' || v_group_id ||':'||'组告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
			                                         insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
			                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
			                                                         alarmParam,sendFlag,State,alarm_neName,alarm_num)
			                                         values(SEQ_Z_ALARM_ID.Nextval, -11, v_groupname, v_groupname, v_group_id,
			                                                         '数据告警',5,'[组关联告警]'||v_groupname, v_groupalarmDetail, 1,
			                                                         v_grouppara,0,0,a_locationNeName,a_errorCause);
			                                         groups_alarm(v_group_id, v_groupname, 1);
			                                       
			                                    end if;
                                      end if; --elsif v_group_alarm_parm_count1>0 then		--统计
                                   -- end if; -- if v_Task_Total_State_Group = 0 then
                                    end loop;
                                 end if; -- if v_groupalarmtype = 1 then
                               --end if;   -- if vacount4=0 then
                            end if; -- if v_Policy_Id_Group = a_policyID then
                        end loop; -- for N in 0..v_Policy_Count_Group-1 loop1
                END LOOP;
                close ResultGroup;
                end;
        end if; -- if  vcount>0 and a_alarmKB =2 then
       -- 结束组告警清除
       -- 工程割接告警屏蔽
        select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and p.taskid=a_taskID;
        if  vcount>0 then
        	--	goto proc_end;
            update Z_Alarm set alarmState = 2, sendFlag = 6, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        else  --不屏蔽
         if  v_Nomal_Alarm_Flag = 0 then

         /* if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
            update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
          else
            update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
          end if;*/
          select count(*) into vacount3 from z_netask where taskid=a_taskID;
         if vacount3>0 then
            select nename into v_nename from z_netask where taskid=a_taskID;
            ----------------告警种类------------------
             select paramvalue into v_alarm_time from s_param  where paramname='ALARM_TIME';
             select count(distinct(ALARMNUMBER)) into valarmcount  from Z_Alarm where  ALARMDATE>sysdate-v_alarm_time/1440 and taskid in ( select taskid from Z_netask  where nename=v_nename);
             select paramvalue into v_alarm_type from s_param  where paramname='ALARM_TYPE';

            select count(*) into vacount2 from z_alarm where switchname =v_nename and  alarmState = 0 and sendflag=1;
             if YY_CLEAR_ALARM_FLAG = 1 and (a_alarmKB = 0 or a_alarmKB = 3) then
              -- update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
               ------------告警种类小于规定则清除网元告警-----
               if v_nename is not null and valarmcount< v_alarm_type then
                   update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where switchname =v_nename  and alarmState = 0;
               end if;
             else
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
               if v_nename is not null and valarmcount< v_alarm_type then
                 update Z_Alarm set alarmState = 1, clearDate = sysdate where switchname =v_nename  and alarmState = 0;
               end if;
             end if;
              update Z_Alarm set  clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
              commit;
              update Z_Alarm set alarmState = 2 where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
          else
          
             select testcode into vacount2 from z_taskinfo where taskid  = a_taskID;
          	if (vacount2 = 401 or vacount2 = 420 or vacount2 = 421) and ALARM_POOL_FLAG=1 then
          		update Z_Alarm set alarmState = 2, sendFlag = 6, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber;
          	else
	            if YY_CLEAR_ALARM_FLAG = 1 and (a_alarmKB = 0 or a_alarmKB = 3) then
	              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
	            else
	              update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
	            end if;
	             update Z_Alarm set clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
	             commit;
	             update Z_Alarm set alarmState = 2 where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
	         end if;
          end if;
        else
          update Z_Alarm set clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=5;
          commit;
          update Z_Alarm set alarmState = 2 where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=5;
        end if;


        if vZ_TaskInfo.Testcode = 401 then
          Del_SwitchAlarm(vZ_TaskInfo.ToNeCode1, YY_CLEAR_ALARM_FLAG);
        end if;
      end if;
     end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_taskID > 0 then
          select * into vZ_TaskInfo from Z_TaskInfo where taskID = a_taskID;

          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            v_upAlarmCycle := vZ_TaskInfo.cycleValue * to_number(replace(vZ_AlarmPoint.upAlarmCycle,'c','')) / (24*60);
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
                                  union all
                                  select 1 from Z_AlarmHis where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and uptDate > sysdate - v_upAlarmCycle
                                 );
            --if vCount > 0 then
               --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_taskID || ':' ||vZ_TaskInfo.Taskname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';
--原关联告警项目只有a_alarmkb=1时才启动关联告警，组关联告警不再启动原关联告警 by WeiWei AT NANJING
          if RELATION_ALARM_FLAG = 1 and a_alarmKB = 1  and ( vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 402 )  then
          -- 2010-12-17 巍巍 Modify 关联告警，因为不同级别alarmNumber不同，添加条件 a.alarmNumber = vZ_AlarmPoint.Alarmnumber
            select count(*) into vCount from Z_Alarm a where alarmState = 0 and a.alarmNumber = vZ_AlarmPoint.Alarmnumber and exists
                  (select taskID from Z_TaskInfo b
                    where deleteFlag = 0
                      and b.taskID = a.taskID
                      and b.outNeCode = vZ_TaskInfo.outNeCode
                      and (b.toNeCode1 = vZ_TaskInfo.toNeCode1 or b.toNeCode1 is null)
                      and a.alarmdate>sysdate-1/96);
            if vCount > 3 then
              goto proc_end;
            end if;
          end if;

        else
          v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          vZ_TaskInfo.Taskname := '';
          vZ_TaskInfo.Testcode := -1;
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;



        select NVL(paramValue,1) into SS_ALARM_FLAG from S_Param where paramName = 'SS_ALARM_FLAG';
        if SS_ALARM_FLAG = 1 then
          if vZ_TaskInfo.remark1 = 1 and (vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 402) then
            select count(*) into vCount from Z_SSResult where task_ID = a_taskID and iam_d >= sysdate-1/24 and task_type = 1;
            if vCount > 0 then
              select '(PCM:'||cic7||')' into v_pcm from Z_SSResult where task_ID = a_taskID and iam_d >= sysdate-1/24 and task_type = 1 and rownum=1;
            end if;
          end if;
        end if;
        --新增工程割接告警屏蔽功能

        --修改组告警
        v_Nomal_Alarm_Flag :=0;
        select count(*) into vcount from Z_TASK_ALARM_GROUP p,Z_ALARM_GROUP z where z.GROUPID=p.GROUPID  and  p.taskid=a_taskID;
        if  vcount>0 and a_alarmKB =2 then
              v_Nomal_Alarm_Flag :=1;
              DECLARE CURSOR ResultGroup IS -- 一个任务可以归属于多个组，搜索这个任务归属的组，每个组去查询策略
              select GROUPID from Z_TASK_ALARM_GROUP z  where z.taskid=a_taskID;
              BEGIN
              open ResultGroup;
              LOOP
                  FETCH ResultGroup INTO v_group_id;
                  exit when ResultGroup%notfound;
                     v_Group_Task_Policy := '';
                     --select alarmflag into v_Group_Alarm_Flag from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and rownum=1;
                     select alarmflag into v_Group_Alarm_Flag from Z_ALARM_GROUP where GROUPID = v_group_id;
                     v_Nomal_Alarm_Flag := v_Nomal_Alarm_Flag * v_Group_Alarm_Flag;
                     select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and taskid=a_taskID;
                     select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group from dual;

                     for N in 0..v_Policy_Count_Group-1 loop  -- 挨个查询策略，查找是否某个组有此任务的此策略的告警条件，若找不到返回
                         select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
                         if v_Policy_Id_Group = a_policyID then -- 找到某个组有此任务的此策略的告警条件
                            v_groupname := '';
                            select GROUPNAME,alarmparam,alarmtype into v_groupname,v_grouppara,v_groupalarmtype from Z_ALARM_GROUP where groupid = v_group_id;
         
                            select count(*) into vacount4 from Z_ALARM  where taskname=v_groupname and taskid = -11 and alarmstate=0;
                            select paramvalue into v_group_alarm_detail_flag from s_param where paramname='GROUP_ALARAM_DETAIL_FLAG';

                            --if vacount4=0 then -- 没有此组的组告警，如果有，跳过组告警（可修改时间）
                               v_groupalarmDetail :='';
                               v_groupalarmReasonFlag :=0;
                               if v_groupalarmtype = 1 then      -- 组告警统计类策略的处理
                                  select SF_StrArrayStr(alarmparam,'@',0) into  vacount5 from z_alarm_group where GROUPID=v_group_id;
                                  DECLARE CURSOR ResultCursor IS  -- 进行统计
                                  select TASKID from Z_TASK_ALARM_GROUP where GROUPID=v_group_id;
                                  BEGIN
                                  open ResultCursor;
                                  LOOP
                                      FETCH ResultCursor INTO v_taskid;
                                      exit when ResultCursor%notfound;
                                        select REMARK into v_Group_Each_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and taskid=v_taskid;       --查询此任务的策略
                                        select Get_StrArrayLength(v_Group_Each_Task_Policy,',') into v_Policy_Count_Group_Each from dual;
                                        for N in 0..v_Policy_Count_Group_Each-1 loop                 --统计每个任务在组内此策略是否告警
                                            select SF_StrArrayStr(v_Group_Each_Task_Policy,',',N) into  v_Policy_Id_Group_Each from dual;
                                            select Alarmnumber into v_Policy_Point_Group_Each from z_Alarmpolicy where id = v_Policy_Id_Group_Each;
                                            select count(*) into vacount6 from Z_ALARM  where taskid=v_taskid and alarmstate=0 and alarmnumber=v_Policy_Point_Group_Each;
                                            if vacount6>0 then
                                               if(v_taskid != a_taskID) then            --如果有告警，计数
                                                   vacount7:=vacount7+1;
                                                   select alarmDetail into v_groupalarmReasonDetailEach from Z_ALARM  where taskid=v_taskid and alarmstate=0 and alarmnumber=v_Policy_Point_Group_Each;
                                               end if;
                                               goto ENDEACHTASK;                        --只要找到一个满足就跳出
                                            end if;
                                        end loop;
                                        <<ENDEACHTASK>>
                                        if vacount6>0 and v_taskid != a_taskID then     --拼接告警详情，加入每个任务id和状态，加每个失败详情
                                           if v_groupalarmReasonFlag = 0 then
                                              v_groupalarmReason := v_taskid||':1';
                                              --v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
                                              --modify by psc 2015-08-04  for sichuan
                                              if v_group_alarm_detail_flag = 1 then
                                              	v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
                                              else
                                              	v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
                                              end if;
                                           else
                                              v_groupalarmReason := v_groupalarmReason||''||v_taskid||':1';
                                              v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
                                           end if;
                                        else
                                           if v_groupalarmReasonFlag = 0 then
                                              v_groupalarmReason := v_taskid||':0';
                                           else
                                              v_groupalarmReason := v_groupalarmReason||''||v_taskid||':0';
                                           end if;
                                        end if;

                                  END LOOP;
                                  close ResultCursor;
                                  end;

                                  if vacount7>=vacount5-1 and vacount4=0 then   -- 统计结果处理 要减去本次任务的
                                     v_groupalarmDetail := '['||v_group_id||':'|| '组告警'||']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件,组告警原因：';
                                     insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                                         alarmParam,sendFlag,State,alarm_neName,alarm_num,remark1)
                                     values(SEQ_Z_ALARM_ID.Nextval, -11, v_groupname, v_groupname, v_group_id,
                                                         '数据告警',5,'[组关联告警]'||v_groupname, v_groupalarmDetail||v_groupalarmReasonDetail||v_alarmDetail, 1,
                                                         v_grouppara,0,0,a_locationNeName,a_errorCause,a_failurecause);
                                     groups_alarm(v_group_id, v_groupname, 1);
                                  end if;
                               elsif v_groupalarmtype = 2 then      --限定类策略处理
                                  v_Task_Total_State_Group := 0;
                                  v_Policy_Task_State_Group :=0;
                                  select Get_StrArrayLength(v_grouppara,'$') into v_Task_State_Count_Group from dual; --查询组内有多少任务策略
									
                                  for N in 0..v_Task_State_Count_Group-1 loop     -- 对每个任务策略进行处理
                                      
                                      select SF_StrArrayStr(v_grouppara,'$',N) into  v_Group_Task_State_Policy from dual;
                                      select SF_StrArrayStr(v_Group_Task_State_Policy,'#',0) into  v_Task_Id_Group from dual;
                                      select SF_StrArrayStr(v_Group_Task_State_Policy,'#',1) into  v_Task_State_Group from dual; -- 读取每个任务的任务id和状态
                                      v_Task_Real_State_Group := 0;                -- 每个任务在组内真实的告警状态  0未告警 1告警  原因：策略的告警状态只要有一个告警，就满足条件
                                      v_Task_Look_State_Group := 0;                --当前任务状态初始为告警，0 告警 1未告警 原因：全部任务告警才告警
                                      if v_Task_State_Group = 1 and v_Task_Id_Group != a_taskID then --任务策略中要求告警的处理
                                         v_Group_Task_Policy := '';
                                         v_Task_Look_State_Group := 1;              -- 组内非本次任务的状态置为不告警
                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数

                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
                                             v_Task_Policy_State_Group := 0;
                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
                                                if vcount>0 then
                                                   v_Task_Policy_State_Group := 1;
                                                end if;
                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
                                         end loop;
                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
                                            v_Task_Look_State_Group := 0;
                                         end if;
                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group != a_taskID then ----任务策略中不要求告警的处理
                                         v_Group_Task_Policy := '';
                                         v_Task_Look_State_Group := 0;              -- 组内非本次任务的状态置为不告警
                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数

                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
                                             v_Task_Policy_State_Group := 0;
                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
                                                if vcount>0 then
                                                   v_Task_Policy_State_Group := 1;
                                                end if;
                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
                                         end loop;
                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
                                            v_Task_Look_State_Group := 1; -- 要求不告警的任务有告警
                                         end if;
                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group = a_taskID then ----本次任务策略中要求不告警的处理
                                         v_Policy_Task_State_Group := 1; -- 记录状态
                                      end if;
                                      v_Task_Total_State_Group := v_Task_Total_State_Group+v_Task_Look_State_Group;
                                   end loop ;

                                   if v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件才告警
                                      if vacount4=0 then
                                          v_groupalarmDetail := '[' || v_group_id ||':' ||'关联组'||']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
                                          insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
                                                             alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                                             alarmParam,sendFlag,State,alarm_neName,alarm_num,remark1)
                                          values(SEQ_Z_ALARM_ID.Nextval, -11, v_groupname, v_groupname, v_group_id,
                                                             '数据告警',5,'[组关联告警]'||v_groupname, v_groupalarmDetail, 1,
                                                             v_grouppara,0,0,a_locationNeName,a_errorCause,a_failurecause);
                                          groups_alarm(v_group_id, v_groupname, 1);
                                      end if;
                                   elsif v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 1 then  --本次任务不要求告警其他全部任务满足状态条件清除告警
                                      if vacount4>0 then
                                      update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_groupname and taskid = -11;
                                      groups_alarm(v_group_id, v_groupname, 0);
                                      end if;
                                   end if; -- if v_Task_Total_State_Group = 0 then
                                  
                                 elsif  v_groupalarmtype = 3 then      --综合类策略处理
                                  v_Task_Total_State_Group := 0;
                                  v_Policy_Task_State_Group :=0;
                                  select Get_StrArrayLength(v_grouppara,'$') into v_Task_State_Count_Group from dual; --查询组内有多少任务策略
								                  v_zonghe_alarm_flag :=0;
                                  for N in 0..v_Task_State_Count_Group-1 loop     -- 对每个任务策略进行处理
                                     v_group_alarm_parm_count0:=0;
                                     select SF_StrArrayStr(v_grouppara,'$',N) into  v_Group_Task_State_Policy from dual;
                                      select Get_StrArrayLength(v_Group_Task_State_Policy,'#') into v_group_alarm_parm_count0 from dual; 
                                      select Get_StrArrayLength(v_Group_Task_State_Policy,'@') into v_group_alarm_parm_count1 from dual;
                                      if v_group_alarm_parm_count0>1 then			--限定
                                      		select SF_StrArrayStr(v_Group_Task_State_Policy,'#',0) into  v_Task_Id_Group from dual;
	                                      select SF_StrArrayStr(v_Group_Task_State_Policy,'#',1) into  v_Task_State_Group from dual; -- 读取每个任务的任务id和状态
	                                      v_Task_Real_State_Group := 0;                -- 每个任务在组内真实的告警状态  0未告警 1告警  原因：策略的告警状态只要有一个告警，就满足条件
	                                      v_Task_Look_State_Group := 0;                --当前任务状态初始为告警，0 告警 1未告警 原因：全部任务告警才告警
	                                      if v_Task_State_Group = 1 and v_Task_Id_Group != a_taskID then --任务策略中要求告警的处理
	                                         v_Group_Task_Policy := '';
	                                         v_Task_Look_State_Group := 1;              -- 组内非本次任务的状态置为不告警
	                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
	                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数
	
	                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
	                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
	                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
	                                             v_Task_Policy_State_Group := 0;
	                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
	                                                if vcount>0 then
	                                                   v_Task_Policy_State_Group := 1;
	                                                end if;
	                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
	                                         end loop;
	                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
	                                            v_Task_Look_State_Group := 0;
	                                         end if;
	                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group != a_taskID then ----任务策略中不要求告警的处理
	                                         v_Group_Task_Policy := '';
	                                         v_Task_Look_State_Group := 0;              -- 组内非本次任务的状态置为不告警
	                                         select remark into v_Group_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and TASKID = v_Task_Id_Group;
	                                         select Get_StrArrayLength(v_Group_Task_Policy,',') into v_Policy_Count_Group_Check from dual; -- 组内非本次任务的策略数
	
	                                         for N in 0..v_Policy_Count_Group_Check-1 loop     -- 对每个策略分析
	                                             select SF_StrArrayStr(v_Group_Task_Policy,',',N) into  v_Policy_Id_Group from dual;
	                                             select * into vZ_AlarmPolicy_Group from Z_AlarmPolicy where id = v_Policy_Id_Group;
	                                             v_Task_Policy_State_Group := 0;
	                                             select count(*) into vcount from Z_Alarm where taskID = v_Task_Id_Group and alarmNumber = vZ_AlarmPolicy_Group.Alarmnumber and alarmState = 0;
	                                             if vcount>0 then
	                                                   v_Task_Policy_State_Group := 1;
                                                     select alarmDetail into v_groupalarmReasonDetailEach from Z_ALARM  where taskid=v_taskid and alarmstate=0 and alarmnumber=vZ_AlarmPolicy_Group.Alarmnumber;
	                                             end if;
	                                             v_Task_Real_State_Group := v_Task_Real_State_Group+v_Task_Policy_State_Group;
	                                         end loop;
	                                         if v_Task_Real_State_Group >0 then -- 策略的告警状态只要有一个告警，就满足任务告警条件
	                                            v_Task_Look_State_Group := 1; -- 要求不告警的任务有告警
	                                         end if;
	                                      elsif v_Task_State_Group = 0 and v_Task_Id_Group = a_taskID then ----本次任务策略中要求不告警的处理
	                                         v_Policy_Task_State_Group := 1; -- 记录状态
	                                      end if;
	                                      v_Task_Total_State_Group := v_Task_Total_State_Group+v_Task_Look_State_Group;
	                                      
	                                       if v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 0 then  --本次任务告警其他全部任务满足状态条件才清除告警
		                                      if vacount4>0 then
		                                         v_zonghe_alarm_flag := 0;
                                          else
                                              v_zonghe_alarm_flag := 1;
                                              if v_group_alarm_detail_flag = 1 then
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
                                              else
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
                                             end if;
		                                      end if;
		                                   elsif v_Task_Total_State_Group = 0 and v_Policy_Task_State_Group = 1 then  --本次任务不告警其他全部任务满足状态条件进行告警
		                                      if vacount4=0 then
		                                         v_zonghe_alarm_flag :=1;
		                                         if v_group_alarm_detail_flag = 1 then
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
                                              else
                                             	    v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
                                             	end if;
		                                      end if;
		                                   end if;    -- if v_Task_Total_State_Group = 0 then
                                      elsif v_group_alarm_parm_count1>0 then			--统计
                                      		select SF_StrArrayStr(v_Group_Task_State_Policy,'@',0) into  vacount5 from z_alarm_group where GROUPID=v_group_id;
			                                  DECLARE CURSOR ResultCursor IS  -- 进行统计
			                                  select TASKID from Z_TASK_ALARM_GROUP where GROUPID=v_group_id;
			                                  BEGIN
			                                  open ResultCursor;
			                                  LOOP
			                                      FETCH ResultCursor INTO v_taskid;
			                                      exit when ResultCursor%notfound;
			                                        select REMARK into v_Group_Each_Task_Policy from Z_TASK_ALARM_GROUP where GROUPID = v_group_id and taskid=v_taskid;       --查询此任务的策略
			                                        select Get_StrArrayLength(v_Group_Each_Task_Policy,',') into v_Policy_Count_Group_Each from dual;
			                                        for N in 0..v_Policy_Count_Group_Each-1 loop                 --统计每个任务在组内此策略是否告警
			                                            select SF_StrArrayStr(v_Group_Each_Task_Policy,',',N) into  v_Policy_Id_Group_Each from dual;
			                                            select Alarmnumber into v_Policy_Point_Group_Each from z_Alarmpolicy where id = v_Policy_Id_Group_Each;
			                                            
			                                            select Get_StrArrayLength(v_grouppara,v_taskid) into vacount8 from dual;
			                                            if vacount8<= 1 then
				                                            select count(*) into vacount6 from Z_ALARM  where taskid=v_taskid and alarmstate=0 and alarmnumber=v_Policy_Point_Group_Each;
				                                            if vacount6>0 then
				                                               if(v_taskid != a_taskID) then            --如果有告警，计数
				                                                   vacount7:=vacount7+1;
				                                                   select alarmDetail into v_groupalarmReasonDetailEach from Z_ALARM  where taskid=v_taskid and alarmstate=0 and alarmnumber=v_Policy_Point_Group_Each;
				                                               end if;
				                                               goto ENDEACHTASK;                        --只要找到一个满足就跳出
				                                            end if;
				                                        end if;
			                                        end loop;
			                                        <<ENDEACHTASK>>
			                                        if vacount6>0 and v_taskid != a_taskID then     --拼接告警详情，加入每个任务id和状态，加每个失败详情
			                                           if v_groupalarmReasonFlag = 0 then
			                                              v_groupalarmReason := v_taskid||':1';
			                                              --v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
			                                              --modify by psc 2015-08-04  for sichuan
			                                              if v_group_alarm_detail_flag = 1 then
			                                              	v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
			                                              else
			                                              	v_groupalarmReasonDetail := v_groupalarmReasonDetailEach;
			                                              end if;
			                                           else
			                                              v_groupalarmReason := v_groupalarmReason||''||v_taskid||':1';
			                                              v_groupalarmReasonDetail := v_groupalarmReasonDetail||''||v_groupalarmReasonDetailEach;
			                                           end if;
			                                        else
			                                           if v_groupalarmReasonFlag = 0 then
			                                              v_groupalarmReason := v_taskid||':0';
			                                           else
			                                              v_groupalarmReason := v_groupalarmReason||''||v_taskid||':0';
			                                           end if;
			                                        end if;
			
			                                  END LOOP;
			                                  close ResultCursor;
			                                  end;
              												if vacount7<vacount5-1 then
              													update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_groupname and taskid = -11;
              	                                      			groups_alarm(v_group_id, v_groupname, 0);
              												elsif (vacount7>=vacount5-1) and  v_zonghe_alarm_flag=1 and vacount4=0 then
				                                     v_groupalarmDetail := '['||v_group_id||':'|| '组告警'||']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件,组告警原因：';
				                                     insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
				                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
				                                                         alarmParam,sendFlag,State,alarm_neName,alarm_num,remark1)
				                                     values(SEQ_Z_ALARM_ID.Nextval, -11, v_groupname, v_groupname, v_group_id,
				                                                         '数据告警',5,'[组关联告警]'||v_groupname, v_groupalarmDetail||v_groupalarmReasonDetail||v_alarmDetail, 1,
				                                                         v_grouppara,0,0,a_locationNeName,a_errorCause,a_failurecause);
				                                     groups_alarm(v_group_id, v_groupname, 1);
			                                  end if;
                                      end if; --if v_group_alarm_parm_count0>0 then	
                                   END LOOP;
                                 end if; -- if v_groupalarmtype = 1 then
                               --end if;   -- if vacount4=0 then
                            end if; -- if v_Policy_Id_Group = a_policyID then
                        end loop; -- for N in 0..v_Policy_Count_Group-1 loop1
                END LOOP;
                close ResultGroup;
                end;
        end if; -- if  vcount>0 and a_alarmKB =2 then
        --结束组告警

        -- 工程割接告警屏蔽
        select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and p.taskid=a_taskID;
        if  vcount>0 then
        	--	goto proc_end;
            insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname, vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,0,a_locationNeName,a_errorCause,a_failurecause);
        else  --不屏蔽
         if  v_Nomal_Alarm_Flag = 0 then
           select count(*) into vacount3 from z_netask where taskid=a_taskID;
           if vacount3>0 then
            select nename into v_nename from z_netask where taskid=a_taskID;
             if v_nename is not null then
               -------同一网元的告警种类-------
              select paramvalue into v_alarm_time from s_param  where paramname='ALARM_TIME';
              select count(distinct(ALARMNUMBER)) into valarmcount  from Z_Alarm where  taskid in ( select taskid from Z_netask  where nename=v_nename) and ALARMDATE>sysdate-v_alarm_time/1440;
             end if;
           end if;
               select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and p.taskid=a_taskID;
               if vcount >0 then
                v_sendflag:=9;
               end if;
               select paramvalue into v_alarm_type from s_param  where paramname='ALARM_TYPE';

               if valarmcount>=v_alarm_type  then
                 select count(*) into vacount from z_alarm where SWITCHNAME=v_nename;
                  if vacount>0 then
                     insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname,vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,v_sendflag,a_locationNeName,a_errorCause,a_failurecause);
                  else
                     insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,Sendflag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval,-3, v_nename||'网元严重告警请处理', -1, v_nename||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, 5, v_nename||'网元严重告警请处理', v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,v_sendflag,a_locationNeName,a_errorCause,a_failurecause);
                  end if;
              else
                  if (vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 420 or  vZ_TaskInfo.Testcode = 421) and ALARM_POOL_FLAG =1 then
              	  		v_sendflag:=5;
              	  end if;
                  
                  if (vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 420 or  vZ_TaskInfo.Testcode = 421) and (a_alarmFlag=2) and v_pool_alarm_nomal_flag=1 then
                     v_sendflag:=6;
                  elsif (vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 420 or  vZ_TaskInfo.Testcode = 421) and (a_alarmFlag=1) and v_port_alarm_nomal_flag=1 then
                     v_sendflag:=6;
                  elsif (vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 420 or  vZ_TaskInfo.Testcode = 421) and (a_alarmFlag=3) and (v_port_alarm_nomal_flag=1 or v_pool_alarm_nomal_flag=1) then
                     v_sendflag:=6;
                  end if;
                     
                   insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,Sendflag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname, vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,v_sendflag,a_locationNeName,a_errorCause,a_failurecause);
              end if;
        else --新增关于a_alarmkb=2时，插入记录不向外送
           insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname, vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,a_locationNeName,a_errorCause,a_failurecause);

        end if ;
      end if;
    end if;
    end if;
    commit;

    --调用判断关联告警存储过程
		--	RELATION_ALARM(a_taskid);
    if vZ_TaskInfo.Testcode = 401 then
      Add_SwitchAlarm; --处理交换机告警
    end if;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
    delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
    delete from Z_Alarm a where exists (select taskID from Z_TaskInfo b where taskStatus=3 and b.taskID = a.taskID) and alarmDate < sysdate-1;
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;


  procedure Alarm_Generation_port(
    a_portID        in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vz_Switch       i_Switch%ROWTYPE;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_name         varchar2(20) := '';
    v_count        number:=0;
	
	
	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
	
    begin

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_portID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';

    select  switchname into v_name from i_switch where switchid=a_portID;
     if v_name is not null then
		if v_alarm_interval>0 then
			select count(*) into v_alarm_count from Z_Alarm  where taskID = -10 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			if v_alarm_count>0 then
				insert into Z_AlarmHis select * from Z_Alarm  where taskID = -10 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				delete from Z_Alarm  where taskID = -10 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				commit;
			end if;
		end if;
        select count(*) into vCount from Z_Alarm where taskID = -10 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
     end if;


   -- select  remark into v_name from I_ne where neid=a_neid;
    if vCount > 0  then
       select * into vZ_Alarm from Z_Alarm where taskID = -10 and taskname=v_name  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;

       if a_alarmKB = 1 or a_alarmKB =2 then  --有告警
             select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
            if a_portID > 0 then
              select * into vz_Switch from i_Switch where switchid = a_portID;
              --v_count:=vZ_Alarm.reCount+1;
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||v_count||'次重复告警】';
              v_alarmDetail := v_upAlarmStr || '[' || a_portID || ':' ||vz_Switch.switchname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            else
              v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            end if;
           update Z_Alarm set alarmDetail = v_alarmDetail,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1 = a_failurecause
            where ID = vZ_Alarm.ID;
      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
       -- select remark into v_name from i_ne where neid=a_neID;
        if v_name is not null then
          select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=2 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;

      -- if vcount>0  or vCount1>0 then --server
       --   update Z_Alarm set alarmState = 1, sendFlag = 6, clearDate = sysdate where taskID = -9 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
      -- else---ne---
          --select nename into v_name2 from i_ne where neid=a_neID;
          if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
       --     if vcount>0 then
              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -10 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
           -- end if;
          else
       --     if vcount>0 then
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -10 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
         --   end if;

          end if;
     --  end if;
      end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_portID > 0 then
         select * into vz_Switch from i_Switch where switchid = a_portID;

          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = -9 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
            );
            --if vCount > 0 then
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_portID || ':' ||vz_Switch.switchname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';

        else
          v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          vz_Switch.switchname:= '';
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;

        select  switchname into v_name from i_switch where switchid=a_portID;

        if v_name is not null then
        select count(*) into vCount from Z_Alarm where taskID = -10 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
        end if;

        if  vcount>0  then
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, -10, vz_Switch.switchname,vZ_AlarmPolicy.Testcode , vz_Switch.switchname, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, '[端局失败]'||vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                           vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,1,a_failurecause);

         else
            if  a_alarmKB = 1 then
                    insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                    alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                    alarmParamType, alarmParam, clearMode, clearParamType, clearParam,State,remark1)
                      values(SEQ_Z_ALARM_ID.Nextval, -10, vz_Switch.switchname,vZ_AlarmPolicy.Testcode , vz_Switch.switchname, vZ_AlarmPoint.Alarmnumber,
                                    vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, '[端局失败]'||vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                    vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,1,a_failurecause);
            else --新增关于a_alarmkb=2时，插入记录不向外送by WeiWei AT NANJING
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,state,remark1)
                         values(SEQ_Z_ALARM_ID.Nextval, -10, vz_Switch.switchname, -1, vz_Switch.switchname, vZ_AlarmPoint.Alarmnumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,1,a_failurecause);

            end if ;
        end if;

      end if;
    end if;
    commit;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
    delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
    delete from Z_Alarm a where exists (select taskID from Z_TaskInfo b where taskStatus=3 and b.taskID = a.taskID) and alarmDate < sysdate-1;
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;




----msc pool告警-----

  procedure Alarm_Generation_mgw(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vz_ne           I_Ne%ROWTYPE;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_count        number:=0;
    vCount1        number:=0;
    v_name         varchar2(20) := '';
    v_name2        varchar2(20) := '';

	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
	
    begin

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_neID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;
	
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';
	
     ----server---
   --  select  count(*) into vCount from I_ne where neid=a_neid;
  --   if vCount>=0 then
        select  remark into v_name from I_ne where neid=a_neid;
         vCount:= 0;
		 v_alarm_count:=0;
       if v_name is not null then
			if v_alarm_interval>0 then
				select count(*) into v_alarm_count from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				if v_alarm_count > 0  then
					insert into Z_AlarmHis select * from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
					delete from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
					commit;
				end if;
				
			end if;	
			select count(*) into vCount from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
			
       end if;
   --  end if;
     ---ne---
     select  nename into v_name2 from I_ne where neid=a_neid;
	 v_alarm_count:=0;
	 if v_alarm_interval>0 then
		select count(*) into v_alarm_count from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
		if v_alarm_count > 0  then
			insert into Z_AlarmHis select * from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			delete from Z_Alarm where taskID = -9 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			commit;
		end if;
				
	end if;
	select count(*) into vCount1 from Z_Alarm where taskID = -9 and taskname=v_name2 and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
	
	
   -- select  remark into v_name from I_ne where neid=a_neid;
    if vCount > 0 or vCount1>0 then
         if vCount>0 then --server---
            select * into vZ_Alarm from Z_Alarm where taskID = -9 and taskname=v_name  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
         else---ne----
            select * into vZ_Alarm from Z_Alarm where taskID = -9 and taskname=v_name2  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
         end if;
       if a_alarmKB = 1 or a_alarmKB =2 then  --有告警
             select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
            if a_neID > 0 then
              select * into vz_ne from I_NE where neid = a_neID;
              --v_count:=vZ_Alarm.reCount+1;
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||v_count||'次重复告警】';
              v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||vz_ne.remark || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            else
              v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            end if;
           update Z_Alarm set alarmDetail = v_alarmDetail,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1 = a_failurecause
            where ID = vZ_Alarm.ID;
      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
       -- select remark into v_name from i_ne where neid=a_neID;
        if v_name is not null then
          select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=2 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
        select nename into v_name2 from i_ne where neid=a_neID;
        select count(*) into vCount1 from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID  and z.PROJSTATE=2 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name2;
      -- if vcount>0  or vCount1>0 then --server
       --   update Z_Alarm set alarmState = 1, sendFlag = 6, clearDate = sysdate where taskID = -9 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
      -- else---ne---
          --select nename into v_name2 from i_ne where neid=a_neID;
          if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
            if vcount>0 then
              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -9 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            else
              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -9 and SWITCHNAME=v_name2 and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            end if;
          else
            if vcount>0 then
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -9 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            else
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -9 and SWITCHNAME=v_name2 and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            end if;

          end if;
     --  end if;
      end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_neID > 0 then
         select * into vz_ne from I_NE where neid = a_neID;

          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = -9 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
            );
            --if vCount > 0 then
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||vz_ne.nename || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';

        else
          v_alarmDetail := '['||'0'||':'||vZ_AlarmPolicy.Testcode||':'|| vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          vz_ne.nename:= '';
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;

        --新增工程割接告警屏蔽功能
        select remark into v_name from i_ne where neid=a_neID;
        if v_name is not null then
             select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
         select nename into v_name2 from i_ne where neid=a_neID;
         select count(*) into vCount1 from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name2;

        if  vCount1>0 or vcount>0  then
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, -9, vz_ne.remark,vZ_AlarmPolicy.Testcode , vz_ne.nename||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                           vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,1,a_failurecause);

         else
            if  a_alarmKB = 1 then
                    insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                    alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                    alarmParamType, alarmParam, clearMode, clearParamType, clearParam,State,remark1)
                      values(SEQ_Z_ALARM_ID.Nextval, -9, vz_ne.nename,vZ_AlarmPolicy.Testcode , vz_ne.nename||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                    vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                    vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,1,a_failurecause);
            else --新增关于a_alarmkb=2时，插入记录不向外送by WeiWei AT NANJING
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,state,remark1)
                         values(SEQ_Z_ALARM_ID.Nextval, -9, vz_ne.nename, -1, vz_ne.nename||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,1,a_failurecause);

            end if ;
        end if;
      end if;
    end if;
    commit;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
     delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
     delete from Z_Alarm where alarmState = 1 and sendflag=6;--工单预约删除
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;

----时延波动告警-----
  procedure Alarm_Generation_delay(
    a_psNeName         in varchar2,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_count        number:=0;
    vCount1        number:=0;
    v_name         varchar2(20) := '';
    v_name2        varchar2(20) := '';
    v_taskname		varchar2(200) :='';
	
	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
begin

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_psNeName is not null then
      	select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      	return;
    end if;
    
    select taskname into v_taskname from z_taskinfo where taskid = a_psNeName;
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';
	if v_alarm_interval> 0 then
		select count(*) into v_alarm_count from Z_Alarm where taskID = -14 and switchname=a_psNeName and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
		if v_alarm_count>0 then
			insert into Z_AlarmHis select * from Z_Alarm where taskID = -14 and switchname=a_psNeName and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			delete from Z_Alarm  where taskID = -14 and switchname=a_psNeName and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			commit;
		end if;
	 end if;
	select count(*) into vCount from Z_Alarm where taskID = -14 and switchname=a_psNeName and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
    

    if vCount > 0 then
    	select * into vZ_Alarm from Z_Alarm where taskID = -14 and switchname=a_psNeName  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;         
  
       
	    if a_alarmKB = 1 or a_alarmKB =2 then  --有告警
	    	select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
	            	
	        v_alarmDetail := v_upAlarmStr || '[' ||a_psNeName||':'|| v_taskname || ':' ||vZ_AlarmPolicy.Testcode|| ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
	          
	       	update Z_Alarm set alarmDetail = v_alarmDetail,
	                       alarmState = 0,
	                       reCount = reCount + 1,
	                       uptDate = sysdate,
	                       remark1 = a_failurecause
	        where ID = vZ_Alarm.ID;
		else --清除告警
	
	        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
	 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
	               
			if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
			  	update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -14 and SWITCHNAME=a_psNeName and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
			else
			   	update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = -14 and SWITCHNAME=a_psNeName and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
			
			end if;
		end if;
		
    else
      	if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        	select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        

          	if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            	select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = -14 and v_taskname=a_psNeName and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
            					);
          	end if;

          	v_alarmDetail := v_upAlarmStr || '['||a_psNeName||':' || v_taskname || ':' ||vZ_AlarmPolicy.Testcode|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          	select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';


        	--新增工程割接告警屏蔽功能
       
			select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=a_psNeName;

        	if  vcount>0  then
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, -14, v_taskname,vZ_AlarmPolicy.Testcode , a_psNeName, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                           vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,1,a_failurecause);

         	else
            	if  a_alarmKB = 1 then
                    insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                    alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                    alarmParamType, alarmParam, clearMode, clearParamType, clearParam,State,remark1)
                      	values(SEQ_Z_ALARM_ID.Nextval, -14, v_taskname,vZ_AlarmPolicy.Testcode , a_psNeName, vZ_AlarmPoint.Alarmnumber,
                                    vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                    vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,1,a_failurecause);
            	else --新增关于a_alarmkb=2时，插入记录不向外送by WeiWei AT NANJING
                	insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,state,remark1)
                         values(SEQ_Z_ALARM_ID.Nextval, -14, v_taskname, -1, a_psNeName, vZ_AlarmPoint.Alarmnumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,1,a_failurecause);

            	end if ;
        	end if;
       end if;
    end if;
    commit;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
     delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
     delete from Z_Alarm where alarmState = 1 and sendflag=6;--工单预约删除
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;


  -- 删除交换机告警
  procedure Del_SwitchAlarm(
    a_switchCode    in varchar2,
    YY_CLEAR_ALARM_FLAG integer)
  is
    vCount          number;
  begin
    select count(*) into vCount from Z_Alarm a, Z_Taskinfo b where  a.taskID = b.taskID and toNeCode1 = a_SwitchCode;
    if vCount = 1 then -- 该交换机测试告警记录小于2条，清除告警
      if YY_CLEAR_ALARM_FLAG = 1 then
        update Z_Alarm set alarmState = 1, sendFlag =0 where alarmParam = a_SwitchCode;
      else
        delete from Z_Alarm where alarmParam = a_SwitchCode;
      end if;

      commit;
    end if;
  end;

  -- 添加交换机告警记录
  procedure Add_SwitchAlarm
  is
    v_taskID        Z_taskinfo.taskID%type;
    v_testCode      Z_taskinfo.testCode%type;
    v_switchCode    Z_taskinfo.toNeCode1%type;
    v_switchName    Z_taskinfo.toNeName1%type;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    v_count         integer;
  begin
    DECLARE CURSOR ResultCursor IS -- 取中继电路测试的告警记录
           select b.taskID, b.testCode, b.toNeCode1, b.toNeName1
            from Z_Alarm a, Z_taskinfo b
           where a.taskID = b.taskID
             and b.testCode = 401
             and taskStatus <= 2; --(taskStatus <= 2 or (taskStatus >= 3 and alarmSate > sysdate-1);

    BEGIN
      open ResultCursor;

      LOOP
        FETCH ResultCursor INTO v_taskID, v_testCode, v_switchCode, v_switchName;
        exit when ResultCursor%notfound;

        select count(*) into v_count from Z_Alarm where alarmParam = v_switchCode;
        if v_count = 0 then -- 没有该交换机告警记录
           select count(*) into v_count from Z_Alarm a, Z_taskinfo b
            where a.taskID = b.taskID
              and b.testCode = 401
              and taskStatus <= 2
              and toNeCode1 = toNeCode1;
          if v_count >= 2 then -- 存在2条以上的相同交换机告警，需要新增交换机告警记录

            select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = 10001; --交换机告警
            insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam)
                         values(SEQ_Z_ALARM_ID.Nextval, -3, '交换机('||v_switchName||')测试告警', v_testCode, v_switchName, vZ_AlarmPoint.alarmNumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, Get_alarmdetail(v_switchCode), vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPoint.AlarmParamType, v_switchCode, vZ_AlarmPoint.Clearmode, vZ_AlarmPoint.Clearparamtype, vZ_AlarmPoint.ClearParam);
            commit;
          end if;
        end if;

      END LOOP;
      close ResultCursor;
    exception when others then
      ROLLBACK;
      close ResultCursor;
    END;
  end;


  function Get_AlarmDetail(
    a_switchCode varchar2
  ) return varchar2
  is
    v_alarmDetail varchar2(600);
    v_taskName varchar2(50);
    v_switchName varchar2(50);
    v_taskID int;
    v_min_alarmDate date;
    iFirstFlag int;
  begin
    DECLARE CURSOR ResultCursor IS -- 取中继电路测试的告警记录
    select b.taskID, b.taskName, b.toNeName1, min(alarmDate)
      from Z_Alarm a, Z_TaskInfo b
     where a.taskID = b.taskID
       and b.testCode = 401
       and taskStatus <= 2
       and toNeCode1 = a_switchCode
     group by b.taskID, b.taskName;
    BEGIN
      v_alarmDetail := '';

      iFirstFlag := 1;
      open ResultCursor;
      LOOP
        FETCH ResultCursor INTO v_taskID, v_taskName, v_switchName, v_min_alarmDate;
        exit when ResultCursor%notfound;
        if iFirstFlag = 1 then

          v_taskName := substr(v_taskName, instr(v_taskName,'('),40); -- 获取任务名中的交换机路由表
          v_alarmDetail := '[交换机('||v_switchName||'):告警] 于'||to_char(v_min_alarmDate,'yyyy-mm-dd hh24:mi:ss')
             ||'与交换机('||v_switchName||')相关的多个测试任务(TASKID='
             ||to_char(v_taskID)||v_taskName;
          iFirstFlag := 0;
        else
          v_taskName := substr(v_taskName,instr(v_taskName,'('),40); -- 获取任务名中的交换机路由表
          v_alarmDetail := v_alarmDetail||', '||to_char(v_taskID)||v_taskName;
        end if;

      END LOOP;
      close ResultCursor;
      v_alarmDetail := v_alarmDetail||' )连续测试告警。';
      return v_alarmDetail;
    exception when others then
      ROLLBACK;
      close ResultCursor;
      return v_alarmDetail;
    END;
  end;

 procedure fail_bill_insert(
    a_neid          in number,
    a_progid        in number,
    a_alarmnumber   in number,
    a_taskid        in number,
    a_flag			in number)
  is
    v_name         varchar2(50):='';
    vCount         number:=0;
  begin
  	if a_flag =0 then
        select count(*) into vCount from i_ne where neid=a_neid;
        if vCount>0 then
           select nename into v_name from i_ne where neid=a_neid;
           insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
           values (SEQ_Z_TESTRESULT_FAILED.Nextval,v_name, a_progid, a_alarmnumber, sysdate, a_taskid);
        else
           insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
           values (SEQ_Z_TESTRESULT_FAILED.Nextval,'-1', a_progid, a_alarmnumber, sysdate, a_taskid);
        end if;
    elsif a_flag =1 then 
   		select  count(*) into vCount from i_switch where switchid=a_neid;
      if vCount>0 then
         select switchname into v_name from i_switch where switchid=a_neid;
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,v_name, a_progid, a_alarmnumber, sysdate, a_taskid);
      else
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,'-1', a_progid, a_alarmnumber, sysdate, a_taskid);
      end if;
    elsif a_flag =2 then 
   		select  count(*) into vCount from i_sgw where sgwid=a_neid;
      if vCount>0 then
         select sgwname into v_name from i_sgw where sgwid=a_neid;
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,v_name, a_progid, a_alarmnumber, sysdate, a_taskid);
      else
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,'-1', a_progid, a_alarmnumber, sysdate, a_taskid);
      end if;
    elsif a_flag =3 then 
   		select  count(*) into vCount from i_pgw where pgwid=a_neid;
      if vCount>0 then
         select pgwname into v_name from i_pgw where pgwid=a_neid;
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,v_name, a_progid, a_alarmnumber, sysdate, a_taskid);
      else
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,'-1', a_progid, a_alarmnumber, sysdate, a_taskid);
      end if;
     elsif a_flag =4 then 
   		select  count(*) into vCount from i_psbc where psbcid=a_neid;
      if vCount>0 then
         select psbcname into v_name from i_psbc where psbcid=a_neid;
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,v_name, a_progid, a_alarmnumber, sysdate, a_taskid);
      else
         insert into Z_TESTRESULT_FAILED (id,NENAME, PROG_ID, ALARM_NUMBER, ISTDATE, TASKID)
         values (SEQ_Z_TESTRESULT_FAILED.Nextval,'-1', a_progid, a_alarmnumber, sysdate, a_taskid);
      end if;
    
    end if;
      commit;
  exception when others then
    rollback;
  end;

procedure groups_alarm(
    a_groupid          in number,
    a_groupname        varchar2,
    a_alarmKB          in number)        -- 0 清除告警   1 告警
is
    v_alarmparam                 varchar2(64):='';
    v_id                         number:=0;
    v_Group_State_Count_Groups   number:=0;
    v_Group_Id_Groups            number:=0;
    v_Group_State_Groups         number:=0;
    v_Group_State_Policy         varchar2(64):='';
    v_count                      number:=0;
    v_count_group                number:=0;
    v_Group_Name                 varchar2(64):='';
    v_Groups_Name                varchar2(64):='';
    v_Total_State_Group          number:=0;
    v_Real_State_Group           number:=0;
    v_Policy_State_Group         number:=0;
    v_group_alarm_type			 number:=0;
    vacount5					 number:=0;
     vacount6					 number:=0;
    vacount7					 number:=0;
    vacount8					 number:=0;
    vacount9					 number:=0;
    v_groups_value				varchar2(200):='';
    v_groups_value_count		number:=0;
    v_groupalarmDetail           Z_Alarm.alarmDetail%type;
    
    v_group_alarm_parm_count0 number:=0;
    v_group_alarm_parm_count1 number:=0;
    v_zonghe_alarm_flag number:=0;
	
	

	
begin
    DECLARE CURSOR GroupCursor IS -- 取群告警策略
    select id from z_group_alaram where 1=1;

    BEGIN
    open GroupCursor;
    LOOP
        FETCH GroupCursor INTO v_id;
        exit when GroupCursor%notfound;
            select alarmparam,alarmtype,groups,name into v_alarmparam,v_group_alarm_type,v_groups_value,v_Groups_Name from z_group_alaram  where id=v_id;
			select count(*) into v_count from Z_ALARM  where taskname=v_Groups_Name and taskid = -12 and alarmstate=0;
			
			if v_group_alarm_type = 1 then			--统计
                	select SF_StrArrayStr(v_alarmparam,'@',0) into  vacount5 from dual;
                	select SF_StrArrayStr(v_alarmparam,'@',1) into  vacount6 from dual;
                	select Get_StrArrayLength(v_groups_value,',') into v_groups_value_count from dual; --查询群内有多少组策略
                	vacount7:=0;
                	for N in 0..v_groups_value_count-1 loop     -- 对每个组进行处理
                		select SF_StrArrayStr(v_groups_value,',',N) into  vacount9 from dual;
                		v_Group_Name :='';
                       select groupname into v_Group_Name from Z_ALARM_GROUP where GROUPID = vacount9;
                       select count(*) into v_count_group from Z_ALARM  where taskname=v_Group_Name and taskid = -11 and alarmstate=0; --查询群内其他组的告警状态
                       if v_count_group>0 then
                       		vacount7 := vacount7+1;	
                       end if;                	
                	end loop;
                	
                	if vacount7<vacount5 then
                		update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_Groups_Name and taskid = -12;
                	else
                		if v_count>0 then
                			update Z_Alarm set uptDate = sysdate where taskname=v_Groups_Name and taskid = -12;
                		else
                			v_groupalarmDetail := '[' || v_id ||':'||'群告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
	                                      insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
	                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
	                                                         alarmParam,sendFlag,State)
	                                      values(SEQ_Z_ALARM_ID.Nextval, -12, v_Groups_Name, v_Groups_Name, v_id,
	                                                         '数据告警',5,'[组关联告警]'||v_Groups_Name, v_groupalarmDetail, 1,
	                                                         v_alarmparam,0,0);
                		end if;
                	
                	end if;  
            elsif v_group_alarm_type = 2 then		--限定  
            	
            	select Get_StrArrayLength(v_alarmparam,'$') into v_Group_State_Count_Groups from dual; --查询群内有多少组策略
           		for N in 0..v_Group_State_Count_Groups-1 loop     -- 对每个策略进行处理
	                v_Group_State_Policy :='';
	                v_Group_Id_Groups :=0;
	                select SF_StrArrayStr(v_alarmparam,'$',N) into  v_Group_State_Policy from dual;
               
                	select SF_StrArrayStr(v_Group_State_Policy,'#',0) into  v_Group_Id_Groups from dual;
	                if v_Group_Id_Groups = a_groupid then             -- 群内有关于此组的策略
	                    select name into v_Groups_Name from z_group_alaram where id = v_id;
	                    
	                    v_Policy_State_Group := 0;
	
	                    for N in 0..v_Group_State_Count_Groups-1 loop     -- 对每个策略进行处理
	                        v_Group_State_Policy :='';
	                        v_Group_Id_Groups :=0;
	                        select SF_StrArrayStr(v_alarmparam,'$',N) into  v_Group_State_Policy from dual;
	                        select SF_StrArrayStr(v_Group_State_Policy,'#',0) into  v_Group_Id_Groups from dual;
	                        select SF_StrArrayStr(v_Group_State_Policy,'#',1) into  v_Group_State_Groups from dual;
	                        v_Real_State_Group := 0;                -- 每个组在群内真实的告警状态  0告警 1未告警  原因：全部满足条件才告警，所有都为0
	                        --v_Policy_State_Group := 0;
	                        if v_Group_State_Groups = 1 and v_Group_Id_Groups != a_groupid then --组策略中要求告警的处理
	                           v_Real_State_Group := 1;
	                           v_Group_Name :='';
	                           select groupname into v_Group_Name from Z_ALARM_GROUP where GROUPID = v_Group_Id_Groups;
	                           select count(*) into v_count_group from Z_ALARM  where taskname=v_Group_Name and taskid = -11 and alarmstate=0; --查询群内其他组的告警状态
	
	                           if v_count_group >0 then -- 组告警状态只要有一个告警，就满足告警条件，要求此组为告警条件，此组确实有告警，置为0，满足条件
	                              v_Real_State_Group := 0;
	                           end if;
	                        elsif v_Group_State_Groups = 0 and v_Group_Id_Groups != a_groupid then ----任务策略中不要求告警的处理
	                           v_Group_Name := '';
	                           v_Real_State_Group := 0;              -- 群内非本组的状态置为不告警
	                           select groupname into v_Group_Name from Z_ALARM_GROUP where GROUPID = v_Group_Id_Groups;
	                           select count(*) into v_count_group from Z_ALARM  where taskname=v_Group_Name and taskid = -11 and alarmstate=0; --查询群内其他组的告警状态
	
	                           if v_count_group >0 then -- 要求不告警的任务有告警
	                              v_Real_State_Group := 1; -- 要求不告警的任务有告警,置状态不满足
	                           end if;
	                        elsif v_Group_State_Groups = 0 and v_Group_Id_Groups = a_groupid then ----本次任务策略中要求不告警的处理
	                           v_Policy_State_Group := 1; -- 记录状态
	                        end if;
	                        v_Total_State_Group := v_Total_State_Group+v_Real_State_Group;
	                     end loop ;
	
	                    if v_count > 0 and a_alarmKB = 1 then        --群已经有告警，在组的策略是告警时进行时间更新，非告警时进行清除判断
	                       if v_Total_State_Group = 0 and v_Policy_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件才告警
	                          update Z_Alarm set uptDate = sysdate where taskname=v_Groups_Name and taskid = -12;
	                       elsif v_Total_State_Group = 0 and v_Policy_State_Group = 1 then  --本次任务不要求告警其他全部任务满足状态条件清除告警
	                          update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_Groups_Name and taskid = -12;
	                       end if;
	                    elsif v_count > 0 and a_alarmKB = 0 then     --群内有告警，进行清除告警判断
	                       if v_Total_State_Group = 0 and v_Policy_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件清除告警
	                          update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_Groups_Name and taskid = -12;
	                       end if;
	                    elsif v_count = 0 and a_alarmKB = 1 then     --群内无告警，进行告警判断, 要求本次有告警的
	                       if v_Total_State_Group = 0 and v_Policy_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件进行告警
	                          v_groupalarmDetail := '[' || v_id ||':'||'群告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
	                                      insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
	                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
	                                                         alarmParam,sendFlag,State)
	                                      values(SEQ_Z_ALARM_ID.Nextval, -12, v_Groups_Name, v_Groups_Name, v_id,
	                                                         '数据告警',5,'[组关联告警]'||v_Groups_Name, v_groupalarmDetail, 1,
	                                                         v_alarmparam,0,0);
	                       end if;
	                    elsif v_count = 0 and a_alarmKB = 0 then     --群内无告警，进行告警判断，要求本次无告警的
	                       if v_Total_State_Group = 0 and v_Policy_State_Group = 1 then  --本次任务要求无告警其他全部任务满足状态条件进行告警
	                          v_groupalarmDetail := '[' || v_id ||':'||'群告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
	                                      insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
	                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
	                                                         alarmParam,sendFlag,State)
	                                      values(SEQ_Z_ALARM_ID.Nextval, -12, v_Groups_Name, v_Groups_Name, v_id,
	                                                         '数据告警',5,'[组关联告警]'||v_Groups_Name, v_groupalarmDetail, 1,
	                                                         v_alarmparam,0,0);
	                        end if;
	                    end if;
	                end if;     -- if v_Group_Id_Groups = a_groupid then
	            end loop;
	         
           elsif v_group_alarm_type = 3 then		--综合
           		v_zonghe_alarm_flag :=0;
           		select Get_StrArrayLength(v_alarmparam,'$') into v_Group_State_Count_Groups from dual; --查询群内有多少组策略
           		for N in 0..v_Group_State_Count_Groups-1 loop     -- 对每个策略进行处理
	                v_Group_State_Policy :='';
	                v_Group_Id_Groups :=0;
	                select SF_StrArrayStr(v_alarmparam,'$',N) into  v_Group_State_Policy from dual;
                	
                	select Get_StrArrayLength(v_Group_State_Policy,'#') into v_group_alarm_parm_count0 from dual; 
                    select Get_StrArrayLength(v_Group_State_Policy,'@') into v_group_alarm_parm_count1 from dual;
                    
                    if v_group_alarm_parm_count0>0 then		--限定                    
                    	
                		select SF_StrArrayStr(v_Group_State_Policy,'#',0) into  v_Group_Id_Groups from dual;
		                if v_Group_Id_Groups = a_groupid then             -- 群内有关于此组的策略
		                    select name into v_Groups_Name from z_group_alaram where id = v_id;
		                    
		                    v_Policy_State_Group := 0;
		
		                    for N in 0..v_Group_State_Count_Groups-1 loop     -- 对每个策略进行处理
		                        v_Group_State_Policy :='';
		                        v_Group_Id_Groups :=0;
		                        select SF_StrArrayStr(v_alarmparam,'$',N) into  v_Group_State_Policy from dual;
		                        select SF_StrArrayStr(v_Group_State_Policy,'#',0) into  v_Group_Id_Groups from dual;
		                        select SF_StrArrayStr(v_Group_State_Policy,'#',1) into  v_Group_State_Groups from dual;
		                        v_Real_State_Group := 0;                -- 每个组在群内真实的告警状态  0告警 1未告警  原因：全部满足条件才告警，所有都为0
		                        --v_Policy_State_Group := 0;
		                        if v_Group_State_Groups = 1 and v_Group_Id_Groups != a_groupid then --组策略中要求告警的处理
		                           v_Real_State_Group := 1;
		                           v_Group_Name :='';
		                           select groupname into v_Group_Name from Z_ALARM_GROUP where GROUPID = v_Group_Id_Groups;
		                           select count(*) into v_count_group from Z_ALARM  where taskname=v_Group_Name and taskid = -11 and alarmstate=0; --查询群内其他组的告警状态
		
		                           if v_count_group >0 then -- 组告警状态只要有一个告警，就满足告警条件，要求此组为告警条件，此组确实有告警，置为0，满足条件
		                              v_Real_State_Group := 0;
		                           end if;
		                        elsif v_Group_State_Groups = 0 and v_Group_Id_Groups != a_groupid then ----任务策略中不要求告警的处理
		                           v_Group_Name := '';
		                           v_Real_State_Group := 0;              -- 群内非本组的状态置为不告警
		                           select groupname into v_Group_Name from Z_ALARM_GROUP where GROUPID = v_Group_Id_Groups;
		                           select count(*) into v_count_group from Z_ALARM  where taskname=v_Group_Name and taskid = -11 and alarmstate=0; --查询群内其他组的告警状态
		
		                           if v_count_group >0 then -- 要求不告警的任务有告警
		                              v_Real_State_Group := 1; -- 要求不告警的任务有告警,置状态不满足
		                           end if;
		                        elsif v_Group_State_Groups = 0 and v_Group_Id_Groups = a_groupid then ----本次任务策略中要求不告警的处理
		                           v_Policy_State_Group := 1; -- 记录状态
		                        end if;
		                        v_Total_State_Group := v_Total_State_Group+v_Real_State_Group;
		                     end loop ;
		
		                    if v_count > 0 and a_alarmKB = 1 then        --群已经有告警，在组的策略是告警时进行时间更新，非告警时进行清除判断
		                       if v_Total_State_Group = 0 and v_Policy_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件才告警
		                          update Z_Alarm set uptDate = sysdate where taskname=v_Groups_Name and taskid = -12;
		                       elsif v_Total_State_Group = 0 and v_Policy_State_Group = 1 then  --本次任务不要求告警其他全部任务满足状态条件清除告警
		                          update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_Groups_Name and taskid = -12;
		                       end if;
		                    elsif v_count > 0 and a_alarmKB = 0 then     --群内有告警，进行清除告警判断
		                       if v_Total_State_Group = 0 and v_Policy_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件清除告警
		                          update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_Groups_Name and taskid = -12;
		                       end if;
		                    elsif v_count = 0 and a_alarmKB = 1 then     --群内无告警，进行告警判断, 要求本次有告警的
		                       if v_Total_State_Group = 0 and v_Policy_State_Group = 0 then  --本次任务要求告警其他全部任务满足状态条件进行告警
		                          v_groupalarmDetail := '[' || v_id ||':'||'群告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
		                                      insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
		                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
		                                                         alarmParam,sendFlag,State)
		                                      values(SEQ_Z_ALARM_ID.Nextval, -12, v_Groups_Name, v_Groups_Name, v_id,
		                                                         '数据告警',5,'[组关联告警]'||v_Groups_Name, v_groupalarmDetail, 1,
		                                                         v_alarmparam,0,0);
		                       end if;
		                    elsif v_count = 0 and a_alarmKB = 0 then     --群内无告警，进行告警判断，要求本次无告警的
		                       if v_Total_State_Group = 0 and v_Policy_State_Group = 1 then  --本次任务要求无告警其他全部任务满足状态条件进行告警
		                          v_groupalarmDetail := '[' || v_id ||':'||'群告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
		                                      insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
		                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
		                                                         alarmParam,sendFlag,State)
		                                      values(SEQ_Z_ALARM_ID.Nextval, -12, v_Groups_Name, v_Groups_Name, v_id,
		                                                         '数据告警',5,'[组关联告警]'||v_Groups_Name, v_groupalarmDetail, 1,
		                                                         v_alarmparam,0,0);
		                        end if;
		                    end if;
		                end if;     -- if v_Group_Id_Groups = a_groupid then
		            elsif v_group_alarm_parm_count1>0 then		--统计
		            	select SF_StrArrayStr(v_Group_State_Policy,'@',0) into  vacount5 from dual;
	                	select SF_StrArrayStr(v_Group_State_Policy,'@',1) into  vacount6 from dual;
	                	select Get_StrArrayLength(v_groups_value,',') into v_groups_value_count from dual; --查询群内有多少组策略
	                	vacount7:=0;
	                	for N in 0..v_groups_value_count-1 loop     -- 对每个组进行处理
	                		select SF_StrArrayStr(v_groups_value,'，',N) into  vacount9 from dual;
	                		v_Group_Name :='';
	                       select groupname into v_Group_Name from Z_ALARM_GROUP where GROUPID = vacount9;
	                       select count(*) into v_count_group from Z_ALARM  where taskname=v_Group_Name and taskid = -11 and alarmstate=0; --查询群内其他组的告警状态
	                       
	                       select Get_StrArrayLength(v_groups_value,vacount9) into vacount8 from dual;
	                       if vacount8<= 0 then
		                       if v_count_group>0 then
		                       		vacount7 := vacount7+1;	
		                       end if;
		                   end if;                	
	                	end loop;
	                	
	                	if vacount7<vacount5 then
	                		update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskname=v_Groups_Name and taskid = -12;
	                	else
	                		if v_count>0 then
	                			update Z_Alarm set uptDate = sysdate where taskname=v_Groups_Name and taskid = -12;
	                		else
	                			v_groupalarmDetail := '[' || v_id ||':'||'群告警'|| ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| '满足关联组告警条件';
		                                      insert into Z_Alarm(id, taskID, taskName, switchName, alarmNumber,
		                                                         alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
		                                                         alarmParam,sendFlag,State)
		                                      values(SEQ_Z_ALARM_ID.Nextval, -12, v_Groups_Name, v_Groups_Name, v_id,
		                                                         '数据告警',5,'[组关联告警]'||v_Groups_Name, v_groupalarmDetail, 1,
		                                                         v_alarmparam,0,0);
	                		end if;
	                	
	                	end if;  
		            end if;
	                
            	end loop;    --
          end if;
                
    END LOOP;
    close GroupCursor;
    end;

end;

procedure Alarm_Shield(  --ips200设备告警
    a_shield_type      in number,--告警类型 1--主控板网络不可达  2--业务板网络不可达  3--NO.7信令不可达  4--M3UA信令不可达 5--单板状态异常 6--MSIP单板mount异常 
    a_alarmDetail   in varchar2,
    a_alarmKB       in number) --是否告警：1-告警 0-清除告警   

is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_count        number:=0;
    begin

    
    select count(*) into vCount from Z_Alarm where taskID = -13 and  alarmNumber = a_shield_type and alarmState = 0;
    
    if vCount > 0  then
       select * into vZ_Alarm from Z_Alarm where taskID = -13 and  alarmNumber = a_shield_type and alarmState = 0;

       if a_alarmKB = 1 then  --有告警           
          v_alarmDetail := '于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail ;
           update Z_Alarm set alarmDetail = v_alarmDetail,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate
            where ID = vZ_Alarm.ID;
       else --清除告警

          select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
  
          if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -13  and alarmNumber = a_shield_type and alarmState = 0;
          else
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -13 and  alarmNumber = a_shield_type and alarmState = 0;
          end if;
       end if;
    else
      if a_alarmKB = 1 then --新增告警
          v_alarmDetail := '于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail ;
          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';
       
                insert into Z_Alarm(id, taskID, taskName, testCode, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType,sendFlag,State)
                     values(SEQ_Z_ALARM_ID.Nextval, -13,'ips200告警',-1, a_shield_type,
                            '交换告警', 6, 'ips200告警',v_alarmDetail, 0,
                           -1,0,1);

      end if;
    end if;
    commit;
    
  
    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
     delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
     delete from Z_Alarm where alarmState = 1 and sendflag=6;--工单预约删除
    commit;
    
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;


 procedure Alarm_Generation_tlv(
    a_taskID        in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    v_groupalarmDetail   Z_Alarm.alarmDetail%type;
    vZ_TaskInfo     Z_TaskInfo%ROWTYPE;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    SS_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_nename      varchar2(50) := '';
    v_groupname   varchar2(50) := '';
    v_grouppara   varchar2(80) := '';
    valarmcount    number:=0;
    vacount         number:=0;
    vacount2        number:=0;
    vacount3        number:=0;
    vacount4        number:=0;
    vacount5        number:=0;
    vacount6        number:=0;
    vacount7        number:=0;
    v_sendflag       number:=0;
    v_alarm_type    number:=0;
    v_alarm_time    number:=0;
    v_group_id      number:=0;
    v_taskid        number:=0;
    v_allcount      number:=0;
	
	
	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;

    --用于群组告警
    v_Group_Task_Policy      varchar2(80) := '';
    v_Group_Task_State_Policy varchar2(80) := '';
    v_Group_Each_Task_Policy      varchar2(80) := '';
    v_Policy_Count_Group     number:=0;
    v_Policy_Count_Group_Each    number:=0;
    v_Policy_Point_Group_Each    number:=0;
    v_Policy_Id_Group        number:=0;
    v_groupalarmtype         number:=0;
    v_Task_State_Count_Group number:=0;
    v_Task_Id_Group          number:=0;
    v_Task_State_Group       number:=0;
    v_Task_Total_State_Group  number:=0;
    v_Task_Real_State_Group  number:=0;
    v_Task_Look_State_Group  number:=0;
    v_Task_Policy_State_Group  number:=0;
    v_Policy_Count_Group_Check number:=0;
    v_Policy_Task_State_Group number:=0;
    vZ_AlarmPolicy_Group  Z_AlarmPolicy%ROWTYPE;
    --v_Group_Id_Insert_Alarm  Z_Alarm.id%type;
    v_Nomal_Alarm_Flag       number:=0;
    v_Group_Alarm_Flag       number:=0;

    v_Policy_Id_Group_Each   number:=0;
    v_groupalarmReasonFlag   number:=0;
    v_groupalarmReason   Z_Alarm.alarmDetail%type;
    v_groupalarmReasonDetail   Z_Alarm.alarmDetail%type;
    v_groupalarmReasonDetailEach   Z_Alarm.alarmDetail%type;

    begin
    select count(*) into vCount from Z_TaskInfo where taskID = a_taskID and alarmFlag > 0 and deleteFlag = 0;
    if vCount = 0 then -- 过滤不存在的任务
       return;
    end if;

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_taskID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';

	if v_alarm_interval>0 then
		select count(*) into v_alarm_count from Z_Alarm  where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
		if v_alarm_count>0 then
			insert into Z_AlarmHis select * from Z_Alarm  where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			delete from Z_Alarm  where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			commit;
		end if;
	end if;
	select count(*) into vCount from Z_Alarm where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
	
	
    if vCount > 0 then
      select * into vZ_Alarm from Z_Alarm where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;

      if a_alarmKB = 1 or a_alarmKB = 2 then  --有告警

        --add by wxl 2010-01-05
        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_taskID > 0 then
          select * into vZ_TaskInfo from Z_TaskInfo where taskID = a_taskID;
          v_allcount:=vZ_Alarm.reCount+1;
          --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
          --v_upAlarmStr := '【'||v_allcount||'次重复告警】';
          v_alarmDetail := v_upAlarmStr || '[' || a_taskID || ':' ||vZ_TaskInfo.Taskname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
        else
          v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
        end if;

        update Z_Alarm set alarmDetail = v_alarmDetail,
        					alarm_neName = a_locationNeName,
        					alarm_num = a_errorCause,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1=a_failurecause
         where ID = vZ_Alarm.ID;

      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING

       
       -- 工程割接告警屏蔽
        select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and p.taskid=a_taskID;
        if  vcount>0 then
        	--	goto proc_end;
            update Z_Alarm set alarmState = 2, sendFlag = 6, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        else  --不屏蔽
         if  v_Nomal_Alarm_Flag = 0 then

         /* if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
            update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
          else
            update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
          end if;*/
          select count(*) into vacount3 from z_netask where taskid=a_taskID;
         if vacount3>0 then
            select nename into v_nename from z_netask where taskid=a_taskID;
            ----------------告警种类------------------
             select paramvalue into v_alarm_time from s_param  where paramname='ALARM_TIME';
             select count(distinct(ALARMNUMBER)) into valarmcount  from Z_Alarm where  ALARMDATE>sysdate-v_alarm_time/1440 and taskid in ( select taskid from Z_netask  where nename=v_nename);
             select paramvalue into v_alarm_type from s_param  where paramname='ALARM_TYPE';

            select count(*) into vacount2 from z_alarm where switchname =v_nename and  alarmState = 0 and sendflag=1;
             if YY_CLEAR_ALARM_FLAG = 1 and (a_alarmKB = 0 or a_alarmKB = 3) then
              -- update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
               ------------告警种类小于规定则清除网元告警-----
               if v_nename is not null and valarmcount< v_alarm_type then
                   update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where switchname =v_nename  and alarmState = 0;
               end if;
             else
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
               if v_nename is not null and valarmcount< v_alarm_type then
                 update Z_Alarm set alarmState = 1, clearDate = sysdate where switchname =v_nename  and alarmState = 0;
               end if;
             end if;
              update Z_Alarm set  clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
              commit;
              update Z_Alarm set alarmState = 2 where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
          else
             select testcode into vacount2 from z_taskinfo where taskid  = a_taskID;
          	if vacount2 = 401 or vacount2 = 420 or vacount2 = 421 then
          		update Z_Alarm set alarmState = 2, sendFlag = 6, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber;
          	else
	            if YY_CLEAR_ALARM_FLAG = 1 and (a_alarmKB = 0 or a_alarmKB = 3) then
	              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
	            else
	              update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
	            end if;
	             update Z_Alarm set clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
	             commit;
	             update Z_Alarm set alarmState = 2 where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=9;
	         end if;
          end if;
        else
          update Z_Alarm set clearDate = sysdate where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=5;
          commit;
          update Z_Alarm set alarmState = 2 where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and sendflag=5;
        end if;


        if vZ_TaskInfo.Testcode = 401 then
          Del_SwitchAlarm(vZ_TaskInfo.ToNeCode1, YY_CLEAR_ALARM_FLAG);
        end if;
      end if;
     end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_taskID > 0 then
          select * into vZ_TaskInfo from Z_TaskInfo where taskID = a_taskID;

          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            v_upAlarmCycle := vZ_TaskInfo.cycleValue * to_number(replace(vZ_AlarmPoint.upAlarmCycle,'c','')) / (24*60);
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
                                  union all
                                  select 1 from Z_AlarmHis where taskID = a_taskID and alarmNumber = vZ_AlarmPolicy.Alarmnumber and uptDate > sysdate - v_upAlarmCycle
                                 );
            --if vCount > 0 then
               --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_taskID || ':' ||vZ_TaskInfo.Taskname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';
--原关联告警项目只有a_alarmkb=1时才启动关联告警，组关联告警不再启动原关联告警 by WeiWei AT NANJING
          if RELATION_ALARM_FLAG = 1 and a_alarmKB = 1  and ( vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 402 )  then
          -- 2010-12-17 巍巍 Modify 关联告警，因为不同级别alarmNumber不同，添加条件 a.alarmNumber = vZ_AlarmPoint.Alarmnumber
            select count(*) into vCount from Z_Alarm a where alarmState = 0 and a.alarmNumber = vZ_AlarmPoint.Alarmnumber and exists
                  (select taskID from Z_TaskInfo b
                    where deleteFlag = 0
                      and b.taskID = a.taskID
                      and b.outNeCode = vZ_TaskInfo.outNeCode
                      and (b.toNeCode1 = vZ_TaskInfo.toNeCode1 or b.toNeCode1 is null)
                      and a.alarmdate>sysdate-1/96);
            if vCount > 3 then
              goto proc_end;
            end if;
          end if;

        else
          v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          vZ_TaskInfo.Taskname := '';
          vZ_TaskInfo.Testcode := -1;
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;



        select NVL(paramValue,1) into SS_ALARM_FLAG from S_Param where paramName = 'SS_ALARM_FLAG';
        if SS_ALARM_FLAG = 1 then
          if vZ_TaskInfo.remark1 = 1 and (vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 402) then
            select count(*) into vCount from Z_SSResult where task_ID = a_taskID and iam_d >= sysdate-1/24 and task_type = 1;
            if vCount > 0 then
              select '(PCM:'||cic7||')' into v_pcm from Z_SSResult where task_ID = a_taskID and iam_d >= sysdate-1/24 and task_type = 1 and rownum=1;
            end if;
          end if;
        end if;
        --新增工程割接告警屏蔽功能

        

        -- 工程割接告警屏蔽
        select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and p.taskid=a_taskID;
        if  vcount>0 then
        	--	goto proc_end;
            insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname, vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,0,a_locationNeName,a_errorCause,a_failurecause);
        else  --不屏蔽
         if  v_Nomal_Alarm_Flag = 0 then
           select count(*) into vacount3 from z_netask where taskid=a_taskID;
           if vacount3>0 then
            select nename into v_nename from z_netask where taskid=a_taskID;
             if v_nename is not null then
               -------同一网元的告警种类-------
              select paramvalue into v_alarm_time from s_param  where paramname='ALARM_TIME';
              select count(distinct(ALARMNUMBER)) into valarmcount  from Z_Alarm where  taskid in ( select taskid from Z_netask  where nename=v_nename) and ALARMDATE>sysdate-v_alarm_time/1440;
             end if;
           end if;
               select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and p.taskid=a_taskID;
               if vcount >0 then
                v_sendflag:=9;
               end if;
               select paramvalue into v_alarm_type from s_param  where paramname='ALARM_TYPE';

               if valarmcount>=v_alarm_type  then
                 select count(*) into vacount from z_alarm where SWITCHNAME=v_nename;
                  if vacount>0 then
                     insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname,vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,v_sendflag,a_locationNeName,a_errorCause,a_failurecause);
                  else
                     insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,Sendflag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval,-3, v_nename||'网元严重告警请处理', -1, v_nename||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, 5, v_nename||'网元严重告警请处理', v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,v_sendflag,a_locationNeName,a_errorCause,a_failurecause);
                  end if;
              else
                  if vZ_TaskInfo.Testcode = 401 or vZ_TaskInfo.Testcode = 420 or  vZ_TaskInfo.Testcode = 421 then
              	  		v_sendflag:=5;
              	  end if;
                   insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,Sendflag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname, vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,v_sendflag,a_locationNeName,a_errorCause,a_failurecause);
              end if;
        else --新增关于a_alarmkb=2时，插入记录不向外送
           insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,alarm_neName,alarm_num,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, a_taskID, vZ_TaskInfo.Taskname, vZ_TaskInfo.Testcode, vZ_TaskInfo.Tonename1||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                            vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,a_locationNeName,a_errorCause,a_failurecause);

        end if ;
      end if;
    end if;
    end if;
    commit;

    --调用判断关联告警存储过程
		--	RELATION_ALARM(a_taskid);
    if vZ_TaskInfo.Testcode = 401 then
      Add_SwitchAlarm; --处理交换机告警
    end if;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
    delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
    delete from Z_Alarm a where exists (select taskID from Z_TaskInfo b where taskStatus=3 and b.taskID = a.taskID) and alarmDate < sysdate-1;
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;
  
  
----sgw pool告警-----

  procedure Alarm_Generation_sgw(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_count        number:=0;
    vCount1        number:=0;
    v_name         varchar2(20) := '';
    v_name2        varchar2(20) := '';

	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
	
    begin

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';
	
    if a_neID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;

    select  sgwname into v_name from i_sgw where sgwid=a_neid;
     vCount:= 0;
   if v_name is not null then
		if v_alarm_interval>0 then
			select count(*) into v_alarm_count from Z_Alarm  where taskID = -15 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			if v_alarm_count>0 then
				insert into Z_AlarmHis select * from Z_Alarm  where taskID = -15 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				delete from Z_Alarm  where taskID = -15 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				commit;
			end if;
		end if;
		select count(*) into vCount from Z_Alarm where taskID = -15 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
   end if;
  
 
    if vCount > 0  then
         
       select * into vZ_Alarm from Z_Alarm where taskID = -15 and taskname=v_name  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
       
       if a_alarmKB = 1 or a_alarmKB =2 then  --有告警
             select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
            if a_neID > 0 then
          
              --v_count:=vZ_Alarm.reCount+1;
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||v_count||'次重复告警】';
              v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||v_name || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            else
              v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            end if;
           update Z_Alarm set alarmDetail = v_alarmDetail,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1 = a_failurecause
            where ID = vZ_Alarm.ID;
      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
     
        if v_name is not null then
          select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=2 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
        
          if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
            if vcount>0 then
              update Z_Alarm set alarmState = 1, sendFlag = 5, clearDate = sysdate where taskID = -15 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            else
              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -15 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            end if;
          else
            
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -15 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            

          end if;
     --  end if;
      end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_neID > 0 then
         
          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = -15 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
            );
            --if vCount > 0 then
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||v_name || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';

        else
          v_alarmDetail := '['||'0'||':'||vZ_AlarmPolicy.Testcode||':'|| vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;

        --新增工程割接告警屏蔽功能
        
        if v_name is not null then
             select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
         
        if vcount>0  then
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, -15, v_name,vZ_AlarmPolicy.Testcode , v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                           vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,1,a_failurecause);

         else
            if  a_alarmKB = 1 then
                    insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                    alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                    alarmParamType, alarmParam, clearMode, clearParamType, clearParam,State,remark1)
                      values(SEQ_Z_ALARM_ID.Nextval, -15, v_name,vZ_AlarmPolicy.Testcode , v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                    vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                    vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,1,a_failurecause);
            else --新增关于a_alarmkb=2时，插入记录不向外送by WeiWei AT NANJING
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,state,remark1)
                         values(SEQ_Z_ALARM_ID.Nextval, -15, v_name, -1, v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,1,a_failurecause);

            end if ;
        end if;
      end if;
    end if;
    commit;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
     delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
     delete from Z_Alarm where alarmState = 1 and sendflag=6;--工单预约删除
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;
  
  ----pgw pool告警-----

  procedure Alarm_Generation_pgw(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_count        number:=0;
    vCount1        number:=0;
    v_name         varchar2(20) := '';
    v_name2        varchar2(20) := '';

	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
	
    begin

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_neID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';

    select  pgwname into v_name from i_pgw where pgwid=a_neid;
     vCount:= 0;
   if v_name is not null then
		if v_alarm_interval>0 then
			select count(*) into v_alarm_count from Z_Alarm  where taskID = -16 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			if v_alarm_count>0 then
				insert into Z_AlarmHis select * from Z_Alarm  where taskID = -16 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				delete from Z_Alarm  where taskID = -16 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				commit;
			end if;
		end if;
		select count(*) into vCount from Z_Alarm where taskID = -16 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
   end if;
  
 
    if vCount > 0  then
         
       select * into vZ_Alarm from Z_Alarm where taskID = -16 and taskname=v_name  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
       
       if a_alarmKB = 1 or a_alarmKB =2 then  --有告警
             select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
            if a_neID > 0 then
          
              --v_count:=vZ_Alarm.reCount+1;
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||v_count||'次重复告警】';
              v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||v_name || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            else
              v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            end if;
           update Z_Alarm set alarmDetail = v_alarmDetail,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1=a_failurecause
            where ID = vZ_Alarm.ID;
      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
     
        if v_name is not null then
          select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=2 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
        
          if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
            if vcount>0 then
              update Z_Alarm set alarmState = 1, sendFlag = 5, clearDate = sysdate where taskID = -16 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            else
              update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -16 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            end if;
          else
           
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -16 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
             
           

          end if;
     --  end if;
      end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_neID > 0 then
         
          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = -16 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
            );
            --if vCount > 0 then
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||v_name || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';

        else
          v_alarmDetail := '['||'0'||':'||vZ_AlarmPolicy.Testcode||':'|| vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;

        --新增工程割接告警屏蔽功能
        
        if v_name is not null then
             select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
         
        if vcount>0  then
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, -16, v_name,vZ_AlarmPolicy.Testcode , v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                           vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,1,a_failurecause);

         else
            if  a_alarmKB = 1 then
                    insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                    alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                    alarmParamType, alarmParam, clearMode, clearParamType, clearParam,State,remark1)
                      values(SEQ_Z_ALARM_ID.Nextval, -16, v_name,vZ_AlarmPolicy.Testcode , v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                    vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                    vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,1,a_failurecause);
            else --新增关于a_alarmkb=2时，插入记录不向外送by WeiWei AT NANJING
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,state,remark1)
                         values(SEQ_Z_ALARM_ID.Nextval, -16, v_name, -1, v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,1,a_failurecause);

            end if ;
        end if;
      end if;
    end if;
    commit;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
     delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
     delete from Z_Alarm where alarmState = 1 and sendflag=6;--工单预约删除
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;
  
  ----psbc pool告警-----

  procedure Alarm_Generation_psbc(
    a_neID         in number,
    a_policyID      in number,
    a_alarmDetail   in varchar2,
    a_locationNeName in varchar2,
    a_errorCause	in number,
    a_alarmKB       in number,  --是否告警：1-告警 0-清除告警 2-关联告警，3-取消关联告警
    a_failurecause in varchar2)
  is
    vCount          number;
    v_upAlarmCycle  number;
    v_upAlarmStr    varchar2(20) := '';
    v_alarmDetail   Z_Alarm.alarmDetail%type;
    vZ_AlarmPoint   Z_AlarmPoint%ROWTYPE;
    vZ_AlarmPolicy  Z_AlarmPolicy%ROWTYPE;
    vZ_Alarm        Z_Alarm%ROWTYPE;
    YY_CLEAR_ALARM_FLAG   integer;
    RELATION_ALARM_FLAG   integer;
    v_pcm           varchar2(20) := '';
    v_count        number:=0;
    vCount1        number:=0;
    v_name         varchar2(20) := '';
    v_name2        varchar2(20) := '';

	v_alarm_interval			 number:=0;
	v_alarm_count        		number:=0;
	
    begin

    select count(*) into vCount from Z_AlarmPolicy where id = a_policyID and alarmOnOff = 1 ;
    if vCount = 0 then -- 过滤不存在的告警策略
       return;
    end if;

    if a_neID > 0 then
      select * into vZ_AlarmPolicy from Z_AlarmPolicy where id = a_policyID;
    else
      vZ_AlarmPolicy.Alarmnumber := a_policyID;
    end if;
	
	select NVL(paramValue,0) into v_alarm_interval from S_Param where paramName = 'ALARM_INTERVAL';

    select  psbcname into v_name from i_psbc where psbcid=a_neid;
     vCount:= 0;
   if v_name is not null then
		if v_alarm_interval>0 then
			select count(*) into v_alarm_count from Z_Alarm  where taskID = -17 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
			if v_alarm_count>0 then
				insert into Z_AlarmHis select * from Z_Alarm  where taskID = -17 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				delete from Z_Alarm  where taskID = -17 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0 and (ROUND(TO_NUMBER(sysdate - ALARMDATE) * 24) > v_alarm_interval);
				commit;
			end if;
		end if;
		select count(*) into vCount from Z_Alarm where taskID = -17 and taskname=v_name and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
   end if;
  
 
    if vCount > 0  then
         
       select * into vZ_Alarm from Z_Alarm where taskID = -17 and taskname=v_name  and testcode=vZ_AlarmPolicy.Testcode and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
       
       if a_alarmKB = 1 or a_alarmKB =2 then  --有告警
             select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
            if a_neID > 0 then
          
              --v_count:=vZ_Alarm.reCount+1;
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||v_count||'次重复告警】';
              v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||v_name || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            else
              v_alarmDetail := '[' || vZ_AlarmPoint.Pointname || ']于' || to_char(vZ_Alarm.alarmDate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;
            end if;
           update Z_Alarm set alarmDetail = v_alarmDetail,
                           alarmState = 0,
                           reCount = reCount + 1,
                           uptDate = sysdate,
                           remark1=a_failurecause
            where ID = vZ_Alarm.ID;
      else --清除告警

        select NVL(paramValue,1) into YY_CLEAR_ALARM_FLAG from S_Param where paramName = 'YY_CLEAR_ALARM_FLAG';
 --增加a_alarmKB=0时才向外送取消告警消息 by WeiWei AT NANJING
     
        if v_name is not null then
          select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=2 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
        
          if YY_CLEAR_ALARM_FLAG = 1 and a_alarmKB = 0 then
            if vcount>0 then
              update Z_Alarm set alarmState = 1, sendFlag = 5, clearDate = sysdate where taskID = -17 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
            else
               update Z_Alarm set alarmState = 1, sendFlag = 0, clearDate = sysdate where taskID = -17 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
             end if;
          else
            
               update Z_Alarm set alarmState = 1, clearDate = sysdate where taskID =  -17 and SWITCHNAME=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState = 0;
        

          end if;
     --  end if;
      end if;
    else
      if a_alarmKB = 1 or a_alarmKB =2 then --新增告警

        select * into vZ_AlarmPoint from Z_AlarmPoint where alarmNumber = vZ_AlarmPolicy.Alarmnumber;
        if a_neID > 0 then
         
          if instr(vZ_AlarmPoint.upAlarmCycle,'c')>0 then
            select count(*) into vCount from (
                                  select 1 from Z_Alarm where taskID = -17 and taskname=v_name and alarmNumber = vZ_AlarmPolicy.Alarmnumber and alarmState <> 2 and uptDate > sysdate - v_upAlarmCycle
            );
            --if vCount > 0 then
              --2013.4.27改，根据童文虎和吴晶晶要求修改，去掉次数显示
              --v_upAlarmStr := '【'||vCount||'次升级告警】';
            --end if;
          end if;

          v_alarmDetail := v_upAlarmStr || '[' || a_neID || ':' ||vZ_AlarmPolicy.Testcode||':'||v_name || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          select NVL(paramValue,1) into RELATION_ALARM_FLAG from S_Param where paramName = 'RELATION_ALARM_FLAG';

        else
          v_alarmDetail := '['||'0'||':'||vZ_AlarmPolicy.Testcode||':'|| vZ_AlarmPoint.Pointname || ']于' || to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||','|| a_alarmDetail || ',告警点'||vZ_AlarmPoint.Alarmnumber||vZ_AlarmPoint.pointName;

          
          vZ_AlarmPolicy.AlarmParamType := vZ_AlarmPoint.AlarmParamType;
          vZ_AlarmPolicy.AlarmParam := vZ_AlarmPoint.AlarmParam;
          vZ_AlarmPolicy.ClearMode := vZ_AlarmPoint.ClearMode;
          vZ_AlarmPolicy.ClearParamType := vZ_AlarmPoint.ClearParamType;
          vZ_AlarmPolicy.ClearParam := vZ_AlarmPoint.ClearParam;
        end if;

        --新增工程割接告警屏蔽功能
        
        if v_name is not null then
             select count(*) into vcount from Z_PROJECT_GROUP p,Z_PROJECTINFO z where p.PROJID=z.ID and z.PROJSTATE=1 and z.START_TIME<=sysdate and z.END_TIME>=sysdate and z.nename=v_name;
        end if;
         
        if vcount>0  then
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                            alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                            alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,State,remark1)
                     values(SEQ_Z_ALARM_ID.Nextval, -17, v_name,vZ_AlarmPolicy.Testcode , v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                            vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                           vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,6,1,a_failurecause);

         else
            if  a_alarmKB = 1 then
                    insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                    alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                    alarmParamType, alarmParam, clearMode, clearParamType, clearParam,State,remark1)
                      values(SEQ_Z_ALARM_ID.Nextval, -17, v_name,vZ_AlarmPolicy.Testcode , v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                    vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname,v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                    vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,1,a_failurecause);
            else --新增关于a_alarmkb=2时，插入记录不向外送by WeiWei AT NANJING
                insert into Z_Alarm(id, taskID, taskName, testCode, switchName, alarmNumber,
                                alarmClass, alarmLevel, alarmTitle, alarmDetail, alarmType,
                                alarmParamType, alarmParam, clearMode, clearParamType, clearParam,sendFlag,state,remark1)
                         values(SEQ_Z_ALARM_ID.Nextval, -17, v_name, -1, v_name||v_pcm, vZ_AlarmPoint.Alarmnumber,
                                vZ_AlarmPoint.Alarmclass, vZ_AlarmPoint.Alarmlevel, vZ_AlarmPoint.Pointname, v_alarmDetail, vZ_AlarmPoint.Alarmtype,
                                vZ_AlarmPolicy.AlarmParamType, vZ_AlarmPolicy.AlarmParam, vZ_AlarmPolicy.ClearMode, vZ_AlarmPolicy.ClearParamType, vZ_AlarmPolicy.ClearParam,5,1,a_failurecause);

            end if ;
        end if;
      end if;
    end if;
    commit;

    <<proc_end>>
    if YY_CLEAR_ALARM_FLAG = 0 then
      update Z_Alarm set alarmState = 2 where alarmState = 1;
    end if;
    --删除ALARM_STATE=2或alarm_date在1天以上且任务已经不在执行的告警记录 2007-09-04
     delete from Z_Alarm where alarmState = 2; --TG_Z_ALARM_DEL修改为 当alarmState更新为2时，删除告警
     delete from Z_Alarm where alarmState = 1 and sendflag=6;--工单预约删除
    commit;
  exception when others then
    rollback;
    dbms_output.put_line(sqlerrm);
  end;
  
end pkg_tnits_alarm;
/
