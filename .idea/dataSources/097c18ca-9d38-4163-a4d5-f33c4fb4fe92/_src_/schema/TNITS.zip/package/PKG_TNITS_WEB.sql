CREATE package pkg_tnits_web is

--------------------------------------------
-- Export file for user tnits             --
-- updated by zxp on  2017-08- 10--
--------------------------------------------

  type rc_class is ref cursor;

  function SF_GetMaxID(
    a_tableName     in varchar2,
    a_IDColumName   in varchar2
  ) return number;

  function SF_toDate(
    a_date          in varchar2
  ) return date;

  procedure SP_Query(
    a_sql           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- S_User : 用户管理
  procedure SP_S_UserManager(
    a_type          in varchar2,
    a_userID        in number,
    a_loginName     in varchar2,
    a_userName      in varchar2,
    a_password      in varchar2,
    a_roleID        in number,
    a_state         in number,
    a_areaID        in number,
    a_dpid          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_UserQuery(
    a_myRoleID      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_UserLogin(
    a_loginName     in varchar2,
    a_password      in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_UserLoginAuto(
    a_loginName       in varchar2,
    Message          out varchar2,
    ResultCursor     out rc_class);

  procedure SP_S_UserMpsd(
    a_userID        in number,
    a_password      in varchar2,
    Message         out VARCHAR2,
    ResultCursor    out rc_class);

  -- Role :角色管理
  procedure SP_S_RoleManager(
    a_type          in varchar2,
    a_roleID        in number,
    a_roleName      in varchar2,
    a_isAdmin       in number,
    a_state         in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_RoleQuery(
    a_myRoleID      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_RoleSetModules(
    a_roleID        in number,
    a_moduleIDs     in varchar2,
    a_powers        in varchar2,
    a_preCount      in number,
    a_seperator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Module : 模块管理
  procedure SP_S_ModuleManager(
    a_type          in varchar2,
    a_s_moduleID    in varchar2,
    a_moduleID      in varchar2,
    a_moduleName    in varchar2,
    a_state         in number,
    a_isMenu        in number,
    a_parent        in varchar2,
    a_hasChild      in number,
    a_url           in varchar2,
    a_img           in varchar2,
    a_power         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_ModuleQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_ModuleQueryByRole(
    a_roleID        in number,
    a_isMenu        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- SysLog : 日志管理
  procedure SP_S_LogAdd(
    a_logType       in number,
    a_context       in varchar2,
    a_operator      in varchar2,
    a_ipAddress     in varchar2,
    a_roleid        in number, --角色id
    a_dpid          in number,--部门id
    a_module        in varchar2,--模块
    a_command       in varchar2,--方法
    a_areaid        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_NeLinkTree(
    a_layerNum      in number,
    a_mark          in number,
    a_ids           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_LogDel(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    a_operator      in varchar2,
    a_context       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_LogQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    a_operator      in varchar2,
    a_context       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Param :系统参数管理
  procedure SP_S_ParamManager(
    a_type          in varchar2,
    a_id            in number,
    a_paramName     in varchar2,
    a_paramValue    in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_ParamQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

 -- DataParam :数据过滤管理
  procedure SP_S_DataParamManager(
    a_type          in varchar2,
    a_id            in number,
    a_dataType      in varchar2,
    a_dataTypeName  in varchar2,
    a_dataValue     in varchar2,
    a_minValue      in varchar2,
    a_maxValue      in varchar2,
    a_isActivate    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   -- DataParam :数据过滤条件查询
  procedure SP_S_DataParamQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- S_TestCode : 测试方式管理
  procedure SP_S_TestCodeManager(
    a_type          in varchar2,
    a_testCode      in number,
    a_testName      in varchar2,
    a_smpName       in varchar2,
    a_state         in number,
    a_billTimeOut   in number,
    a_redoParam     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_TestCodeQuery(
    a_state         in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- S_TestCode : 测试类别管理
  procedure SP_S_TestTypeManager(
    a_type          in varchar2,
    a_id            in number,
    a_testTypeName  in varchar2,
    a_state         in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_TestTypeQuery(
    a_state         in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- S_PlatForm : 平台信息管理
  procedure SP_S_PlatFormManager(
    a_type          in varchar2,
    a_platFormID    in number,
    a_platFormName  in varchar2,
    a_status        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_TestCodeByMsisdnQuery(
    a_msisdn        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_PlatFormQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Area : 地区管理
  procedure SP_I_AreaManager(
    a_type          in varchar2,
    a_areaID        in number,
    a_areaName      in varchar2,
    a_areaCode      in varchar2,
    a_remark1       in varchar2,
    a_remark2       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_AreaQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Switch : 交换机管理
  procedure SP_I_SwitchManager(
    a_type          in varchar2,
    a_switchID      in number,
    a_switchName    in varchar2,
    a_switchType    in number,
    a_switchCode    in varchar2,
    a_areaID        in number,
    a_router        in number,
    a_ssCode        in varchar2,
    a_remark        in varchar2,
    a_stype          in varchar2,
    a_intid         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Switch : 交换机管理2
  procedure SP_I_SwitchManager2(
    a_type          in varchar2,
    a_switchID      in varchar2,
    a_switchName    in varchar2,
    a_switchType    in varchar2,
    a_switchCode    in varchar2,
    a_areaID        in varchar2,
    a_router        in varchar2,
    a_ssCode        in varchar2,
    a_remark        in varchar2,
    a_preCount      in number,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_SwitchQuery(
    a_switchName    in varchar2,
    a_switchType    in number,
    a_areaID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_SwitchResource : 交换机同步更新
  procedure SP_I_SwitchResourceManager(
    a_type          in varchar2,
    a_switchID      in number,
    a_ywjc_switchID in varchar2,
    a_switchName    in varchar2,
    a_switchType    in number,
    a_switchCode    in varchar2,
    a_areaID        in number,
    a_router        in number,
    a_ssCode        in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_SwitchResourceQuery(
    a_stateFlag     in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Scp : 智能设备管理
  procedure SP_I_ScpManager(
    a_type          in varchar2,
    a_scpID         in number,
    a_scpName       in varchar2,
    a_scpType       in number,
    a_areaID        in number,
    a_fixCode       in varchar2,
    a_longCode      in varchar2,
    a_shortCode     in varchar2,
    a_defCaller     in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_ScpQuery(
    a_scpName       in varchar2,
    a_scpType       in number,
    a_areaID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

 -- I_Stp : 信令路由管理
  procedure SP_I_StpManager(
    a_type          in varchar2,
    a_stpID         in number,
    a_stpName       in varchar2,
    a_stpCode       in varchar2,
    a_router        in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_StpQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_CrResource : 彩铃资源管理
  procedure SP_I_CrResourceManager(
    a_type          in varchar2,
    a_switchID      in number,
    a_shortCode     in varchar2,
    a_dtmfCode      in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_CrResourceQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_RncResource : RNC资源管理
  procedure SP_I_RncResourceManager(
    a_type          in varchar2,
    a_switchID      in number,
    a_rncName       in varchar2,
    a_shortCode     in varchar2,
    a_remark        in varchar2,
    a_tac           in number,
    a_lac           in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_RncResourceQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_BSCResource : BSC资源查询
  procedure SP_I_BSCResourceQuery(
    a_areaName      in varchar2,
    a_rtpName       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_GTNo : MAP网元管理
  procedure SP_I_GTNoManager(
    a_type          in varchar2,
    a_gtID          in number,
    a_gtName        in varchar2,
    a_gtNo          in varchar2,
    a_gtType        in number,
    a_remark        in varchar2,
    a_areaID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_GTNoQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_GTDetail : MAP测试号码管理
 procedure SP_I_GTDetailManager(
    a_type          in varchar2,
    a_id            in number,
    a_gtHLRID       in number,
    a_gtSCID        in number,
    a_imsi          in varchar2,
    a_msisdn        in varchar2,
    a_shortNo       in varchar2,
    a_netIndex      in number,
    a_msisdn2       in varchar2,
    a_remark        in varchar2,
    a_roleid        in number,
    a_testType      in varchar2,
    a_simType       in number,
    a_opc           in varchar2,
    a_ki            in varchar2,
    a_state         in number,
    a_netType       in number,
    a_fetion        in varchar2,
    a_areaid        in number,
    a_type2          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_GTDetailQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Bulletin : 公告管理
  procedure SP_I_BulletinManager(
    a_type          in varchar2,
    a_id            in number,
    a_title         in varchar2,
    a_content       in varchar2,
    a_bType         in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_BulletinQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_SCPrefix : 短信中心号段管理
  procedure SP_I_SCPrefixManager(
    a_type          in varchar2,
    a_prefix        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_SCPrefixQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_SCData : 短信中心号段管理
  procedure SP_I_SCDataManager(
    a_type          in varchar2,
    a_gtSCID        in number,
    a_prefix        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_SCDataQuery(
    c_gtSCID        in number,
    c_prefix        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_PhoneType : 用户属性管理
  procedure SP_I_PhoneTypeManager(
    a_type          in varchar2,
    a_id            in number,
    a_typeName      in varchar2,
    a_defPhone      in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_PhoneTypeQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_SmcPhone : 短信转发号码管理
  procedure SP_I_SmcPhoneManager(
    a_type          in varchar2,
    a_ID            in number,
    a_groupID       in number,
    a_phone         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_SmcPhoneQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Smgw : 短信网关管理
  procedure SP_I_SmgwManager(
    a_type          in varchar2,
    a_smgwID        in number,
    a_smgwName      in varchar2,
    a_smgwIP        in varchar2,
    a_smgwPort      in varchar2,
    a_spUid         in varchar2,
    a_spPwd         in varchar2,
    a_spNumber      in varchar2,
    a_route         in number,
     a_smgwtype      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_SmgwQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Ne : 网元资源管理
  procedure SP_I_NeManager(
    a_type          in varchar2,
    a_neID          in number,
    a_neName        in varchar2,
    a_neType        in number,
    a_state         in number,
    a_areaName      in varchar2,
    a_loopBackIP    in varchar2,
    a_netIP         in varchar2,
    a_address       in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_NeQuery(
    a_neName        in  varchar2,
    a_neType        in  number,
    a_areaName        in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_NeNodeQuery(
    a_neName        in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_NeInterfaceManager(
    a_type            in varchar2,
    a_interfaceID     in number,
    a_neID            in number,
    a_neName          in varchar2,
    a_nePort          in varchar2,
    a_interfaceAddr   in number,
    a_interfaceType   in varchar2,
    a_portID          in varchar2,
    a_portType        in varchar2,
    a_portIP          in varchar2,
    a_linkName        in varchar2,
    a_vlan            in varchar2,
    a_linkType        in varchar2,
    a_neteType        in varchar2,
    a_transRoute      in varchar2,
    a_route           in varchar2,
    a_d_odf           in varchar2,
    a_t_odf           in varchar2,
    a_state           in number,
    a_remark          in varchar2,
    Message           out varchar2,
    ResultCursor      out rc_class);

    procedure SP_I_NeInterfaceQuery(
    a_neName        in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_NodeManager(
    a_type          in varchar2,
    a_nodeID        in number,
    a_neID          in number,
    a_neName        in varchar2,
    a_ipnet         in varchar2,
    a_inteface      in varchar2,
    a_linkName      in varchar2,
    a_state         in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_NeLinkQuery(
    a_neName        in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    procedure SP_I_NeLinkManager(
    a_type             in varchar2,
    a_id               number,
    a_neID             number,
    a_neName           varchar2,
    a_nePort           varchar2,
    a_nodeID           number,
    a_interfaceID      number,
    a_linkNeID         number,
    a_linkNeName       varchar2,
    a_linkNePort       varchar2,
    a_linkNodeID       number,
    a_linkInterfaceID  number,
    a_remark           in varchar2,
    Message            out varchar2,
    ResultCursor       out rc_class);

  -- I_Sgsn : SGSN管理
  procedure SP_I_SgsnManager(
    a_type          in varchar2,
    a_sgsnID        in number,
    a_sgsnName      in varchar2,
    a_sgsnType      in number,
    a_areaID        in number,
    a_router        in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_SgsnQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_Ggsn : GGSN管理
  procedure SP_I_GgsnManager(
    a_type          in varchar2,
    a_ggsnID        in number,
    a_ggsnName      in varchar2,
    a_ggsnType      in number,
    a_areaID        in number,
    a_router        in number,
    a_IP            in varchar2,
    a_port          in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_GgsnQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

      -- I_Wap : WAP管理
  procedure SP_I_WapManager(
    a_type          in varchar2,
    a_wapID        in number,
    a_wapName      in varchar2,
    a_wapType      in number,
    a_areaID        in number,
    a_router        in number,
    a_IP            in varchar2,
    a_port          in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_WapQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

 -- I_GPRSResource: GPRS资源管理
  procedure SP_I_GPRSResourceManager(
    a_type          in varchar2,
    a_ID            in number,
    a_rsName        in varchar2,
     a_rsType       in number,
    a_IP            in varchar2,
    a_url           in varchar,
    a_keyWord       in varchar2,
    a_port          in varchar2,
    a_userName      in varchar,
    a_passWord      in varchar2,
    a_remark         in varchar2,
    a_buscode        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_GPRSResourceQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_IMSUA: IMS终端用户管理
procedure SP_I_IMSUAManager(
    a_type          in varchar2,
    a_ID            in number,
    a_uaNumber      in varchar2,
    a_shortnum      in varchar2,
    a_IMPI          in varchar2,
    a_userName      in varchar2,
    a_passWord      in varchar,
    a_kiValue      in varchar,
    a_OPCValue      in varchar,
    a_IMSIValue      in number,
    a_totalTel      in number,
    a_domain        in varchar2,
    a_areaid        in number,
    a_uatype        in number,
    a_netype        in number,
    a_exttel        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_IMSUAQuery(
    a_uaNumber      in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- I_IMSProxy: IMS接入服务器管理
  procedure SP_I_IMSProxyManager(
    a_type          in varchar2,
    a_ID            in number,
    a_deviceName    in varchar2,
    a_ipAddr        in varchar2,
    a_port          in number,
    a_areaid        in number,
    a_proxytype     in number,
    a_router        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_IMSProxyQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_IMSProxyQuery3(
    a_type          in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   -- I_MapVirtualNet : 虚拟网入网信息管理
  procedure SP_I_MapVirtualNetManager(
    a_type          in varchar2,
    a_ID            in number,
    a_virtualNetType        in number,
    a_virtualNetTypeName      in varchar2,
    a_virtualNetID        in number,
    a_virtualNetName      in varchar2,
    a_MSISDN      in varchar2,
    a_shortNO      in varchar2,
    a_remark          in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_MapVirtualNetQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_IMSProxyServerQuery(
    a_type          in number,
    a_areaid        in number,
    a_protype       in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- B_RtpInfo : RTP管理
  procedure SP_B_RtpInfoManager(
    a_type          in varchar2,
    a_rtpID         in number,
    a_rtpCode       in varchar2,
    a_rtpName       in varchar2,
    a_phone1        in varchar2,
    a_phone2        in varchar2,
    a_phone3        in varchar2,
    a_phone4        in varchar2,
    a_shortCode1    in varchar2,
    a_shortCode2    in varchar2,
    a_shortCode3    in varchar2,
    a_shortCode4    in varchar2,
    a_netType       in varchar2,
    a_rtpIP         in varchar2,
    a_rtpPort       in varchar2,
    a_maskIP        in varchar2,
    a_gateWay       in varchar2,
    a_sapIP         in varchar2,
    a_rtpType       in varchar2,
    a_placeType     in varchar2,
    a_areaName      in varchar2,
    a_exchangeName  in varchar2,
    a_bscName       in varchar2,
    a_stationName   in varchar2,
    a_subStationName in varchar2,
    a_phone1Type    in varchar2,
    a_phone2Type    in varchar2,
    a_phone3Type    in varchar2,
    a_phone4Type    in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_RtpInfoQuery(
    a_mark          in number,
    a_ids           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_RtpTree(
    a_userID        in number,
    a_layerNum      in number,
    a_mark          in number,
    a_ids           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- B_TaskInfo : BSC任务管理
  procedure SP_B_TaskInfoManager(
    a_type          in varchar2,
    a_rtp_id_1      in varchar2,
    a_rtp_id_2      in varchar2,
    a_duration      in varchar2,
    a_interval      in varchar2,
    a_setCallNum    in varchar2,
    a_cmd_exPara    in varchar2,
    a_taskType      in varchar2,
    a_taskMode      in varchar2,
    a_sendTime      in varchar2,
    a_overTime      in varchar2,
    a_taskName      in varchar2,
    a_resultType    in varchar2,
    a_operator      in number,
    a_preCount      in number,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TaskInfoQuery(
    a_mark          in number,
    a_ids           in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_userID        in number,
    a_userID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TaskInfoSetCRFile(
    a_taskID        in number,
    a_file          in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TaskInfo2Query(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_tasksID       in number,
    c_taskName      in varchar2,
    c_userID        in number,
    a_userID        in number,
    a_ids           in varchar2,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TestResultStatQuery(
    a_tableName     in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_tasksID       in number,
    c_taskName      in varchar2,
    a_userID        in number,
    a_istType       in number,
    a_ids           in varchar2,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- B_TaskRule : BSC任务模板管理
  procedure SP_B_TaskRuleManager(
    a_type          in varchar2,
    a_ruleID        in number,
    a_ruleName      in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TaskRuleQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- B_TaskRuleDetail : BSC模板例测任务表管理
  procedure SP_B_TaskRuleDetailManager(
    a_type          in varchar2,
    a_id            in number,
    a_ruleID        in number,
    a_callerTypeID  in number,
    a_callerTypeName in varchar2,
    a_defCaller     in varchar2,
    a_calledTypeID  in number,
    a_calledTypeName in varchar2,
    a_shortCalled   in number,
    a_defCalled     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TaskRuleDetailQuery(
    a_ruleID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TestSSResult2Query(
    a_tableName     in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_tasksID       in number,
    c_taskName      in varchar2,
    a_userID        in number,
    a_istType       in number,
    a_ids           in varchar2,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_B_TestResultStat3Query(
    a_tableName     in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_tasksID       in number,
    c_taskName      in varchar2,
    a_userID        in number,
    a_istType       in number,
    a_ids           in varchar2,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_T_TaskRulepoiQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_tasksID       in number,
    c_taskName      in varchar2,
    a_userID        in number,
    a_istType       in number,
    a_ids           in varchar2,
    a_taskids       in varchar2,
    a_separator     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Z_TaskTemplet : 任务模板管理
  procedure SP_Z_TaskRuleTempletQuery(
    a_ruleid        in number,
    a_startTime     in varchar2,
    a_endTime       in varchar2,
    a_taskids       in varchar2,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskTempletManager(
    a_type          in varchar2,
    a_templetID     in number,
    a_templetName   in varchar2,
    a_taskName      in varchar2,
    a_testCode      in number,
    a_executeMode   in number,
    a_cycleUnit     in number,
    a_cycleInput    in number,
    a_caller        in varchar2,
    a_called        in varchar2,
    a_shortCode     in varchar2,
    a_duration      in number,
    a_interval      in number,
    a_testCount     in number,
    a_planTime      in varchar2,
    a_outSwitchCode in varchar2,
    a_toSwitchArea1 in varchar2,
    a_toSwitchArea2 in varchar2,
    a_toSwitchCode1 in varchar2,
    a_toSwitchCode2 in varchar2,
    a_operator      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskTempletQuery(
    a_operator      in number,
    a_testCode      in number,
    a_templetID     in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Z_TaskInfo : 任务管理
  procedure SP_Z_TaskInfoManager(
    a_type          in varchar2,
    a_taskID        in number,
    a_tasksID       in number,
    a_taskName      in varchar2,
    a_testCode      in number,
    a_executeMode   in number,
    a_cycleUnit     in number,
    a_cycleInput    in number,
    a_cycleValue    in number,
    a_caller        in varchar2,
    a_called        in varchar2,
    a_duration      in number,
    a_interval      in number,
    a_testCount     in number,
    a_router        in varchar2,
    a_gateWay       in varchar2,
    a_textInfo      in varchar2,
    a_planTime      in varchar2,
    a_operator      in number,
    a_areaID        in number,
    a_taskStatus    in number,
    a_sapID         in number,
    a_outNeName     in varchar2,
    a_inNeName      in varchar2,
    a_toNeName1     in varchar2,
    a_toNeName2     in varchar2,
    a_toNeName3     in varchar2,
    a_outNeCode     in varchar2,
    a_inNeCode      in varchar2,
    a_toNeCode1     in varchar2,
    a_toNeCode2     in varchar2,
    a_toNeCode3     in varchar2,
    a_alarmFlag     in number,
    a_alarmNumbers  in varchar2,
    a_alarmParamTypes in varchar2,
    a_alarmParams   in varchar2,
    a_clearModes    in varchar2,
    a_clearParamTypes in varchar2,
    a_clearParams   in varchar2,
    a_groupid       in number,
    a_spliter       in varchar2,
    a_poingCount    in number,
    a_recordFlag    in varchar2,
    a_remark1       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskInfoDel(
    a_taskIDs       in varchar2,
    a_spliter       in varchar2,
    a_userID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskStatusSetAll(
    a_taskIDs       in varchar2,
    a_taskStatus    in number,
    a_spliter       in varchar2,
    a_userID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskInfoQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_testCode      in number,
    c_outNeCode     in varchar2,
    c_executeMode   in number,
    c_cycleUnit     in number,
    c_taskStatus    in number,
    c_taskName      in varchar2,
    c_taskID        in number,
    c_tasksID       in number,
    c_userID        in number,
    a_userID        in number,
    c_testType      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskInfoQueryTop(
    c_counter       in number,
    a_userID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskInfoByMonitorBox(
    a_userID        in number,
    a_testCodes     in varchar2,
    a_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Z_AlarmPoint : 告警点管理
  procedure SP_Z_AlarmPointManager(
    a_type          in varchar2,
    a_s_alarmNumber in number,
    a_alarmNumber   in number,
    a_pointName     in varchar2,
    a_smpName       in varchar2,
    a_testCode      in number,
    a_alarmClass    in varchar2,
    a_alarmLevel    in number,
    a_alarmOnOff    in number,
    a_alarmType     in number,
    a_alarmParamType in number,
    a_alarmParam    in varchar2,
    a_alarmData     in varchar2,
    a_clearMode     in number,
    a_clearParamType in number,
    a_clearParam    in varchar2,
    a_upAlarmCycle  in varchar2,
    a_remark        in varchar2,
    a_synoFlag      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_AlarmPointQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Z_AlarmPolicy : 告警策略管理
  procedure SP_Z_AlarmPolicyManager(
    a_type          in varchar2,
    a_id            in number,
    a_alarmNumber   in number,
    a_alarmOnOff    in number,
    a_taskID        in number,
    a_testCode      in number,
    a_alarmParamType in number,
    a_alarmParam    in varchar2,
    a_clearMode     in number,
    a_clearParamType in number,
    a_clearParam    in varchar2,
    a_createuser    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_AlarmPolicyQuery(
    a_alarmNumber   in number,
    a_testCode      in number,
    a_taskID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_AlarmPointQueryByPolicy(
    a_alarmFlag     in number,
    a_testCode      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Z_Alarm 告警
  procedure SP_Z_AlarmDel(
    a_alarmIDs      in varchar2,
    a_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_AlarmQueryByMonitor(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_AlarmQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_testCode      in number,
    c_outNeCode     in varchar2,
    c_executeMode   in number,
    c_cycleUnit     in number,
    c_taskStatus    in number,
    c_taskName      in varchar2,
    c_taskID        in number,
    c_tasksID       in number,
    c_userID        in number,
    a_userID        in number,
    c_testType      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskAlarmPolicyQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_testCode      in number,
    c_outNeCode     in varchar2,
    c_executeMode   in number,
    c_cycleUnit     in number,
    c_taskStatus    in number,
    c_taskName      in varchar2,
    c_taskID        in number,
    c_tasksID       in number,
    c_userID        in number,
    a_userID        in number,
    c_testType      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_AlarmHisQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_testCode      in number,
    c_outNeCode     in varchar2,
    c_executeMode   in number,
    c_cycleUnit     in number,
    c_taskStatus    in number,
    c_taskName      in varchar2,
    c_taskID        in number,
    c_tasksID       in number,
    c_userID        in number,
    a_userID        in number,
    c_testType      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskSetAlarm(
    a_alarmFlag     in number,
    a_alarmNumbers  in varchar2,
    a_alarmParamTypes in varchar2,
    a_alarmParams   in varchar2,
    a_clearModes    in varchar2,
    a_clearParamTypes in varchar2,
    a_clearParams   in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number,
    a_taskIDs       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  function SF_Z_TaskSetAlarm(
    a_taskIDs       in varchar2,
    a_alarmFlag     in number,
    a_alarmNumbers  in varchar2,
    a_alarmParamTypes in varchar2,
    a_alarmParams   in varchar2,
    a_clearModes    in varchar2,
    a_clearParamTypes in varchar2,
    a_clearParams   in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number
  ) return varchar2;

  procedure SP_Z_SSTaskStatGetSignaling(
    a_taskID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_SSTestResultCount(
    a_taskID        in number,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_Z_SSTestResult(
    a_taskID        in number,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TestResultIPNetByMonitor(
    c_Time          in number,
    c_number        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TestResultIPTaskByMonitor(
    c_taskid        in number,
    c_time          in number,
    c_number        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

 /* procedure SP_Z_TestResultQuery(
    c_taskID        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);*/

 procedure SP_Z_TestResultQuery(
    c_taskID        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_taskname      in varchar2,
    c_alarmnumber   in number,
    c_testcode      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

 /* procedure SP_Z_TestResultCount(
    c_taskID        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);*/

   procedure SP_Z_TestResultCount(
    c_taskID        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_taskname      in varchar2,
    c_alarmnumber   in number,
    c_testcode      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TestResultStat(
    c_groupStat     in varchar2,
    c_hourStat      in varchar2,
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_taskIDs       in varchar2,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_GJTestResultStat(
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);


  procedure SP_Z_TaskReportStat(
    c_groupStat     in varchar2,
    c_dayStat       in number,
    c_testcode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_taskIDs       in varchar2,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  --集团任务报表统计
  procedure SP_Z_JTTaskReportStat_1(
    c_type          in varchar2,
    c_areaType      in varchar2, --0-全部 1-本省及外省 2-本省 3-省内地区，其他>100
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_realFlag      in number,
    c_flag          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  --集团任务报表统计
  procedure SP_Z_JTTaskReportStat_2(
    c_type          in varchar2,
    c_areaType      in varchar2, --0-全部 1-本省及外省 2-本省 3-省内地区，其他>100
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_realFlag      in number,
    c_flag          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  --集团任务报表结果重载
  procedure SP_Z_JTTaskReportResultUpload(
    c_testCode      in number,
    c_areaType      in varchar2, --0-全部 1-本省及外省 2-本省 3-省内地区，其他>100
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  --集团任务报表结果清空
  procedure SP_Z_JTTaskReportResultClear(
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  --集团任务重做按日统计
  procedure SP_Z_JTTaskDayStatRedo(
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  function FUN_GetRoleAuth(
    a_type            number,  --1查询 2-添加 3-修改 4-删除
    a_module          varchar2,
    a_userID          number
  ) return number;

   function FUN_GetUserAreaID(
    a_userID          number
  ) return number;


  procedure SP_TS_GetTask(
    c_taskID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_TS_QueryByTasks(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_TS_SetNextPlanTime(
    a_taskID        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  function SF_TS_GetNextPlanTime(
    a_planTime      in date,
    a_startTime     in date,
    a_cycleUnit     in number,
    a_cycleValue    in number
  ) return date;

  procedure SP_TS_SetTaskStatus(
    a_taskID        in number,
    a_taskStatus    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_TS_QuerySSResult(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    flag            in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_TS_Syn_SSResult(
    c_id            in number,
    c_caller        in varchar2,
    c_called        in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_taskid        in number,
    c_sstype        in number,
    c_tasktype      in number,
    c_ssdbCount     in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_del_SSResult_bak;

   -- Z_TestResultJTReport : 集团测试结果管理
  procedure SP_Z_TestResultJTReportManager(
    a_type          in varchar2,
    a_taskID     in varchar2,
    a_taskName     in varchar2,
    a_testCode     in varchar2,
    a_progID     in varchar2,
    a_callType     in varchar2,
    a_testResult     in varchar2,
    a_callResult     in varchar2,
    a_billResult     in varchar2,
    a_caller     in varchar2,
    a_called     in varchar2,
    a_startTime     in varchar2,
    a_endTime     in varchar2,
    a_executeNum     in varchar2,
    a_duration     in varchar2,
    a_talkStatus     in varchar2,
    a_responseTime     in varchar2,
    a_totalTime     in varchar2,
    a_sendPacket     in varchar2,
    a_recvPacket     in varchar2,
    a_lostPacketRate     in varchar2,
    a_errPacketRate     in varchar2,
    a_minDelay     in varchar2,
    a_maxDelay     in varchar2,
    a_avgDelay     in varchar2,
    a_breakLine     in varchar2,
    a_callerValue     in varchar2,
    a_calledValue     in varchar2,
    a_callerDetail     in varchar2,
    a_calledDetail     in varchar2,
    a_ss7Content     in varchar2,
    a_codeData     in varchar2,
    a_attachTime     in varchar2,
    a_detachTime     in varchar2,
    a_activationTime     in varchar2,
    a_deActivationTime     in varchar2,
    a_operateTime     in varchar2,
    a_redo     in varchar2,
    a_gwip1     in varchar2,
    a_gwip2     in varchar2,
    a_exTaskID     in varchar2,
    a_exProgID     in varchar2,
    a_remark1     in varchar2,
    a_remark2     in varchar2,
    a_remark3     in varchar2,
    a_remark4     in varchar2,
    a_istDate     in varchar2,
    a_uptDate     in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

 --集团测试结果全量表检索
 procedure SP_Z_JTTestResultQuery(
    c_areaType      in varchar2, --0-全部 1-本省及外省 2-本省 3-省内地区，其他>=100
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_startrow      in number,
    c_endrow        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

 procedure SP_RNC_TaskRuleDetailManager(
    a_type          in varchar2,
    a_id            in number,
    a_ruleID        in number,
    a_caller  in varchar2,
    a_called in varchar2,
    a_outNeName     in varchar2,
    a_inNeName  in varchar2,
    a_outNeCode        in number,
    a_inNeCode        in number,
    a_isopen 		in number,
    a_calltype   in number,
    a_callnumber     in varchar2,
    a_testCode     in number,
     a_remark    in varchar2,
     a_kind        in number,
    a_testcount   in number,
    a_interval        in number,
    a_duration 		in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
     procedure SP_RNC_TaskRuleManager(
    a_type          in varchar2,
    a_ruleID        in number,
    a_ruleName      in varchar2,
 a_ruletype      in varchar2,
 a_callerid      in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  -- Z_JTMsc_UpdateList : 数据中心-保存交换机编号更新列表
  procedure SP_Z_JTMsc_UpdateList(
    c_citylist in varchar2,
	  c_namelist in varchar2,
	  c_noList in varchar2,
	  c_timeText in varchar2,
	  c_needDelete in number,
	  Message  out varchar2,
	  ResultCursor out rc_class);
	    -- Z_TestResultcenter : 同步失败测试结果
procedure SP_Z_SYN_TestResultCenter(
    a_taskID             in varchar2,
    a_Count              in number,
    Message              out varchar2,
    ResultCursor         out rc_class);
  procedure SP_Z_QueryTestResultCenter(
    maxCount             in number,
    Message              out varchar2,
    ResultCursor         out rc_class);
 -- Z_TestResultcenter : 更新同步失败测试结果状态
  procedure SP_Z_UpdateTestResultCenter(
    a_taskID             in varchar2,
    Message              out varchar2,
    ResultCursor         out rc_class);
  -- SP_TS_QueryByCenter : 查询结果任务
procedure SP_TS_QueryByCenter(
    type            in  number,
    c_rowStart      in  number,
    c_rowEnd        in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);
  procedure SP_S_RoleSetTestCodes(
    a_roleID        in number,
    a_testcodes     in varchar2,
    a_preCount      in number,
    a_seperator     in varchar2,
    a_phone         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
   procedure SP_S_TestcodeQueryByRole(
    a_roleID        in number,
    a_phone         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
     -- IpResource : IP资源管理
  procedure SP_I_IpManager(
    v_type          in varchar2,
    a_id            in number,
    a_type          in varchar2,
    a_stat          in number,
    a_ip            in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_IPQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_routerManager(
    a_type          in varchar2,
    a_iD            in number,
    a_name          in varchar2,
    a_router        in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_routerQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_S_lineChartQuery(
    a_taskid        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
     procedure SP_Z_Alarm24QueryByMonitor(
    Message         out varchar2,
    ResultCursor    out rc_class);

     -------------------------------2011-06-025--

 procedure SP_S_phoneSetTestCodes(
    a_testcodes     in varchar2,
    a_type          in number,
    a_preCount      in number,
    a_seperator     in varchar2,
    a_phone         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_S_TestcodeByPhone(
    a_phone         in varchar2,
    a_type          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);


   procedure SP_I_RemindPhoneQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_RemindManager(
    a_type          in varchar2,
    a_id            in number,
    a_phone         in varchar2,
    a_stat          in number,
    a_start_time    in varchar2,
    a_end_time      in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    procedure SP_I_NeTree(
    a_layerNum      in number,
    a_mark          in number,
    a_nename        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
      --------------------------------------wlan-----------------
    procedure SP_I_RadQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);
      -- I_RadCode : Rad测试号码
   procedure SP_I_RadCodeManager(
    a_type          in varchar2,
    a_id            in number,
    a_imsi          in varchar2,
    a_mobile        in varchar2,
    a_flate         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      -- I_Rad : Radius服务器
   procedure SP_I_RadManager(
    a_type          in varchar2,
    a_radId         in number,
    a_radName       in varchar2,
    a_port1         in number,
    a_port2         in number,
    a_ipAddress     in varchar2,
    a_radKey        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_RadCodeQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);
    -------------------------告警关联----------------------------

   procedure SP_Z_Alarm_GroupManager(
    a_type          in varchar2,
    a_groupid       in number,
    a_groupname     in varchar2,
    a_state         in number,
    a_alarmtype     in number,
    a_alarmparm     in varchar2,
    a_cleartype     in number,
    a_clearparm     in varchar2,
    a_alarmflag     in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_Z_Alarm_GroupQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

      -------------------------割接管理----------------------------
   procedure SP_Z_projinfoManager(
    a_type          in varchar2,
    a_id            in number,
    a_proname       in varchar2,
    a_netype        in number,
    a_nename        in varchar2,
    a_username      in varchar2,
    a_projstate     in number,
    a_starttime     in varchar2,
    a_endtime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_Z_ProjInfoQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);


    ------------网元管理---------------
   procedure SP_Z_NeTypeManager(
    a_type          in varchar2,
    a_id            in number,
    a_state         in number,
    a_netype          in number,
    a_nename        in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_Z_NeTypeQuery(
    a_state         in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);


        ------------任务关联网元管理---------------
    procedure SP_Z_addNeTask(
    a_taskids       in varchar2,
    a_nename        in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);


  ------------------删除网元关联任务---------------
    procedure SP_Z_delNeTask(
    a_id            in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_NeTaskQuery(
   c_taskIDs       in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

       -- Z_TaskAlarm_Group :任务关联告警管理
  /* procedure SP_Z_TaskAlarm_GroupManager(
    a_type          in varchar2,
    a_groupid       in number,
    a_taskids       in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);*/
    procedure SP_Z_TaskAlarm_GroupManager(
    a_type          in varchar2,
    a_groupid       in number,
    a_taskids       in varchar2,
    a_param         in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_Z_TaskAlarm_GroupQuery(
    a_groupid       in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);


   ----------------任务关联查询-------------
   procedure SP_Z_queryAlarmTask(
    a_node          in number,
    a_type          in number,
    a_groupid       in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

------------------割接任务告警---------------
  procedure SP_Z_ProjectInfoManager(
    a_type          in varchar2,
    a_projid        in number,
    a_taskids       in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_Z_Project_groupQuery(
    a_projid        in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);


  ----------------任务割接查询-------------
   procedure SP_Z_queryProjTask(
    a_node          in number,
    a_type          in number,
    a_neName        in varchar2,
    a_projid       in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   ----------------批量绑定任务----------------
  procedure SP_Z_TaskGroupManager(
    a_groupid       in number,
    a_taskids       in varchar2,
    a_spliter       in varchar2,
    a_poingCount    in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
  --------------------------任务树-------------------------------
  procedure SP_Z_TestCodeTree(
    a_mark          in number,
    a_id           in varchar2,
    a_groupid       in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
 ----------------------端局统计-----------------------------------
  procedure SP_Z_TestSwitchStat(
    a_areaid        in number,
    a_testcode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      ---------------------------日常告警-------------------------
 procedure SP_Z_DayAlarmQueryByMonitor(
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_DayAlarm24QueryByMonitor(
    Message         out varchar2,
    ResultCursor    out rc_class);

---------同步更新任务割接状态-------------
procedure SP_Z_SYNPROJECT;

---------------工程预约管理----------------------
  procedure SP_Z_workOrderManager(
    a_type          in varchar2,
    a_id            in number,
    a_proname       in varchar2,
    a_areaid        in number,
    a_nename        in varchar2,
    a_username      in varchar2,
    a_projstate     in number,
    a_starttime     in varchar2,
    a_endtime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      ------------sip测试接入服务器以及用户变更
 procedure SP_I_IMSUAQuery2(
    Message         out varchar2,
    ResultCursor    out rc_class);

 procedure SP_I_IMSProxyQuery2(
    a_state         in number,
    Message         out varchar2,
  ResultCursor    out rc_class);

 procedure SP_I_IMSUACalledQuery(
    a_areaid        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

 procedure SP_I_IMSUATypeQuery(
    a_type          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
 /* ----------------------健康报告--成功率--------------------
 procedure SP_Z_SuccessRate(
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   ---------------健康报告--失败次数-------------------------
  procedure SP_Z_FailureCount(
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);*/


  procedure SP_Z_TaskInfoQueryCount(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_testCode      in number,
    c_outNeCode     in varchar2,
    c_executeMode   in number,
    c_cycleUnit     in number,
    c_taskStatus    in number,
    c_taskName      in varchar2,
    c_taskID        in number,
    c_tasksID       in number,
    c_userID        in number,
    a_userID        in number,
    c_testType      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_TaskInfoQueryPage(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_testCode      in number,
    c_outNeCode     in varchar2,
    c_executeMode   in number,
    c_cycleUnit     in number,
    c_taskStatus    in number,
    c_taskName      in varchar2,
    c_taskID        in number,
    c_tasksID       in number,
    c_userID        in number,
    a_userID        in number,
    c_testType      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);


  procedure SP_I_ApQuery(
   a_acid           in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_ApManager(
    a_type          in varchar2,
    a_id            in number,
    a_acid          in number,
    a_ip            in varchar2,
    a_mac           in varchar2,
    a_state         in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      procedure SP_I_ACQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);


       procedure SP_I_AcManager(
    a_type          in varchar2,
    a_id            in number,
    a_acname        in varchar2,
    a_state         in number,
    a_acip          in varchar2,
    a_areaid        in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

     ---------------------集团报表---------------
  procedure SP_Z_SwitchStatQuery(
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);


   -----------------------集团报表---------------
  procedure SP_Z_JtResultQuery(
    c_testcode      in number,
    c_calltype      in number,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

     procedure SP_Z_JtResultCount(
    c_testcode      in number,
    c_calltype      in number,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_BC_TaskInfoQuery(
    a_type          in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);
  procedure SP_BC_TestResultQuery(
   a_type          in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_I_IMSProxyByArea(
    a_areaid        in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  ------------------------ims 集团报表----------------
  procedure SP_Z_JTImsTaskReportStat(
    c_type              in varchar2,
    c_startTime          in varchar2,
    c_endTime            in varchar2,
    Message              out varchar2,
    ResultCursor         out rc_class);
   --------------------------错误详单------------------
  procedure SP_Z_TestFailureResultQuery(
    c_testcode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   ----------------------健康报告--成功率--------------------
  procedure SP_Z_SuccessRate(
    stateType       in  number,
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
      ---------------健康报告--失败次数-------------------------
  procedure SP_Z_FailureCount(
    stateType       in  number,
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

     ---------------健康报告--端局失败次数-------------------------
  procedure SP_Z_SwitchFailureCount(
    stateType       in  number,
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      ---------------------测试号码树---------------------
  procedure SP_Z_GtDetailTree(
    a_mark          in number,
    a_areaname        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);


  ---------------------测网元码树---------------------
  procedure SP_Z_NeTaskTree(
    a_mark          in number,
    a_nename        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
-- I_Department : 部门管理
  procedure SP_I_DepartmentManager(
    a_type          in varchar2,
    a_id            in number,
    a_name          in varchar2,
    a_state         in number,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

 --部门查询
  procedure SP_I_DepartmentQuery(
    a_state         in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);


     -----日志统计-----
  procedure SP_S_LogStatQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    a_dpid          in number,
    a_roleid        in number,
    a_moduleName    in varchar2,
    a_username      in varchar2,
    a_areaid        in number,
    a_rowStart      in number,
    a_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

      -----日志统计-----
  procedure SP_S_LogStatCountQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    a_dpid          in number,
    a_roleid        in number,
    a_moduleName    in varchar2,
    a_username      in varchar2,
    a_areaid        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

    procedure SP_I_IMSUAExtQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);

    -----------路由统计---------
    /*
  procedure SP_S_RouterStatQuery(
    c_startTime      in varchar2,
    c_endTime        in varchar2,
    c_testCode       in number,
    c_testType       in number,
    c_taskname       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    */

      procedure SP_S_RouterStatQuery(
    c_startTime      in varchar2,
    c_endTime        in varchar2,
    c_testCode       in number,
    c_testType       in number,
    c_taskname       in varchar2,
    c_sHour      in varchar2,
    c_isdel          in varchar2,
    c_len            in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
    --------------------------
  procedure SP_S_RoutertestresultQuery(
    c_startTime      in varchar2,
    c_endTime        in varchar2,
    c_testCode       in number,
    c_testType       in number,
    c_taskname       in varchar2,
    c_sHour      in varchar2,
    c_isdel          in varchar2,
    c_len            in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
    ----------------按路径话单导出
   procedure SP_S_RouterTestresultStatQuery(
    c_startTime      in varchar2,
    c_endTime        in varchar2,
    c_testCode       in number,
    c_testType       in number,
    c_taskname       in varchar2,
    c_sHour      in varchar2,
    c_isdel          in varchar2,
     c_len            in number,
   c_routerUrl      in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    ----------------按路由分段统计
     procedure SP_S_RouterSpStatQuery(
    c_startTime      in varchar2,
    c_endTime        in varchar2,
    c_testType       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
        -----------路由统计---------
 procedure SP_S_RouterSplitStatQuery(
    c_startTime      in varchar2,
    c_endTime        in varchar2,
    c_testCodes       in varchar2,
    c_realFlag       in number,
    Message         out varchar2,
    ResultCursor    out rc_class);


 procedure SP_I_SgsnToGgsnQuery(
    a_ggsnid          in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);


   procedure SP_S_SetGgsntoSgsns(
    a_sgsnids       in varchar2,
    a_preCount      in number,
    a_seperator     in varchar2,
    a_ggsnid        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_GgsnToWapQuery(
    a_wapid         in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_S_SetGgsntoWap(
    a_ggsnids       in varchar2,
    a_preCount      in number,
    a_seperator     in varchar2,
    a_wapid         in number,
    Message         out varchar2,
    ResultCursor    out rc_class);


       -- i_ggsnipaddress : ggsn地址管理
  procedure SP_i_GgsnIpAddressManager(
    a_type          in varchar2,
    a_id            in number,
    a_ggsnid        in number,
    a_IP            in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_I_GgsnIpAddressQuery(
    a_ggsnid        in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);

       -- i_wapipaddress : wap地址管理
  procedure SP_i_wapipaddressManager(
    a_type          in varchar2,
    a_id            in number,
    a_wapid         in number,
    a_IP            in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_i_wapipaddressQuery(
    a_wapid         in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);


      ---------国漫统计------
  procedure SP_Z_GJStat(
    c_tasksid       in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

   procedure SP_S_ModuleQueryByRole2(
    a_roleID        in number,
    a_isMenu        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

    --------------告警群----------------
  procedure SP_Z_GroupAlarmManager(
    a_type          in varchar2,
    a_id            in number,
    a_name          in varchar2,
    a_status        in number,
    a_alarmparam    in varchar2,
    a_remark        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

  procedure SP_Z_GroupAlarmQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);
    ------------------------------------

  procedure SP_TimedelayCountQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

     procedure SP_TimedelayQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
   a_rowStart      in number,
    a_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);

 procedure SP_TimedelayStatQuery(
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

 procedure SP_S_EvaluationParamBean(
    testType        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);


    procedure SP_S_EvaluationParam_ALL(
    a_type            in varchar2,
    a_id              in number,
    a_testType        in varchar2,
    a_attachDelay     in varchar2,
    a_attachInterval  in varchar2,
    a_detachDelay     in varchar2,
    a_detachInterval  in varchar2,
    a_activationDelay in varchar2,
    a_activationInterval  in varchar2,
    a_deActivationDelay  in varchar2,
    a_deActivationInterval  in varchar2,
    a_socketDelay  in varchar2,
    a_socketInterval  in varchar2,
    a_oneSocketDelay in varchar2,
    a_oneSocketInterval in varchar2,
    a_oneResponseDelay in varchar2,
    a_oneResponseInterval in varchar2,
    a_oneReceiveDelay in varchar2,
    a_oneReceiveInterval in varchar2,
    a_twoSocketDelay in varchar2,
    a_twoSocketInterval in varchar2,
    a_twoResponseDelay in varchar2,
    a_twoResponseInterval in varchar2,
    a_twoReceiveDelay in varchar2,
    a_twoReceiveInterval in varchar2,

    a_dnsResponseDelay  in varchar2,
    a_dnsResponseInterval  in varchar2,
    a_dnsOperateDelay  in varchar2,
    a_dnsOperateInterval  in varchar2,

    a_dataResponseDelay  in varchar2,
    a_dataResponseInterval  in varchar2,
    a_dataReceiveDelay      in varchar2,
    a_dataReceiveInterval   in varchar2,

    a_totalSocketDelay      in varchar2,
    a_totalSocketInterval  in varchar2,
    a_totalResponseDelay    in varchar2,
    a_totalResponseInterval in varchar2,
    a_totalReceiveDelay     in varchar2,
    a_totalReceiveInterval  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    procedure SP_S_EvaluationNEstat(

    a_neType        in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
   ----------------------------sbc指标分析-----------------------
  procedure SP_Z_JTSBCReportStat(
    c_testcode           in number,
    c_startTime          in varchar2,
    c_endTime            in varchar2,
    Message              out varchar2,
    ResultCursor         out rc_class);

  procedure SP_Z_JTSBCReportTop(
    c_testCode           in number,
    c_startTime          in varchar2,
    c_endTime            in varchar2,
    Message              out varchar2,
    ResultCursor         out rc_class);

   procedure SP_S_SBClineChartQuery(
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

     procedure SP_S_Failrurequery(
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      -----------------------------------网元排名-------------------
  procedure SP_S_NeNamequery(
    a_testcode      in number,
    a_orderType     in number,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

      --------------用户统计-------
   procedure SP_Z_UserStatQuery(
    startTime       in  varchar2,
    endTime         in  varchar2,
    username        in  varchar2,
    statType        in  number,
    Message         out varchar2,
    ResultCursor    out rc_class);

    -----上海集团接口统计------
  procedure SP_Z_SmsStat(
    stateType       in  number,
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    -------------山西自动报表 -----------------
   procedure SP_Z_TaskReportStat2(
    c_groupStat     in varchar2,
    c_dayStat       in number,
    c_testcode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_hours         in varchar2,
    c_taskIDs       in varchar2,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);


       -------------报表 查询-------
   procedure SP_Z_ReporttatQuery(
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

     procedure SP_Z_MutilsTestResultQuery(
    c_taskID        in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_taskname      in varchar2,
    c_alarmnumber   in number,
    c_testcode      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
       -------------设备资源负荷 查询-------
   procedure SP_I_ResourceQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);
    
   procedure sp_z_chartReport(
    c_sExecuteTime    in  varchar2,
    c_eExecuteTime    in  varchar2,
    taskids           in  varchar2,
    oprtype           in  varchar2,
    testCode        in  varchar2,
    Message           out varchar2,
    ResultCursor      out rc_class);
    
    -------------csfb统计------
 procedure SP_Z_CsfbStatQuery(
    startTime       in  varchar2,
    endTime         in  varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    -----------鱼骨图详单----------
procedure SP_Z_TestResultFishQuery(
    c_taskIDs       in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_flag          in number,
    c_testcode      in number,
    c_spliter       in varchar2,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
  procedure SP_Z_TestResultFishCount(
    c_taskIDs       in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_flag          in number,
    c_testcode      in number,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    ------------------------------
    procedure sp_z_sectionChartReport(
    c_sExecuteTime    in  varchar2,
    c_eExecuteTime    in  varchar2,
    taskids           in  varchar2,
    oprtype           in  varchar2,
    oprtime           in  varchar2,
    testCode          in  varchar2,
    Message           out varchar2,
    ResultCursor      out rc_class);
------------------------江西网元指标-----------
    procedure SP_Z_Jx_NeTestStat(
    c_type          in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    -----------------------------------
    
     procedure SP_Z_JTCSCFReportStat(
     c_testcode          in number,
    c_startTime          in varchar2,
    c_endTime            in varchar2,
    Message              out varchar2,
    ResultCursor         out rc_class);
    
    procedure SP_TopQueryResult(
    c_taskID        in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
      procedure SP_Z_TestResultByTasksIdQuery(
    c_tasksID        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_testcode      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
     procedure SP_S_VersionQuery(
    Message         out varchar2,
    ResultCursor    out rc_class);
    
        procedure SP_Z_TestResultByTasksIdCount(
    c_tasksID        in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_testcode      in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    
    -----------清除异常号码---------
 procedure SP_Z_AbnormalNumber(
    a_taskID        in number,
    a_caller        in varchar2,
    a_imsi          in varchar2,
    a_hss           in varchar2,
    a_gsd           in varchar2,
    a_myd           in varchar2,
    a_lstime        in varchar2,
    a_letime        in varchar2,       
    a_router        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    
  procedure SP_Z_AbnormalNumberCount(
    a_startTime        in varchar2,
    a_endTime        in varchar2,
    a_phone          in varchar2,
    a_type           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    
  procedure SP_Z_AbnormalNumberQuery(
    a_startTime        in varchar2,
    a_endTime        in varchar2,
    a_phone          in varchar2,
    a_type           in varchar2,
    c_rowStart      in number,
    c_rowEnd        in number,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    
  procedure SP_Z_AbnormalNumberTotal(
    a_startTime        in varchar2,
    a_endTime        in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    ---------------------2016-03-28-----------
    procedure SP_Z_TestHttpStat(
    c_testCode      in number,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_taskIDs       in varchar2,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    -------------------------------
    
    ----------------2016-06-18-----------------
    procedure SP_Z_TestResultByTaskIdsQuery(
    c_taskIDs        in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_testcode      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    c_spliter         in varchar2,
    c_cond            in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    
    procedure SP_Z_TestResultByTaskIdsCount(
    c_taskIDs        in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_testcode      in number,
    c_spliter         in varchar2,
    c_cond            in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    -------------------end ----------------------
    procedure SP_Z_TESTRESULT_GD_NEQUERY(
    c_taskIDs        in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_testcode      in number,
    c_type          in number,
    c_spliter         in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);
    

    
    
      ---------------------------volte 省内指标统计-------------
  --procedure SP_Z_VOLTEDAYSTAT;
  
      ------------多任务查询count-----------
    procedure SP_Z_MutilsTestResultCount(
     c_taskID        in varchar2,
    c_sExecuteTime  in varchar2,
    c_eExecuteTime  in varchar2,
    c_failFlag      in number,
    c_taskname      in varchar2,
    c_alarmnumber   in number,
    c_testcode      in number,
    c_rowStart      in number,
    c_rowEnd        in number,
    c_spliter       in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

end pkg_tnits_web;
/
