CREATE package pkg_monitor_web is
       type rc_class is ref cursor;

       function SF_GetMaxID(
          a_tableName     in varchar2,
          a_IDColumName   in varchar2
        ) return number;

        function SF_toDate(
          a_date          in varchar2
        ) return date;
      procedure SP_S_UserLogin(
    a_loginName       in varchar2,
    a_password        in varchar2,
    Message          out varchar2,
    ResultCursor     out rc_class);

    procedure SP_I_TaskInfoManager(
    a_type                 in varchar2,
    a_taskId               in varchar2,
    a_taskType             in varchar2,
    a_taskExecuteType      in varchar2,
    a_taskPerformInterval  in varchar2,
    a_httpDomainName      in varchar2,
    a_httpIp              in varchar2,
    a_httpPort            in varchar2,
    a_pingIp              in varchar2,
    a_timerPerformTime    in varchar2,
    a_transferNodeCnt     in varchar2,
    a_firstTransferIp     in varchar2,
    a_secondTransferIp    in varchar2,
    a_remark              in varchar2,
    a_mp_nodeid           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    procedure SP_I_TaskInfoQuery(
    a_taskId        in varchar2,
    a_str           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);


    procedure SP_S_MenuQuery(
     a_userId        in varchar2,
     Message         out varchar2,
     ResultCursor    out rc_class);


    procedure SP_S_MenuManager(
    a_userId               in varchar2,
    a_menuValue            in varchar2,
    a_menuRemark           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

    procedure SP_I_PcAttributesInfoQuery(
    a_pcid        in varchar2,
    a_str           in varchar2,
    Message         out varchar2,
    ResultCursor    out rc_class);

end pkg_monitor_web;


/
