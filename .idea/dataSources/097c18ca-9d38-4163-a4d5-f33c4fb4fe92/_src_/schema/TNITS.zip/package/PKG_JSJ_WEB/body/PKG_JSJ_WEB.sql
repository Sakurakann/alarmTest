CREATE package body PKG_JSJ_WEB is

    procedure SP_S_ModuleQueryBYRole(
    a_roleID        in number,
    a_isMenu        in number,
    Message         out varchar2,
    ResultCursor    out rc_class)
  is
    vReturn         VARCHAR2(200) := '';
  begin
    Message := '模块查询成功!';
    if a_roleID = 1 then
      open ResultCursor for
            select a.*  from s_data_module a order by haschild desc, moduleID;
      return;
    end if;
    open ResultCursor for
          select a.* from s_data_module a order by haschild desc, moduleID;
  exception when others then
    Message := '模块查询失败! '||substr(sqlerrm,1,100);
    vReturn := Message;
    open ResultCursor for select vReturn sqlmsg from dual;
  end;
  
end PKG_JSJ_WEB;
/
