CREATE type type_split as table of varchar2(50);


/
