CREATE type rc_class is ref cursor;


/
