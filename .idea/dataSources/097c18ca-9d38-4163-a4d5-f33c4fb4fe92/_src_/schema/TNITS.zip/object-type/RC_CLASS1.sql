CREATE type rc_class1 is ref cursor;


/
