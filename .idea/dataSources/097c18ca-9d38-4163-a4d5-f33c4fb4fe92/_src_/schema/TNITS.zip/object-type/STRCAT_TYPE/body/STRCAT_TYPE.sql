CREATE type body strcat_type is
  static function ODCIAggregateInitialize(cs_ctx IN OUT strcat_type) return number
  is
  begin
    cs_ctx := strcat_type( null );
    return ODCIConst.Success;
  end;

  member function ODCIAggregateIterate(self IN OUT strcat_type, value IN varchar2 )return number
  is
  begin
    self.cat_string := self.cat_string || ';'|| value;
    return ODCIConst.Success;
  end;

  member function ODCIAggregateTerminate(self IN Out strcat_type, returnValue OUT varchar2, flags IN number) return number
  is
  begin
    returnValue := ltrim(rtrim(self.cat_string,';'),';');
    return ODCIConst.Success;
  end;

  member function ODCIAggregateMerge(self IN OUT strcat_type, ctx2 IN Out strcat_type) return number
  is
  begin
    self.cat_string := self.cat_string || ';' || ctx2.cat_string;
    return ODCIConst.Success;
  end;

end;


/
