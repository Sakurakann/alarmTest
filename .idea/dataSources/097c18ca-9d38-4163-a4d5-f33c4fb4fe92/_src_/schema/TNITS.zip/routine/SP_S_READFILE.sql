CREATE procedure SP_S_Readfile(
	fpath in varchar2,
	fname in varchar2,
	max_num in number)
is
   file_handle utl_file.file_type;
    text_buffer varchar2(1024):='';
begin
        file_handle := utl_file.fopen(fpath, fname, 'r' , max_num);
      begin
	   loop
		utl_file.get_line(file_handle, text_buffer);
		  insert into Z_SSResult(caller,called,opc,dpc,cic7,cic5,iam_d,iam_n,rel_n,rlc_n,duration,callstate,failureremark)
                  values (SF_StrArrayStr(text_buffer,'|',0),SF_StrArrayStr(text_buffer,'|',1),SF_StrArrayStr(text_buffer,'|',2),SF_StrArrayStr(text_buffer,'|',3),SF_StrArrayStr(text_buffer,'|',4),SF_StrArrayStr(text_buffer,'|',5),to_date(SF_StrArrayStr(text_buffer,'|',6), 'yyyy-mm-dd hh24:mi:ss'),SF_StrArrayStr(text_buffer,'|',7),SF_StrArrayStr(text_buffer,'|',8),SF_StrArrayStr(text_buffer,'|',9),SF_StrArrayStr(text_buffer,'|',10),SF_StrArrayStr(text_buffer,'|',11),SF_StrArrayStr(text_buffer,'|',12));
	    end loop;
        exception  when no_data_found then
         return;
     end;
     commit;
exception when others then
         dbms_output.put_line('othter error=' ||SQLERRM);
end;


/
