CREATE procedure syn_alarm_delay is
    c_aramparam            z_alarm_delay.alarm_param%type;
    c_testCode             z_alarm_delay.testcode%type;
    c_attachtime           number:=0;
    c_activationtime       number:=0;
    c_responsedelay        number:=0;
    c_param_delay            number:=0;
  begin
   select to_number(PARAMVALUE) into c_param_delay  from  S_PARAM where PARAMNAME='PARAM_DELAY';
    DECLARE CURSOR ResultCursor IS
        select testcode,ALARM_PARAM from z_alarm_delay order by testcode;
    BEGIN
      open ResultCursor;
      LOOP
        FETCH ResultCursor INTO c_testCode,c_aramparam;
        exit when ResultCursor%notfound;
             select avg(z.attachtime),avg(z.activationtime),avg(z.responsedelay) into c_attachtime,c_activationtime,c_responsedelay from z_testresult z ,z_taskinfo t
              where t.taskid=z.taskid and  z.talkstatus=2 and z.attachtime<3000 and z.activationtime<3000 and z.responsetime<3000 and  z.testcode =c_testCode
              and starttime between to_date(to_char(sysdate,'yyyy-mm'),'yyyy-mm') and to_date(to_char(sysdate+1,'yyyy-mm'),'yyyy-mm') group by  z.testcode;
        if c_aramparam='ATTACHTIME' then
           update z_alarm_delay set ALARM_PARAM_VALUE=c_attachtime*c_param_delay where testcode=c_testCode and alarm_param='ATTACHTIME';
        end if;
        if c_aramparam='ACTIVATIONTIME' then
           update z_alarm_delay set ALARM_PARAM_VALUE=c_activationtime*c_param_delay where testcode=c_testCode and alarm_param='ACTIVATIONTIME';
        end if;
        if c_aramparam='RESPONSEDELAY' then
           update z_alarm_delay set ALARM_PARAM_VALUE=c_responsedelay*c_param_delay where testcode=c_testCode and alarm_param='RESPONSEDELAY';
        end if;
      END LOOP;
      close ResultCursor;
      commit;
    exception when others then
      ROLLBACK;
      close ResultCursor;
    END;
  end;


/
