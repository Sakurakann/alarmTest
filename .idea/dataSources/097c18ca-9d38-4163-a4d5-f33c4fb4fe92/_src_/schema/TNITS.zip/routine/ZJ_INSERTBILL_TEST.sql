CREATE procedure zj_insertBill_test
is
  vZ_TaskInfo    z_taskinfo%rowtype;
  vZ_TestResult  z_TestResult%rowtype;
  vStartDate     date;
  vEndDate       date;
  vProgID        number := 123001;
  tmpDuration    number := 1/(24*60);
  tmpInterval    number := 2/(24*60);
  tmpStartTime   date;
  tmpNextCycleTime   date;
  tmpCallerEnd   varchar2(5);
  Resultcursor   pkg_tnits_web.rc_class;
  sqlStr         varchar2(100);
  flag           integer := 0;
begin
  vZ_TestResult.Talkstatus := 2;
  vZ_TestResult.Testresult := 1;
  vZ_TestResult.Callresult := 1;
  vZ_TestResult.Billresult := 1;
  vZ_TaskInfo.Executenum := 30;

  <<loop_begin>>
  if flag = 0 then
    vStartDate := to_date('2009-09-01 00:00:02','yyyy-mm-dd hh24:mi:ss');
    vEndDate := to_date('2009-09-03 00:00:00','yyyy-mm-dd hh24:mi:ss');
    sqlStr := ' select * from z_taskinfo where remark1 = ''009''';
  elsif flag = 1 then
    vStartDate := to_date('2009-09-03 00:00:02','yyyy-mm-dd hh24:mi:ss');
    vEndDate := to_date('2009-09-06 12:04:02','yyyy-mm-dd hh24:mi:ss');
    sqlStr := ' select * from z_taskinfo where remark1 = ''009'' or remark1 = ''008''';
    flag := 2; --中止
  end if;

  begin
    open Resultcursor for sqlStr;
    loop
      fetch Resultcursor into vZ_TaskInfo;
      exit when Resultcursor%notfound;

      tmpStartTime := vStartDate;

      while tmpStartTime < vEndDate loop
        tmpNextCycleTime := tmpStartTime + 2/24;
        for N in 1..30 loop
            tmpCallerEnd := trunc(dbms_random.value(100,999));
            vZ_TestResult.Caller := '17242' || tmpCallerEnd;
            vZ_TestResult.callerDetail := tmpCallerEnd || 'D' || tmpCallerEnd || 'D' || tmpCallerEnd || 'D' || tmpCallerEnd || 'D';
            vZ_TestResult.calledDetail := tmpCallerEnd || 'C' || tmpCallerEnd || 'C' || tmpCallerEnd || 'C' || tmpCallerEnd || 'C';
            vZ_TestResult.ResponseTime := trunc(dbms_random.value(500,3000));

            insert into  Z_TestResult(ID, taskID, ProgID, Caller,
                         Called, StartTime, EndTime, duration, TalkStatus, ExecuteNum,
                         testCode, BreakLine, TestResult, BillResult, ResponseTime,
                         callerDetail, calledDetail, taskName, CallResult)
                  values (SEQ_Z_TestResult_ID.Nextval, vZ_TaskInfo.taskID, vProgID, vZ_TestResult.Caller,
                         vZ_TaskInfo.Called, tmpStartTime, tmpStartTime+tmpDuration,
                         vZ_TaskInfo.Duration, vZ_TestResult.Talkstatus, vZ_TaskInfo.Executenum,
                         401, 0, vZ_TestResult.Testresult, vZ_TestResult.BillResult, vZ_TestResult.ResponseTime,
                         vZ_TestResult.callerDetail, vZ_TestResult.calledDetail,
                         vZ_TaskInfo.taskName, vZ_TestResult.CallResult);

            vProgID := vProgID + 1;
            tmpStartTime := tmpStartTime + tmpInterval;
        end loop;

        tmpStartTime := tmpNextCycleTime;
      end loop;

    end loop;
    close Resultcursor;

    commit;

    if flag = 0 then
      flag := 1; --重复
      goto loop_begin;
    end if;

  exception when others then
    dbms_output.put_line(sqlerrm);
    close Resultcursor;
  	rollback;
  end;
end zj_insertBill_test;


/
