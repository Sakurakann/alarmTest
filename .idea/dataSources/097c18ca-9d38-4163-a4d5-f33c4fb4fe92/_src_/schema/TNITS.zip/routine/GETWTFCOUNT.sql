CREATE FUNCTION GetWTFCount(a_taskID NUMBER, cic_7 Number)
RETURN NUMBER
IS
  intRow  NUMBER;
BEGIN
  SELECT COUNT(*) INTO intRow FROM Z_WTFResult WHERE taskID=a_taskID and (cic7=cic_7 or cic_7 is null);
  return intRow;
END;


/
