CREATE procedure TestUpdatePlantime(
    a_testcode        in number,--注定测试类型
    v_mi              in number)--指定几分钟任务
is
    v_taskid         number:=0;
    v_num            number:=0;
    v_cut            number:=0;
  begin
    update z_taskinfo  set plantime=sysdate  where testcode=a_testcode and EXECUTEMODE=3 and sendstatus=1 and taskstatus=1;
    commit;
    select count(taskid) into v_cut from z_taskinfo where testcode=a_testcode and EXECUTEMODE=3 and sendstatus=1 and taskstatus=1;
    DECLARE CURSOR v_Cursor IS  select taskid from z_taskinfo where testcode=a_testcode and EXECUTEMODE=3 and sendstatus=1  and taskstatus=1;
    BEGIN
     v_num:=0;
      open v_Cursor;
      LOOP
        FETCH v_Cursor INTO v_taskid;
        exit when v_Cursor%notfound;
          update z_taskinfo set plantime=to_date(to_char(plantime,'yyyy-mm-dd hh24:mi'),'yyyy-mm-dd hh24:mi')+(trunc(((60*v_mi)/v_cut),1)*v_num)/86400 where taskid=v_taskid;
          v_num:=v_num+1;
      END LOOP;
      close v_Cursor;
      commit;
    exception when others then
      ROLLBACK;
      close v_Cursor;
    END;
  end;


/
