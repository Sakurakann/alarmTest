CREATE procedure set_death_age(poet VARCHAR2, poet_age NUMBER)

      poet_id NUMBER;

      begin poet_age=poet_age+1
      

end 
print 'the sum is '+ltrim(rtrim(str(@poet_age)))
; 
/
