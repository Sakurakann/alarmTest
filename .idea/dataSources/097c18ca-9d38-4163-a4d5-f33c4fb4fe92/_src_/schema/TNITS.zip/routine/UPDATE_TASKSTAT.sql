CREATE procedure update_taskstat
  is
   c_tasksid       z_taskinfo.tasksid%type;
   v_tcut          number:=0;
   v_zcut          number:=0;
   v_num           number:=0;
  begin
    DECLARE CURSOR ResultCursor IS
        select  tasksid from z_taskinfo where  testcode=839 and remark1='湖北' and remark2 is null group by  tasksid;
    BEGIN
    open ResultCursor;
      LOOP
        FETCH ResultCursor INTO c_tasksid;
        exit when ResultCursor%notfound;
           select sum(testcount) into v_tcut from z_taskinfo where tasksid=c_tasksid;
           select count(*) into v_zcut from z_testresult where taskid in (select taskid from z_taskinfo where tasksid in (select  tasksid from z_taskinfo where tasksid=c_tasksid));
          if v_zcut>=v_tcut then
                update z_taskinfo set remark2=1 where tasksid=c_tasksid;
          else
            select  max((sysdate-istdate)*24*3)  into v_num from z_taskinfo where tasksid=c_tasksid;
            if v_num>=1 then
                 update z_taskinfo set remark2=1 where tasksid=c_tasksid;
            end if;
          end if;
      END LOOP;
       close ResultCursor;
      commit;
    exception when others then
      rollback;
  end;
end;

/
