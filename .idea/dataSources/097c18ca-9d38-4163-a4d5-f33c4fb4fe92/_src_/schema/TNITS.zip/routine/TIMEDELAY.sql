CREATE PROCEDURE timedelay
IS
  v_table1 varchar2(40):='RANAPBILL_';
  vCount number;
  v_zj_CONNECTSTARTTIME  varchar(24);
  v_zj_CCTIME varchar(24);
  v_zj_AUTHREQTIME varchar(24);
  v_zj_AUTHRESTIME varchar(24);
  v_zj_RABREQTIME varchar(24);
  v_zj_RABRESTIME varchar(24);
  v_zj_ALERTINGTIME  varchar(24);
  v_bj_CONNECTSTARTTIME  varchar(24);
  v_bj_CCTIME varchar(24);
  v_bj_AUTHREQTIME varchar(24);
  v_bj_AUTHRESTIME varchar(24);
  v_bj_RABREQTIME varchar(24);
  v_bj_RABRESTIME varchar(24);
  v_bj_ALERTINGTIME  varchar(24);
  v_pj_CONNECTSTARTTIME  varchar(24);
  v_ZJJRDELAY   number;
  v_ZJJQDELAY   number;
  v_ZJZPDELAY   number;
  v_HXWDELAY    number;
  v_ZJZLDELAY   number;
  v_BJXHDELAY   number;
  v_BJZPDELAY   number;
  v_BJJQDELAY   number;
  v_caller varchar(20);
  v_starttime varchar(50);
BEGIN
 insert into z_testresult_timedelay(ID,TASKID,TASKNAME,TESTCODE,PROGID,CALLTYPE,TESTRESULT,CALLRESULT,BILLRESULT,CALLER,CALLED,STARTTIME,ENDTIME,EXECUTENUM,DURATION,TALKSTATUS,RESPONSETIME,TOTALTIME,SENDPACKET,RECVPACKET,LOSTPACKETRATE,ERRPACKETRATE,MINDELAY,MAXDELAY,AVGDELAY,BREAKLINE,CALLERVALUE,CALLEDVALUE,CALLERDETAIL,CALLEDDETAIL,SS7CONTENT,CODEDATA,ATTACHTIME,DETACHTIME,ACTIVATIONTIME,DEACTIVATIONTIME,OPERATETIME,REMARK1,REMARK2,REMARK3,REMARK4,ISTDATE,UPTDATE,REDO,EXTASKID,EXPROGID,GWIP1,GWIP2,TEXT1,TEXT2,TEXT3,TEXT4,SECONDRESPONSETIME,THIRDRESPONSETIME,APN,SOCKETTIME,THIRDRESPONSEENDTIME,APPNAME,SOCKETTIMEALL,RECEIVETIME,DNSTIME,TIMES,DATERECEIVEDELAY,RESPONSEDELAY,SPTODELAY,TOSPDELAY,SECONDRESPONSEENDTIME,ROUTERURL,OPERATEREASON)
 select ID,TASKID,TASKNAME,TESTCODE,PROGID,CALLTYPE,TESTRESULT,CALLRESULT,BILLRESULT,CALLER,CALLED,STARTTIME,ENDTIME,EXECUTENUM,DURATION,TALKSTATUS,RESPONSETIME,TOTALTIME,SENDPACKET,RECVPACKET,LOSTPACKETRATE,ERRPACKETRATE,MINDELAY,MAXDELAY,AVGDELAY,BREAKLINE,CALLERVALUE,CALLEDVALUE,CALLERDETAIL,CALLEDDETAIL,SS7CONTENT,CODEDATA,ATTACHTIME,DETACHTIME,ACTIVATIONTIME,DEACTIVATIONTIME,OPERATETIME,REMARK1,REMARK2,REMARK3,REMARK4,ISTDATE,UPTDATE,REDO,EXTASKID,EXPROGID,GWIP1,GWIP2,TEXT1,TEXT2,TEXT3,TEXT4,SECONDRESPONSETIME,THIRDRESPONSETIME,APN,SOCKETTIME,THIRDRESPONSEENDTIME,APPNAME,SOCKETTIMEALL,RECEIVETIME,DNSTIME,TIMES,DATERECEIVEDELAY,RESPONSEDELAY,SPTODELAY,TOSPDELAY,SECONDRESPONSEENDTIME,ROUTERURL,OPERATEREASON
 from z_testresult where talkstatus=2 and duration>0 and  testcode=801 and starttime>=sysdate-1/144
 and id>(select nvl(max(id),0) from z_testresult_timedelay ) and length(called)=11;    --处理最近10分钟成功的801呼叫
 commit;
 v_table1:=v_table1||(to_char(Sysdate,'yyyymmdd'));
 execute immediate 'INSERT INTO RANAPBILL_timedelay  select * from '||v_table1||'@jtsj where id>(select nvl(max(id),0) from RANAPBILL_timedelay)';
 commit;
 delete from RANAPBILL_timedelay where connectstarttime<=to_char(sysdate-1,'yyyy-mm-dd hh24:mi:ss');
 commit;
  DECLARE CURSOR data_cur IS SELECT id,caller,called,starttime FROM z_testresult_timedelay where state=0;
   BEGIN
   for v_tele in data_cur loop
       v_caller:=v_tele.caller;
       v_starttime:=to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss');
      Select Count(*),max(CONNECTSTARTTIME),max(CCTIME),max(AUTHREQTIME),max(AUTHRESTIME),max(RABREQTIME),max(RABRESTIME),max(ALERTINGTIME) into vCount,v_zj_CONNECTSTARTTIME,v_zj_CCTIME,v_zj_AUTHREQTIME,v_zj_AUTHRESTIME,v_zj_RABREQTIME,v_zj_RABRESTIME,v_zj_ALERTINGTIME from RANAPBILL_timedelay 
       where callerno=v_tele.caller and  SIGNALID = 8 and MSGID = 5  and  connectstarttime>to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss') and connectstarttime<to_char(v_tele.starttime+1/720,'yyyy-mm-dd hh24:mi:ss') order by connectstarttime;   --取主叫话单里的数据
  if vcount=0 then
      select msisdn into  v_caller  from  i_gtdetail where imsi=v_tele.caller;
       Select Count(*),max(CONNECTSTARTTIME),max(CCTIME),max(AUTHREQTIME),max(AUTHRESTIME),max(RABREQTIME),max(RABRESTIME),max(ALERTINGTIME) into vCount,v_zj_CONNECTSTARTTIME,v_zj_CCTIME,v_zj_AUTHREQTIME,v_zj_AUTHRESTIME,v_zj_RABREQTIME,v_zj_RABRESTIME,v_zj_ALERTINGTIME from RANAPBILL_timedelay 
         where callerno=v_caller and  SIGNALID = 8 and MSGID = 5  and  connectstarttime>to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss') and connectstarttime<to_char(v_tele.starttime+1/720,'yyyy-mm-dd hh24:mi:ss') order by connectstarttime;   --取主叫话单里的数据
         
         if vcount>0 then
              --取paging话单里的数据
            Select max(CONNECTSTARTTIME) into v_pj_CONNECTSTARTTIME from RANAPBILL_timedelay 
                where calledno like v_caller and  SIGNALID = 8 and MSGID = 7 and  connectstarttime>to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss') and connectstarttime<to_char(v_tele.starttime+1/720,'yyyy-mm-dd hh24:mi:ss') order by connectstarttime; 
             --取被叫话单里的数据
            Select max(CONNECTSTARTTIME),max(CCTIME),max(AUTHREQTIME),max(AUTHRESTIME),max(RABREQTIME),max(RABRESTIME),max(ALERTINGTIME) into v_bj_CONNECTSTARTTIME,v_bj_CCTIME,v_bj_AUTHREQTIME,v_bj_AUTHRESTIME,v_bj_RABREQTIME,v_bj_RABRESTIME,v_bj_ALERTINGTIME from RANAPBILL_timedelay 
               where callerno like v_caller and  SIGNALID = 8 and MSGID =6 and  connectstarttime>to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss')  and connectstarttime<to_char(v_tele.starttime+1/720,'yyyy-mm-dd hh24:mi:ss') order by connectstarttime;   
         end if;
  else
          --取paging话单里的数据
            Select max(CONNECTSTARTTIME) into v_pj_CONNECTSTARTTIME from RANAPBILL_timedelay 
                where calledno like v_tele.called and  SIGNALID = 8 and MSGID = 7 and  connectstarttime>to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss') and connectstarttime<to_char(v_tele.starttime+1/720,'yyyy-mm-dd hh24:mi:ss') order by connectstarttime; 
             --取被叫话单里的数据
            Select max(CONNECTSTARTTIME),max(CCTIME),max(AUTHREQTIME),max(AUTHRESTIME),max(RABREQTIME),max(RABRESTIME),max(ALERTINGTIME) into v_bj_CONNECTSTARTTIME,v_bj_CCTIME,v_bj_AUTHREQTIME,v_bj_AUTHRESTIME,v_bj_RABREQTIME,v_bj_RABRESTIME,v_bj_ALERTINGTIME from RANAPBILL_timedelay 
               where callerno like v_tele.caller and  SIGNALID = 8 and MSGID =6 and  connectstarttime>to_char(v_tele.starttime-1/720,'yyyy-mm-dd hh24:mi:ss')  and connectstarttime<to_char(v_tele.starttime+1/720,'yyyy-mm-dd hh24:mi:ss') order by connectstarttime;   
  end if;
           v_ZJJRDELAY:= TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_zj_CCTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_zj_CONNECTSTARTTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_ZJJQDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_zj_AUTHRESTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_zj_AUTHREQTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_ZJZPDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_zj_RABRESTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_zj_RABREQTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_HXWDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_pj_CONNECTSTARTTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_zj_RABREQTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_ZJZLDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_zj_ALERTINGTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_zj_CONNECTSTARTTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_BJXHDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_bj_CONNECTSTARTTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_pj_CONNECTSTARTTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_BJZPDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_bj_RABRESTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_bj_RABREQTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
           v_BJJQDELAY:=TO_NUMBER(regexp_substr(TO_CHAR(to_timestamp(v_bj_AUTHRESTIME,'yyyy-mm-dd hh24:mi:ss.ff')-to_timestamp(v_bj_AUTHREQTIME,'yyyy-mm-dd hh24:mi:ss.ff')),'.{1,12}$'));
      update z_testresult_timedelay set ZJJRDELAY=v_ZJJRDELAY,ZJJQDELAY=v_ZJJQDELAY,ZJZPDELAY=v_ZJZPDELAY,HXWDELAY=v_HXWDELAY, ZJZLDELAY=v_ZJZLDELAY,BJXHDELAY=v_BJXHDELAY,BJZPDELAY=v_BJZPDELAY,BJJQDELAY=v_BJJQDELAY,state=2 
          where id=v_tele.id;
      commit;
   END LOOP;
    EXCEPTION
       WHEN OTHERS THEN
           DBMS_OUTPUT.PUT_LINE(SQLERRM);
        rollback;
  END;
END;


/
