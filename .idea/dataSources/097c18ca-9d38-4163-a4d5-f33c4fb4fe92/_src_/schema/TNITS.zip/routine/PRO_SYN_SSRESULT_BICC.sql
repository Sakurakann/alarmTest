CREATE procedure pro_Syn_SSResult_bicc
   is
    tmp_date        varchar2(50);
    tmp_day         varchar2(50);
    tmp_hh          varchar2(50);
    filename        varchar2(100):='';
    file_handle     utl_file.file_type;
    text_buffer     varchar2(1024):='';
  begin
              tmp_date:= to_char(sysdate+5/(24*60),'yyyy-mm-dd HH24:mi');
        	    tmp_day := replace(substr(tmp_date,3,8), '-','');
              tmp_hh:=substr(to_char((to_date(tmp_date,'yyyy-mm-dd HH24:mi')-1/24),'yyyy-mm-dd HH24:mi'),12,2);
                     filename:='ldteltojs'||tmp_day||tmp_hh||'.txt';
                     begin
          		         file_handle := utl_file.fopen('TMP', trim(filename), 'r' , 1000);
                        begin
          			                	utl_file.get_line(file_handle, text_buffer);
                                   if length( text_buffer)<>0 then
                                             insert into Z_SSResult_bak(caller,called,opc,dpc,cic5,iam_d,rlc_n,duration,callstate)
                  				               values (SF_StrArrayStr(text_buffer,'|',0),SF_StrArrayStr(text_buffer,'|',1),SF_StrArrayStr(text_buffer,'|',2),SF_StrArrayStr(text_buffer,'|',3),SF_StrArrayStr(text_buffer,'|',4),to_date(SF_StrArrayStr(text_buffer,'|',5),'YY"年"MM"月"DD"日" HH24"时"MI"分"SS"秒"'),SF_StrArrayStr(text_buffer,'|',6),SF_StrArrayStr(text_buffer,'|',7),SF_StrArrayStr(text_buffer,'|',8));
                                                commit;
                                    end if;
                                          utl_file.fremove('TMP', trim(filename));
                          end;
                end;
  exception when others then
           ROLLBACK;
  end;


/
