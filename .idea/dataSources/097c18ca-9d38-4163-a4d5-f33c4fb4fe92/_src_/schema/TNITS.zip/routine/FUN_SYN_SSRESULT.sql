CREATE function FUN_Syn_SSResult(
    c_id            in number,
    c_caller        in varchar2,
    c_called        in varchar2,
    c_startTime     in varchar2,
    c_endTime       in varchar2,
    c_taskid        in number,
    c_sstype        in number,
    c_tasktype      in number,
    c_ssdbCount     in number)
  return varchar2 is
    tmp             varchar2(2000);
    num              number;
    Message         varchar2(100):='';
  begin
          begin
                      FOR i IN  0..((length(c_called)-5)/3-1)
                            					 LOOP
                                           if   to_number(substr(c_called,0,5))=17240 then
                                                         tmp := ' insert into Z_SSResult(iam_d,iam_n,opc,dpc,caller,called,cic7,cic5,ans,anm_d,rel_d,rlc_d,rel_n,rlc_n,callstate,failureremark,cause,offset,callingstflag,calledstatus,calltrans,sao,msrn,Duration,task_id,interfaceType,task_type) ' ||
                                                               ' select iam_d,iam_n,opc,dpc,caller,called,cic7,cic5,ans,anm_d,rel_d,rlc_d,rel_n,rlc_n,callstate,failureremark,cause,offset,callingstflag,calledstatus,calltrans,sao,msrn,Duration,'||c_taskid||','||c_sstype||','||c_tasktype||' ' ||
                                                               ' from z_ssresult_bak t ' ||
                                                               ' where t.caller = '''||c_caller ||''' ' ||
                                                               ' and t.called = '''||to_number(17240||substr(c_called,(6+i*3),length(c_called))) ||''' ' ||
                                                               ' and t.iam_d >= to_date('''||c_startTime||''',''yyyy-mm-dd hh24:mi:ss'')-5/1440' ||
                                                               ' and t.iam_d <= to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi:ss'')+5/1440';
                            						                     execute immediate tmp;

                                                             commit;
                            					      end if;
                                            if   to_number(substr(c_called,0,6))=125440 then
                            						                     tmp := ' insert into Z_SSResult(iam_d,iam_n,opc,dpc,caller,called,cic7,cic5,ans,anm_d,rel_d,rlc_d,rel_n,rlc_n,callstate,failureremark,cause,offset,callingstflag,calledstatus,calltrans,sao,msrn,Duration,task_id,interfaceType,task_type) ' ||
                                                               ' select iam_d,iam_n,opc,dpc,caller,called,cic7,cic5,ans,anm_d,rel_d,rlc_d,rel_n,rlc_n,callstate,failureremark,cause,offset,callingstflag,calledstatus,calltrans,sao,msrn,Duration,'||c_taskid||','||c_sstype||','||c_tasktype||' ' ||
                                                               ' from z_ssresult_bak t ' ||
                                                               ' where t.caller = '''||c_caller ||''' ' ||
                                                               ' and t.called = '''||to_number(125440||substr(c_called,(7+i*3),length(c_called))) ||''' ' ||
                                                               ' and t.iam_d >= to_date('''||c_startTime||''',''yyyy-mm-dd hh24:mi:ss'')-5/1440' ||

                                                               ' and t.iam_d <= to_date('''||c_endTime||''',''yyyy-mm-dd hh24:mi:ss'')+5/1440';
                               						                    execute immediate tmp;
                                                             commit;
                            					       end if;

                            				   END LOOP;
                                    select count(*) into num from z_ssresult t where t.iam_d >= to_date(c_startTime,'yyyy-mm-dd hh24:mi:ss')-2/1440 and t.iam_d <= to_date(c_endTime,'yyyy-mm-dd hh24:mi:ss')+2/1440 and task_id=c_taskid;
                        					      if num>0 then
                                         delete Z_SSQueryResult where id = c_id;
                                        end if;

              exception when others then
            null;
          end;
     -- delete Z_SSQueryResult where id = c_id;
      commit;
     Message := '同步数据成功.';
    return Message;
  exception when others then
    ROLLBACK;
    Message := '同步数据失败! '||substr(sqlerrm,1,100);
    return Message;
  end;


/
