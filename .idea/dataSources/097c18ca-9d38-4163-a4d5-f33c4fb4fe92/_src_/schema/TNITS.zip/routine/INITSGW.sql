CREATE procedure initsgw is
    v_sgwid          number;
    v_id             number;
  begin
    DECLARE CURSOR ResultCursor IS
      select pgwid from i_pgw where PROVINCE=2600;
     begin
    BEGIN
      open ResultCursor;
      LOOP
        FETCH ResultCursor INTO v_sgwid;
        exit when ResultCursor%notfound;
           select I_PGW_ID.NEXTVAL into v_id from dual;
           update i_pgw set pgwid=v_id where pgwid=v_sgwid;
           update I_PGWIPADDRESS set pgwid=v_id where pgwid=v_sgwid;
        END LOOP;
      close ResultCursor;
      commit;
    exception when others then
      dbms_output.put_line('execption : ' || sqlerrm);
      ROLLBACK;
      close ResultCursor;
    END;
    end;
  end;

/
