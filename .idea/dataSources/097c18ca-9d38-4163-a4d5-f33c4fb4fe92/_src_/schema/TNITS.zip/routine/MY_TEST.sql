CREATE procedure My_Test(num in number)
as
sum integer
@i integer
set @sum=0
set @i=0
while @i<=@num begin
set @sum=@sum+@i
set @i=@i+1
end
print 'the sum is '+ltrim(rtrim(str(@sum)))
/
