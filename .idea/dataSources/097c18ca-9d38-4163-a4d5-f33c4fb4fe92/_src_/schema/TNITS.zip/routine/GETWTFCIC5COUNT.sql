CREATE FUNCTION GetWTFCic5Count(a_taskID NUMBER, CIC_7 Number)
RETURN NUMBER
IS
  intRow  NUMBER;
BEGIN
  SELECT COUNT(distinct cic5) INTO intRow FROM Z_WTFResult WHERE taskID=a_taskID and cic7=cic_7;
  return intRow;
END;


/
