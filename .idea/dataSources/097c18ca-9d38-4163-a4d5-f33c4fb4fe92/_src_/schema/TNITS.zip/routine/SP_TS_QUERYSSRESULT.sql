CREATE procedure SP_TS_QuerySSResult
is
  Message     varchar2(200);
  rs          pkg_tnits_web.rc_class;
begin
  pkg_tnits_web.SP_TS_QuerySSResult(to_char(sysdate-20/(24*60),'yyyy-mm-dd hh24:mi:ss'), to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'), 1, Message, rs);
  dbms_output.put_line(to_char(sysdate-20/(24*60),'yyyy-mm-dd hh24:mi:ss'));
  dbms_output.put_line(to_char(sysdate,'yyyy-mm-dd hh24:mi:ss'));
  dbms_output.put_line(Message);
end;


/
