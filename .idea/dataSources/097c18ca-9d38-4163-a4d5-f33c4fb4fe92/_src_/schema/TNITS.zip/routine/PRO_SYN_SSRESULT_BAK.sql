CREATE procedure pro_Syn_SSResult_bak
   is
    tmp_date        varchar2(50);
    tmp_day         varchar2(50);
    tmp_hh          varchar2(50);
    tmp_mi          varchar2(50);
    filename        varchar2(100):='';
    file_handle     utl_file.file_type;
    rowcount        number:=0;
    flag            number:=0;
    text_buffer     varchar2(1024):='';
    text_tmp        varchar2(1024):='';
    Message         varchar2(500):='';
  begin
         Message := '同步信令成功!';
           tmp_date:= to_char(sysdate+5/(24*60),'yyyy-mm-dd HH24:mi');
                <<quit>>
              filename:='';
              rowcount:=rowcount+1;
             tmp_date:= to_char(to_date(tmp_date,'yyyy-mm-dd HH24:mi')-5/(24*60),'yyyy-mm-dd HH24:mi');
           if rowcount<=3 then
        	    tmp_day := replace(substr(tmp_date,3,8), '-','');
              tmp_hh := substr(tmp_date,12,2);
                    tmp_mi :=(trunc(substr(tmp_date,15,2)/5)+2)*5;
                    if tmp_mi<10 then  tmp_mi:='0'||tmp_mi; end if;
                    if tmp_mi >=60 then
                      tmp_hh:=substr(to_char((to_date(tmp_date,'yyyy-mm-dd HH24:mi')+1/24),'yyyy-mm-dd HH24:mi'),12,2);
                      tmp_mi:='00';
                    end if;
                    filename:='tojs'||tmp_day||tmp_hh||tmp_mi||'.txt';
                     begin
          		         file_handle := utl_file.fopen('TMP', trim(filename), 'r' , 1000);
                        begin
          			               loop
          			                	utl_file.get_line(file_handle, text_buffer);
                                   if length( text_buffer)<>0 then
                                        flag:=flag+1;
                                        if mod(flag,2)<>0 then
                                            text_tmp:=text_buffer;
                                        else
                                            text_buffer:=trim(text_tmp)||trim(text_buffer);
                                                  insert into Z_SSResult_bak(caller,called,opc,dpc,cic7,cic5,iam_d,iam_n,rel_n,rlc_n,duration,callstate,failureremark)
                  				                        values (SF_StrArrayStr(text_buffer,'|',0),SF_StrArrayStr(text_buffer,'|',1),SF_StrArrayStr(text_buffer,'|',2),SF_StrArrayStr(text_buffer,'|',3),SF_StrArrayStr(text_buffer,'|',4),SF_StrArrayStr(text_buffer,'|',5),to_date(SF_StrArrayStr(text_buffer,'|',6), 'yyyy-mm-dd hh24:mi:ss'),SF_StrArrayStr(text_buffer,'|',7),SF_StrArrayStr(text_buffer,'|',8),SF_StrArrayStr(text_buffer,'|',9),SF_StrArrayStr(text_buffer,'|',10),SF_StrArrayStr(text_buffer,'|',11),SF_StrArrayStr(text_buffer,'|',12));
                                                commit;
                                            text_tmp:='';
					    flag:=0;
                                        end if;
                                    end if;
          			              end loop;
                                          utl_file.fremove('TMP', trim(filename));
          			                 exception  when no_data_found then
                                   GOTO quit;
                                end;
                             exception  when   utl_file.invalid_mode  then
                                               GOTO quit;
                                        WHEN   utl_file.invalid_path   THEN
                                                GOTO quit;
                                        WHEN   utl_file.invalid_filehandle   THEN
                                                GOTO quit;
					WHEN   others   THEN
                GOTO quit;
               end;
       end if;
  exception when others then
           ROLLBACK;
  end;


/
