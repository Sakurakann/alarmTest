CREATE function SF_IPIsIN
(
  v_ips    varchar2,
  v_ip        varchar2
)
return number
is
  v_min number;
  v_min2 number;
  v_min3 number;
  v_min4 number;
  v_max number;
  v_max2 number;
  v_max3 number;
  v_max4 number;
  v_tep number;
  v_tep2 number;
  v_tep3 number;
  v_tep4 number;
  v_cut   number;
  v_smin varchar2(1024);
  v_smax varchar2(1024);
  lv_ip varchar2(1024);
  v_str varchar2(1024);
  v_split varchar2(20):='/';
begin
     lv_ip:=ltrim(rtrim(v_ips));
     v_tep:=to_number(SF_StrArrayStr(v_ip,'.',0));
     v_tep2:=to_number(SF_StrArrayStr(v_ip,'.',1));
     v_tep3:=to_number(SF_StrArrayStr(v_ip,'.',2));
     v_tep4:=to_number(SF_StrArrayStr(v_ip,'.',3));
    select decode(LENGTH(REGEXP_REPLACE(REPLACE(lv_ip, v_split, '@'), '[^@]+', '')),1,1,0) into v_cut from dual;
    if v_cut= 1 then
      v_str:=substr(lv_ip,1,instr(lv_ip,v_split)-length(v_split));
      if LENGTH(REGEXP_REPLACE(REPLACE(v_str, '.', '@'), '[^@]+', ''))<=3 then
        v_smin:=v_str||substr(lv_ip,(length(lv_ip)-instr(substr(lv_ip,instr(lv_ip,v_split)+length(v_split),length(lv_ip)),'.',-1,1))+1,length(lv_ip));
        v_min:=to_number(SF_StrArrayStr(v_smin,'.',0));
        v_min2:=to_number(SF_StrArrayStr(v_smin,'.',1));
        v_min3:=to_number(SF_StrArrayStr(v_smin,'.',2));
        v_min4:=to_number(SF_StrArrayStr(v_smin,'.',3));
      end if;
       v_smax:=concat(substr(lv_ip,1,instr(substr(lv_ip,1,instr(lv_ip,v_split)-length(v_split)),'.',-1,1)),substr(lv_ip,instr(lv_ip,v_split)+length(v_split),length(lv_ip)));
       v_max:=to_number(SF_StrArrayStr(v_smax,'.',0));
       v_max2:=to_number(SF_StrArrayStr(v_smax,'.',1));
       v_max3:=to_number(SF_StrArrayStr(v_smax,'.',2));
       v_max4:=to_number(SF_StrArrayStr(v_smax,'.',3));
       if v_tep>=v_min and v_tep<=v_max and v_tep2>=v_min2 and v_tep2<=v_max2 and v_tep3>=v_min3 and v_tep3<=v_max3 and v_tep4>=v_min4 and v_tep4<=v_max4 then
          return 1;
       else 
          return 0;
       end if;
     else
        v_max:=to_number(SF_StrArrayStr(lv_ip,'.',0));
        v_max2:=to_number(SF_StrArrayStr(lv_ip,'.',1));
        v_max3:=to_number(SF_StrArrayStr(lv_ip,'.',2));
        v_max4:=to_number(SF_StrArrayStr(lv_ip,'.',3));
        if v_tep=v_max and v_tep2=v_max2 and v_tep3=v_max3 and v_tep4=v_max4 then 
           return 1;
        else
           return 0;
     end if;
  end if;
end;


/
