CREATE PROCEDURE zj_insertTask_test
is
  vTasksid   number;
  vOutNeCode  varchar2(20);
  vOutNeName  varchar2(50);
  vToNeCode1  varchar2(20);
  vToNeName1  varchar2(50);
  vToNeCode2  varchar2(20);
  vToNeName2  varchar2(50);
  vStartDate  date;
  vEndDate    date;
  flag        integer := 0;
begin
  vStartDate := to_date('2009-09-01 00:00:00','yyyy-mm-dd hh24:mi:ss');
  vEndDate := to_date('2009-09-06 12:00:00','yyyy-mm-dd hh24:mi:ss');

  vOutNeCode := '187';
  vOutNeName := '杭州SSA3出局';

  vToNeCode1 := '171';
  vToNeName1 := '杭州DS1';

  <<loop_begin>>
  if flag = 1 then
    vToNeCode1 := '172';
    vToNeName1 := '杭州DS2';
    flag := 2; --中止
  end if;

  vToNeCode2 := '108';
  vToNeName2 := '杭州GS8';
  select SEQ_Z_TASKINFO_TASKSID.nextval into vTasksid from dual;
  for N in 1..75 loop
    insert into Z_TaskInfo(taskID,tasksID,taskName,testCode,executeMode,cycleUnit,cycleInput,cycleValue,caller,called,duration,interval,testCount,router,gateWay,textInfo,planTime,alarmFlag,sapID,userID,areaID,sendStatus,taskStatus,outNeName,inNeName,toNeName1,toNeName2,toNeName3,outNeCode,inNeCode,toNeCode1,toNeCode2,toNeCode3,Istdate,Uptdate,incFlag,Lastplantime,Firstexecutetime,Lastexecutetime,remark1)
    values(SEQ_Z_TASKINFO_TASKID.nextval,vTasksid,'电路('||vOutNeName||'-'||vToNeName1||'-'||vToNeName2||')',401,3,2,2,120,17240,'17240'||vToNeCode1||vToNeCode2||vToNeCode1||vOutNeCode||'999',60,120,30,0,'','',to_date('2009-09-07 10:00:00','yyyy-mm-dd hh24:mi:ss'),0,400,2,100,8,8,vOutNeName,'',vToNeName1,vToNeName2,'',vOutNeCode,'',vToNeCode1,vToNeCode2,'',vStartDate,vStartDate,'00',vEndDate,vStartDate,vEndDate,'009');
  end loop;
  for N in 1..75 loop
    insert into Z_TaskInfo(taskID,tasksID,taskName,testCode,executeMode,cycleUnit,cycleInput,cycleValue,caller,called,duration,interval,testCount,router,gateWay,textInfo,planTime,alarmFlag,sapID,userID,areaID,sendStatus,taskStatus,outNeName,inNeName,toNeName1,toNeName2,toNeName3,outNeCode,inNeCode,toNeCode1,toNeCode2,toNeCode3,Istdate,Uptdate,incFlag,Lastplantime,Firstexecutetime,Lastexecutetime,remark1)
    values(SEQ_Z_TASKINFO_TASKID.nextval,vTasksid,'电路('||vOutNeName||'-'||vToNeName1||'-'||vToNeName2||')',401,3,2,2,120,17240,'17240'||vToNeCode1||vToNeCode2||vToNeCode1||vOutNeCode||'999',60,120,30,0,'','',to_date('2009-09-07 10:00:00','yyyy-mm-dd hh24:mi:ss'),0,400,2,100,8,8,vOutNeName,'',vToNeName1,vToNeName2,'',vOutNeCode,'',vToNeCode1,vToNeCode2,'',vStartDate,vStartDate,'00',vEndDate,vStartDate,vEndDate,'008');
  end loop;


  vToNeCode2 := '108';
  vToNeName2 := '杭州GS8';
  select SEQ_Z_TASKINFO_TASKSID.nextval into vTasksid from dual;
  for N in 1..75 loop
    insert into Z_TaskInfo(taskID,tasksID,taskName,testCode,executeMode,cycleUnit,cycleInput,cycleValue,caller,called,duration,interval,testCount,router,gateWay,textInfo,planTime,alarmFlag,sapID,userID,areaID,sendStatus,taskStatus,outNeName,inNeName,toNeName1,toNeName2,toNeName3,outNeCode,inNeCode,toNeCode1,toNeCode2,toNeCode3,Istdate,Uptdate,incFlag,Lastplantime,Firstexecutetime,Lastexecutetime,remark1)
    values(SEQ_Z_TASKINFO_TASKID.nextval,vTasksid,'电路('||vOutNeName||'-'||vToNeName1||'-'||vToNeName2||')',401,3,2,2,120,17240,'17240'||vToNeCode1||vToNeCode2||vToNeCode1||vOutNeCode||'999',60,120,30,0,'','',to_date('2009-09-07 10:00:00','yyyy-mm-dd hh24:mi:ss'),0,400,2,100,8,8,vOutNeName,'',vToNeName1,vToNeName2,'',vOutNeCode,'',vToNeCode1,vToNeCode2,'',vStartDate,vStartDate,'00',vEndDate,vStartDate,vEndDate,'009');
  end loop;
  for N in 1..75 loop
    insert into Z_TaskInfo(taskID,tasksID,taskName,testCode,executeMode,cycleUnit,cycleInput,cycleValue,caller,called,duration,interval,testCount,router,gateWay,textInfo,planTime,alarmFlag,sapID,userID,areaID,sendStatus,taskStatus,outNeName,inNeName,toNeName1,toNeName2,toNeName3,outNeCode,inNeCode,toNeCode1,toNeCode2,toNeCode3,Istdate,Uptdate,incFlag,Lastplantime,Firstexecutetime,Lastexecutetime,remark1)
    values(SEQ_Z_TASKINFO_TASKID.nextval,vTasksid,'电路('||vOutNeName||'-'||vToNeName1||'-'||vToNeName2||')',401,3,2,2,120,17240,'17240'||vToNeCode1||vToNeCode2||vToNeCode1||vOutNeCode||'999',60,120,30,0,'','',to_date('2009-09-07 10:00:00','yyyy-mm-dd hh24:mi:ss'),0,400,2,100,8,8,vOutNeName,'',vToNeName1,vToNeName2,'',vOutNeCode,'',vToNeCode1,vToNeCode2,'',vStartDate,vStartDate,'00',vEndDate,vStartDate,vEndDate,'008');
  end loop;


  vToNeCode2 := '102';
  vToNeName2 := '杭州GS2';
  select SEQ_Z_TASKINFO_TASKSID.nextval into vTasksid from dual;
  for N in 1..50 loop
    insert into Z_TaskInfo(taskID,tasksID,taskName,testCode,executeMode,cycleUnit,cycleInput,cycleValue,caller,called,duration,interval,testCount,router,gateWay,textInfo,planTime,alarmFlag,sapID,userID,areaID,sendStatus,taskStatus,outNeName,inNeName,toNeName1,toNeName2,toNeName3,outNeCode,inNeCode,toNeCode1,toNeCode2,toNeCode3,Istdate,Uptdate,incFlag,Lastplantime,Firstexecutetime,Lastexecutetime,remark1)
    values(SEQ_Z_TASKINFO_TASKID.nextval,vTasksid,'电路('||vOutNeName||'-'||vToNeName1||'-'||vToNeName2||')',401,3,2,2,120,17240,'17240'||vToNeCode1||vToNeCode2||vToNeCode1||vOutNeCode||'999',60,120,30,0,'','',to_date('2009-09-07 10:00:00','yyyy-mm-dd hh24:mi:ss'),0,400,2,100,8,8,vOutNeName,'',vToNeName1,vToNeName2,'',vOutNeCode,'',vToNeCode1,vToNeCode2,'',vStartDate,vStartDate,'00',vEndDate,vStartDate,vEndDate,'009');
  end loop;
  for N in 1..50 loop
    insert into Z_TaskInfo(taskID,tasksID,taskName,testCode,executeMode,cycleUnit,cycleInput,cycleValue,caller,called,duration,interval,testCount,router,gateWay,textInfo,planTime,alarmFlag,sapID,userID,areaID,sendStatus,taskStatus,outNeName,inNeName,toNeName1,toNeName2,toNeName3,outNeCode,inNeCode,toNeCode1,toNeCode2,toNeCode3,Istdate,Uptdate,incFlag,Lastplantime,Firstexecutetime,Lastexecutetime,remark1)
    values(SEQ_Z_TASKINFO_TASKID.nextval,vTasksid,'电路('||vOutNeName||'-'||vToNeName1||'-'||vToNeName2||')',401,3,2,2,120,17240,'17240'||vToNeCode1||vToNeCode2||vToNeCode1||vOutNeCode||'999',60,120,30,0,'','',to_date('2009-09-07 10:00:00','yyyy-mm-dd hh24:mi:ss'),0,400,2,100,8,8,vOutNeName,'',vToNeName1,vToNeName2,'',vOutNeCode,'',vToNeCode1,vToNeCode2,'',vStartDate,vStartDate,'00',vEndDate,vStartDate,vEndDate,'008');
  end loop;

  if flag = 0 then
    flag := 1; --重复
    goto loop_begin;
  end if;

  commit;
exception when others then
  rollback;
end;


/
