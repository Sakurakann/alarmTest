CREATE procedure test is
  vnum  number:=0;
begin

 SELECT count(*) into vnum FROM user_tables  where TABLE_NAME=UPPER('S_Version');
  if vnum>0 then
     select count(*) into vnum from S_Version;
      if vnum=0 then
      	  execute immediate ' insert into s_version(newversion,newdate,lastversion,lastdate) values (''ver-2015-08-17'',sysdate,'''',sysdate)';
 	    else
         execute immediate ' update s_version set lastversion=newversion,lastdate=newdate,newversion=''ver-2015-08-17'',newdate=sysdate';
      end if;
   end if;
exception when others then
  dbms_output.put_line(sqlerrm);

end test;


/
