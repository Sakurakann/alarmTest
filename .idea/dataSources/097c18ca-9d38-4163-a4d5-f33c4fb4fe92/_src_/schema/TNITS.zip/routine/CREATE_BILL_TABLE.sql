CREATE procedure Create_bill_table
   is
    v_table varchar2(40):='SS7BILL_';
    v_table1 varchar2(40):='BICCBILL_';
    v_table2 varchar2(40):='SS7MSG_';
    v_table3 varchar2(40):='BiccSignal_';
    v_drop varchar2(40):='';
     c_sql   varchar2(2000):='';
     c_count  number:=0;
  begin

	v_drop:=v_table||(to_char(Sysdate-30,'yyyymmdd'));
	c_sql:= 'drop table tnits.'||v_drop
		|| ' purge';
	select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_drop);
      	if  c_count >0 then
	   execute immediate c_sql;
	end if;

	v_drop:=v_table1||(to_char(Sysdate-30,'yyyymmdd'));
	c_sql:= 'drop table tnits.'||v_drop
		|| ' purge';
	select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_drop);
      	if  c_count >0 then
	   execute immediate c_sql;
	end if;

	v_drop:=v_table2||(to_char(Sysdate-30,'yyyymmdd'));
	c_sql:= 'drop table tnits.'||v_drop
		|| ' purge';
	select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_drop);
      	if  c_count >0 then
	   execute immediate c_sql;
	end if;

	v_drop:=v_table3||(to_char(Sysdate-30,'yyyymmdd'));
	c_sql:= 'drop table tnits.'||v_drop
		|| ' purge';
	select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_drop);
      	if  c_count >0 then
	   execute immediate c_sql;
	end if;



       v_table:=v_table||(to_char(Sysdate+1,'yyyymmdd'));
       v_table1:=v_table1||(to_char(Sysdate+1,'yyyymmdd'));
       v_table2:=v_table2||(to_char(Sysdate+1,'yyyymmdd'));
       v_table3:=v_table3||(to_char(Sysdate+1,'yyyymmdd'));
      execute immediate  'grant create table to tnits';

      select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_table);
      if  c_count =0 then
          c_sql:= ' create table tnits.'||v_table
                  	||' ('
					||'ID                             NUMBER(8,0) NOT NULL,'
					||'BILLID                         NUMBER,'
					||'AREAID                         NUMBER,'
					||'CDRTYPE                        NUMBER,'
					||'PCPRO                          NUMBER,'
					||'PROTOCOLTYPE                   NUMBER,'
					||'PCM                            NUMBER,'
					||'SLOT                           NUMBER,'
					||'CDRDIR                         NUMBER,'
					||'OPC                            NUMBER,'
					||'DPC                            NUMBER,'
					||'CALLERNO                       VARCHAR2(32),'
					||'CALLEDNO                       VARCHAR2(32),'
					||'CALLEDOTHER                    VARCHAR2(32),'
					||'DTMF                           VARCHAR2(32),'
					||'IAMTIME                        VARCHAR2(24),'
					||'ACMTIME                        VARCHAR2(24),'
					||'ANMTIME                        VARCHAR2(24),'
					||'RELTIME                        VARCHAR2(24),'
					||'CALLRESULT                     NUMBER,'
					||'TALKLONG                       NUMBER,'
					||'CALLLONG                       NUMBER,'
					||'RECORDDATE                     DATE DEFAULT SYSDATE,'
					||' CONSTRAINT '||v_table||'_PK PRIMARY KEY (ID)'
					||' )'
					||' tablespace USERS'
					||' pctfree 10'
					||' initrans 1'
					||' maxtrans 255'
					||' storage'
					||' ('
					||' initial 10K'
					||' minextents 1'
					||' maxextents unlimited'
					||' )';
					execute immediate c_sql;

               commit;
        end if;

        select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_table1);
      if  c_count =0 then
          c_sql:= ' create table tnits.'||v_table1
                  	||' ('
					||'	   ID							   NUMBER(8,0) NOT NULL,'
					||'    MSGID                      	   NUMBER,      '
					||'    MSGTYPEID                      NUMBER,     '
					||'    BILLID						   NUMBER,    '
					||'    AREAID						   NUMBER,      '
					||'    OPC                            NUMBER,      '
					||'    DPC                            NUMBER,      '
					||'    CIC						   	   NUMBER,      '
					||'    CALLID						   NUMBER,     '
					||'    SPC							   NUMBER,       '
					||'    CALLERNO					   VARCHAR2(32),    '
					||'    CALLERMIP					   VARCHAR2(20),    '
					||'    CALLERMPORT					   NUMBER,        '
					||'    CALLEDNO					   VARCHAR2(32),    '
					||'    CALLEDMIP					   VARCHAR2(20),    '
					||'    CALLEDMPORT					   NUMBER,        '
					||'    CALLEDOTHER					   VARCHAR2(32),    '
					||'    DTMF						   VARCHAR2(24),    '
					||'    IAMTIME						   VARCHAR2(24),    '
					||'    ACMTIME						   VARCHAR2(24),    '
					||'    ANMTIME						   VARCHAR2(24),    '
					||'    RELTIME						   VARCHAR2(24),    '
					||'    RLCTIME						   VARCHAR2(24), '
					||'    CALLRESULT					   NUMBER,      '
					||'    RELEASEDIR					   NUMBER,      '
					||'    CALLLONG					   NUMBER,        '
					||'    TALKLONG					   NUMBER,         '
					||'    FILENAME					   VARCHAR2(100),   '
					||'    RECORDDATE                     DATE DEFAULT SYSDATE,'
					||' CONSTRAINT '||v_table1||'_PK PRIMARY KEY (ID)'
					||' )'
					||' tablespace USERS'
					||' pctfree 10'
					||' initrans 1'
					||' maxtrans 255'
					||' storage'
					||' ('
					||' initial 10K'
					||' minextents 1'
					||' maxextents unlimited'
					||' )';
					execute immediate c_sql;


               commit;
        end if;

        select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_table2);
      if  c_count =0 then
          c_sql:= ' create table tnits.'||v_table2
                  	||' ('
					||'ID                             NUMBER(8,0) NOT NULL,'
					||'    MSGID                          NUMBER,     '
					||'    MSGTYPEID                      NUMBER,   '
					||'    OPC                            NUMBER,     '
					||'    DPC                            NUMBER,    '
					||'    CDRID                          NUMBER,     '
					||'    CIC                            NUMBER,     '
					||'    SLS                            NUMBER,     '
					||'    CALLERTYPE                     NUMBER,      '
					||'    CALLERNO                       VARCHAR2(32),   '
					||'    CALLEDNO                       VARCHAR2(32),  '
					||'    BACKFLAG                       NUMBER,   '
					||'    MSGTIME                        NUMBER,    '
					||'    MSGMTIME                       NUMBER,    '
					||'    CALLRESULT                     NUMBER,     '
					||'    RECORDDATE                     DATE DEFAULT SYSDATE,'
					||'    CONSTRAINT '||v_table2||'_PK PRIMARY KEY (ID)'
					||' )'
					||' tablespace USERS'
					||' pctfree 10'
					||' initrans 1'
					||' maxtrans 255'
					||' storage'
					||' ('
					||' initial 10K'
					||' minextents 1'
					||' maxextents unlimited'
					||' )';
					execute immediate c_sql;

               commit;
        end if;

        select count(*) into  c_count  from USER_TABLES where table_name=UPPER(v_table3);
      if  c_count =0 then
          c_sql:= ' create table tnits.'||v_table3
                  	||' ('
					||'ID                             NUMBER(8,0) NOT NULL,'
					||'    MSGID                          NUMBER,     '
					||'    MSGTYPEID                      NUMBER,   '
					||'    OPC                            NUMBER,     '
					||'    DPC                            NUMBER,    '
					||'    CDRID                          NUMBER,     '
					||'    CIC                            NUMBER,     '
					||'    SLS                            NUMBER,     '
					||'    CALLERTYPE                     NUMBER,      '
					||'    CALLERNO                       VARCHAR2(32),   '
					||'    CALLEDNO                       VARCHAR2(32),  '
					||'    BACKFLAG                       NUMBER,   '
					||'    MSGTIME                        NUMBER,    '
					||'    MSGMTIME                       NUMBER,    '
					||'    CALLRESULT                     NUMBER,     '
					||'    RECORDDATE                     DATE DEFAULT SYSDATE,'
					||'    CONSTRAINT '||v_table3||'_PK PRIMARY KEY (ID)'
					||' )'
					||' tablespace USERS'
					||' pctfree 10'
					||' initrans 1'
					||' maxtrans 255'
					||' storage'
					||' ('
					||' initial 10K'
					||' minextents 1'
					||' maxextents unlimited'
					||' )';
					execute immediate c_sql;

               commit;
        end if;

    exception when others then
     rollback;
   end;


/
