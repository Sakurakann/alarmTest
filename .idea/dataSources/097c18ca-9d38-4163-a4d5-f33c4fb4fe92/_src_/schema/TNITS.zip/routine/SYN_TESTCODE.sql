CREATE procedure syn_testcode is
    c_id            s_testtype.id%type;
    v_testcodes     varchar2(500):='';
    v_list          varchar2(500):='';
   l_idx  pls_integer;
   v_code varchar2(50):='';
  begin
    DECLARE CURSOR ResultCursor IS
      select id from s_testtype;
    BEGIN
      open ResultCursor;
      LOOP
        FETCH ResultCursor INTO c_id;
        exit when ResultCursor%notfound;
           select testcode into v_testcodes from s_testtype where id=c_id;
           v_list:=v_testcodes;
            begin
               loop
                    l_idx := instr(v_list,',');
                    if l_idx > 0 then
                        v_code:=substr(v_list,1,l_idx-1);
                         insert into T_TYPE_TESTCODE (ID, TESTCODE, TYPEID, REMARK, ISTDATE, UPTDATE)
                            values (T_TYPE_TESTCODE_ID.Nextval, v_code, c_id, null,sysdate,sysdate);
                        v_list := substr(v_list,l_idx+length(','));
                    else
                         v_code:=v_list;
                         insert into T_TYPE_TESTCODE (ID, TESTCODE, TYPEID, REMARK, ISTDATE, UPTDATE)
                            values (T_TYPE_TESTCODE_ID.Nextval, v_code, c_id, null,sysdate,sysdate);
                      exit;
                    end if;
                end loop;
              end ;
         END LOOP;
         close ResultCursor;
      commit;
    exception when others then
      ROLLBACK;
      close ResultCursor;
      dbms_output.put_line(sqlerrm);
    END;
  end;


/
