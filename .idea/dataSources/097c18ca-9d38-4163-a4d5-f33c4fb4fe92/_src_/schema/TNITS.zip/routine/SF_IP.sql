CREATE function SF_IP
(
  v_ipaddr    varchar2,
  v_split     varchar2  --分隔符号
)
return varchar2
is
  v_str varchar2(1024);
  lv_ip varchar2(1024);
begin
     lv_ip:=ltrim(rtrim(v_ipaddr));
     v_str:=substr(lv_ip,1,instr(lv_ip,v_split)-length(v_split));
    if LENGTH(REGEXP_REPLACE(REPLACE(v_str, '.', '@'), '[^@]+', ''))<3 then
       v_str:=v_str||substr(lv_ip,(length(lv_ip)-instr(substr(lv_ip,instr(lv_ip,v_split)+length(v_split),length(lv_ip)),'.',-1,1))+1,length(lv_ip));
    end if;
    v_str:=v_str||'-'||concat(substr(lv_ip,1,instr(substr(lv_ip,1,instr(lv_ip,v_split)-length(v_split)),'.',-1,1)),substr(lv_ip,instr(lv_ip,v_split)+length(v_split),length(lv_ip)));
  return  v_str;
end;


/
