CREATE procedure initphone is
    c_testCode       S_TestCode.TestCode%type;
    c_phone          I_GTDETAIL.MSISDN%type;
    c_count          number;
  begin
    c_count := 0;
    DECLARE CURSOR ResultCursor IS
      select testCode from S_TestCode where state = 1;
     begin
    DECLARE CURSOR ResultCursor2 IS
      select MSISDN from I_GTDETAIL where state = 0;
    BEGIN
      dbms_output.put_line('start exec...');
      open ResultCursor;
      LOOP
        FETCH ResultCursor INTO c_testCode;
        exit when ResultCursor%notfound;
             open ResultCursor2;
               LOOP
                   FETCH ResultCursor2 INTO c_phone;
                      exit when ResultCursor2%notfound;
                     insert into S_ROLE_PHONE values (5,c_phone,c_testCode);
                     c_count := c_count + 1;
               END LOOP;
	      close ResultCursor2;
      END LOOP;
      close ResultCursor;
      commit;
      dbms_output.put_line('insert count : ' || c_count);
    exception when others then
      dbms_output.put_line('execption : ' || sqlerrm);
      ROLLBACK;
      close ResultCursor2;
      close ResultCursor;
    END;
    end;
  end;


/
