CREATE FUNCTION strcat(
  input varchar2
)RETURN varchar2
PARALLEL_ENABLE AGGREGATE USING strcat_type;


/
