CREATE TRIGGER TG_Z_ALARM_DEL
  
 AFTER UPDATE 
	
  ON Z_ALARM
  
 FOR EACH ROW 
declare
  RecSum number;
begin
   if :new.alarmState = 2 then
       select count(*) into RecSum from Z_AlarmHis where id = :old.id;
       if RecSum=0 then
          insert into Z_AlarmHis(id,taskID,taskName,testCode,switchName,alarmNumber,alarmClass,alarmLevel,
          alarmTitle,alarmDetail,alarmType,alarmParamType,alarmParam,clearMode,clearParamType,clearParam,
          alarmState,sendFlag,sendCount,alarmDate,clearDate)
          values(:old.id,:old.taskID,:old.taskName,:old.testCode,:old.switchName,:old.alarmNumber,:old.alarmClass,:old.alarmLevel,
          :old.alarmTitle,:old.alarmDetail,:old.alarmType,:old.alarmParamType,:old.alarmParam,:old.clearMode,:old.clearParamType,:old.clearParam,
          :new.alarmState,:old.sendFlag,:old.sendCount,:old.alarmDate,:old.clearDate);
       end if;
   end if;
END;
/
