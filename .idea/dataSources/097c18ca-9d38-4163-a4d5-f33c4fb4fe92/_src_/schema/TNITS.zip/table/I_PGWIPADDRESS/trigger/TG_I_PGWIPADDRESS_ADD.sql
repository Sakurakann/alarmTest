CREATE TRIGGER TG_I_PGWIPADDRESS_ADD
  
 BEFORE INSERT 
	
  ON I_PGWIPADDRESS
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
   select I_PGWIPADDRESS_ID.NEXTVAL into next_id from dual;
  :new.ID := next_id;
END;
/
