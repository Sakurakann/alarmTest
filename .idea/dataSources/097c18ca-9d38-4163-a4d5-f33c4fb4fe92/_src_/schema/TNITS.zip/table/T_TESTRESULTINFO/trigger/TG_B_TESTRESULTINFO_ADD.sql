CREATE TRIGGER TG_B_TESTRESULTINFO_ADD
  
 BEFORE INSERT 
	
  ON T_TESTRESULTINFO
  
 FOR EACH ROW 
declare
  next_id number;
  duration_time number;
BEGIN
  select connect_time into  duration_time from t_taskinfo where task_id=:new.task_id;
  select SEQ_B_TESTRESULT_ID.nextval into next_id from dual;
  :new.result_id := next_id;
  :new.insert_date_time := sysdate;
  :new.record_date_time := sysdate;
  if (:new.line_connection_time-duration_time)<5 then
    :new.breakline:=1;
    :new.durationdiff:=:new.line_connection_time+5;
  else
     :new.breakline:=0;
     :new.durationdiff:=0;
  end if;
  NULL;
END;
/
