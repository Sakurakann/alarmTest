CREATE TRIGGER TG_Z_SSQUERYRESULT_T_ADD
  
 BEFORE INSERT 
	
  ON T_TESTRESULTINFO
  
 FOR EACH ROW 
DECLARE
  next_id      number;
  c_count      number;
  start_time   Date;
  tmp          number;
  duration_time number;
begin
  select SEQ_B_TESTRESULT_ID.nextval into next_id from dual;
  select connect_time into  duration_time from t_taskinfo where task_id=:new.task_id;
  :new.result_id := next_id;
  :new.insert_date_time := sysdate;
  :new.record_date_time := sysdate;

  if (:new.line_connection_time-duration_time)<5 then
    :new.breakline:=1;
    :new.durationdiff:=:new.line_connection_time+5;
  else
     :new.breakline:=0;
     :new.durationdiff:=0;
  end if;

  select paramValue into tmp from S_Param where paramName = 'SS_T_INTERFACE_TYPE';
  if tmp = 0 then
    return;
  end if;

  select count(*) into c_count  from t_taskinfo t  where t.istType=1 and t.task_id=:new.TASK_ID;
  if c_count>0 then
      select SEND_TIME  into start_time  from t_taskinfo t  where t.istType=1 and t.task_id=:new.TASK_ID;
      insert into tnits.Z_SSQueryResult( id,TASK_ID, caller,called,CALLTYPE,START_TIME,END_TIME,ss_type,task_type)--中兴接口，任务类型
           values (SEQ_Z_SSQUERYRESULT_ID.nextval,:new.TASK_ID,:new.PLINE_TEL_NUM,:new.SLINE_TEL_NUM,:new.CALL_RESULT,start_time,:new.RECORD_DATE_TIME,2,2);
  end if;
end;
/
