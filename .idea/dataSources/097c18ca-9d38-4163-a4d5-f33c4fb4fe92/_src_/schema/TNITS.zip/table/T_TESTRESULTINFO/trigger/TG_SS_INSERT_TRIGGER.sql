CREATE TRIGGER TG_SS_INSERT_TRIGGER
  
 BEFORE INSERT 
	
  ON T_TESTRESULTINFO
  
 FOR EACH ROW 
DECLARE
  c_count      number;
  start_time    Date;
begin
  select count(*) into c_count  from t_taskinfo t  where t.istType=1 and t.task_id=:new.TASK_ID;
   if c_count>0 then
        select SEND_TIME  into start_time  from t_taskinfo t  where t.istType=1 and t.task_id=:new.TASK_ID;
        insert into tnits.Z_SSQueryResult( id,TASK_ID, caller,called,CALLTYPE,ss_type,task_type,START_TIME,END_TIME)
             values (SEQ_Z_SSQUERYRESULT_ID.nextval,:new.TASK_ID,:new.PLINE_TEL_NUM,:new.SLINE_TEL_NUM,:new.CALL_RESULT,1,2,start_time,:new.RECORD_DATE_TIME);
    end if;
end;
/
