CREATE TRIGGER Z_TESTRESULT_CENTER_ADD
  
 BEFORE INSERT 
	
  ON Z_TESTRESULT_CENTER
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select SEQ_Z_TestResult_Center_ID.nextval into next_id from dual;
  :new.id := next_id;
END;
/
