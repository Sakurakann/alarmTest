CREATE TRIGGER TG_Z_SSRESULT_BAK_ADD
  
 BEFORE INSERT 
	
  ON Z_SSRESULT_BAK
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select SEQ_Z_SSRESULT_bak_ID.nextval into next_id from dual;
  :new.id := next_id;
END;
/
