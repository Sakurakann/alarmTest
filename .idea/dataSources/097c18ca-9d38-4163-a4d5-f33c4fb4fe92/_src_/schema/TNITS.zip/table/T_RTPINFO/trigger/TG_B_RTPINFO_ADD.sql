CREATE TRIGGER TG_B_RTPINFO_ADD
  
 BEFORE INSERT 
	
  ON T_RTPINFO
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select SEQ_B_RTPINFO_ID.nextval into next_id from dual;
  :new.rtp_ID := next_id;
  NULL;
END;
/
