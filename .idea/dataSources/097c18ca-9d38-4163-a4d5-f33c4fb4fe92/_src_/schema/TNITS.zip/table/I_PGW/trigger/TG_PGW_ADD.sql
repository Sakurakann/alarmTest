CREATE TRIGGER TG_PGW_ADD
  
 BEFORE INSERT 
	
  ON I_PGW
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  -- select I_PGW_ID.NEXTVAL into next_id from dual;
  --:new.PGWID := next_id;
  :new.province:=2600;
END;
/
