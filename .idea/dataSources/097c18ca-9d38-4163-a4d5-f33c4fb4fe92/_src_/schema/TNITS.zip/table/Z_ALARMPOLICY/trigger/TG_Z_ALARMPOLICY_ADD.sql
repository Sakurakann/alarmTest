CREATE TRIGGER TG_Z_ALARMPOLICY_ADD
  
 BEFORE INSERT 
	
  ON Z_ALARMPOLICY
  
 FOR EACH ROW 
declare
  Next_ID number;
begin
  select SEQ_Z_AlarmPolicy_ID.nextval into Next_ID from dual;
  :New.ID := Next_ID;
end;
/
