CREATE TRIGGER TG_Z_SSRESULT_ADD
  
 BEFORE INSERT 
	
  ON Z_SSRESULT
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select SEQ_Z_SSResult_ID.nextval into next_id from dual;
  :new.id := next_id;
END;
/
