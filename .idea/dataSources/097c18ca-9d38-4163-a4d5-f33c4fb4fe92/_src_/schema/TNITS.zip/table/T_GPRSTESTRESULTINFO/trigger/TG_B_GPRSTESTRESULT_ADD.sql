CREATE TRIGGER TG_B_GPRSTESTRESULT_ADD
  
 BEFORE INSERT 
	
  ON T_GPRSTESTRESULTINFO
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select SEQ_B_GPRSTESTRESULT_ID.nextval into next_id from dual;
  :new.result_id := next_id;
  :new.insert_date_time := sysdate;
  :new.record_date_time := sysdate;
  NULL;
END;
/
