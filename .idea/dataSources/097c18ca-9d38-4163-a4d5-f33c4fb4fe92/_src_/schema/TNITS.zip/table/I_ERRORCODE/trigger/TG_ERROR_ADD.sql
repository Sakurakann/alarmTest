CREATE TRIGGER TG_ERROR_ADD
  
 BEFORE INSERT 
	
  ON I_ERRORCODE
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select I_ERROR_I.nextval into next_id from dual;
  :new.id := next_id;
END;
/
