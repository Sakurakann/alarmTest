CREATE TRIGGER TG_I_SWITCH_DEL
  
 AFTER DELETE 
	
  ON I_SWITCH
  
 FOR EACH ROW 
declare
  RecSum number;
begin
   --if :new.swtstate = 0 then
       select count(*) into RecSum from I_SWITCH_bak where SWITCHID = :old.SWITCHID;
       if RecSum=0 then
          insert into I_SWITCH_bak(SWITCHID,SWITCHNAME,SWITCHTYPE,SWITCHCODE,AREAID,ROUTER ,SSCODE ,REMARK,ISTDATE,UPTDATE,SWTSTATE)
          values(:old.SWITCHID,:old.SWITCHNAME,:old.SWITCHTYPE,:old.SWITCHCODE,:old.AREAID,:old.ROUTER,:old.SSCODE,:old.REMARK,sysdate,sysdate,0);
       end if;
  -- end if;
END;
/
