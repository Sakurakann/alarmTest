CREATE TRIGGER TG_SGW_ADD
  
 BEFORE INSERT 
	
  ON I_SGW
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
select I_SGW_ID.NEXTVAL into next_id from dual;
  :new.SGWID := next_id;
    :new.province:=2600;
END;
/
