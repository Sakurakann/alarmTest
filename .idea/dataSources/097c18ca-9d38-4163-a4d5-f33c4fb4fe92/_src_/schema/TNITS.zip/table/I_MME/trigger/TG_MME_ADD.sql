CREATE TRIGGER TG_MME_ADD
  
 BEFORE INSERT 
	
  ON I_MME
  
 FOR EACH ROW 
declare
  next_id number;
  prov    number;
BEGIN
  select I_MME_ID.NEXTVAL into next_id from dual;
  select paramvalue into prov from s_param where paramname='VOLTE_STATAREACODE';
  --:new.MMEID := next_id;
 -- :new.province:=2900;
END;
/
