CREATE TRIGGER TG_PSBC_ADD
  
 BEFORE INSERT 
	
  ON I_PSBC
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  -- select I_PSBC_ID.NEXTVAL into next_id from dual;
  --:new.PGWID := next_id;
  :new.province:=2900;
END;
/
