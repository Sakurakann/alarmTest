CREATE TRIGGER TG_BILLMSG_ADD
  
 BEFORE INSERT 
	
  ON BILLMSG20150602
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
  select seq_BILLMSG.nextval into next_id from dual;
  :new.id := next_id;
END;
/
