CREATE TRIGGER TG_I_SGWIPADDRESS_ADD
  
 BEFORE INSERT 
	
  ON I_SGWIPADDRESS
  
 FOR EACH ROW 
declare
  next_id number;
BEGIN
   select I_sgwipaddress_ID.NEXTVAL into next_id from dual;
  :new.ID := next_id;
END;
/
