CREATE VIEW V_AREA_AND_GROUP AS select "AREANAME","ID","AREAID","TYPE","TYPENAME" from (	select a.agname as areaname,'A_'|| a.agid as id,b.areadid as areaid,1 as type,'片区' as typename from i_area_group_name a	inner join i_area_group b on a.agid = b.agid	union	select a.areaname,'B_'||a.areaid  as id,a.areaid,2 as type,'地区' as typename from i_area a	)
/
