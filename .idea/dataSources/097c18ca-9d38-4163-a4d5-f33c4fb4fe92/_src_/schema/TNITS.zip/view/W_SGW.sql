CREATE VIEW W_SGW AS select "SGWID","SGWNAME","IP","ROUTER","REMARK","ISTDATE","UPTDATE","PGWID","ECI","TAC","PROVINCE" as "AREAID" ,"PROVINCE" from i_sgw where PROVINCE <> (select paramvalue from s_param where paramname='VOLTE_STATAREACODE')
/
