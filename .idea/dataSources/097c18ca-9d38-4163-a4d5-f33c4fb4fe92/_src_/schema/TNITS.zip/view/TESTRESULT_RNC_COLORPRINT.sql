CREATE VIEW TESTRESULT_RNC_COLORPRINT AS select  b.ProgID,b.Remark1,b.Caller,b.Remark2,b.Called,b.StartTime,b.EndTime,b.ResponseTime,case b.TalkStatus when 1 then '超时' when 2 then '正常' when 4 then '失败' else ' ' end as taskstatus,b.CodeData,b.TotalTime,b.ResponseTime-b.TotalTime as ringTime,a.taskid,a.taskname,'2/3g彩印' AS nettype , case a.tonecode1 when '0' then  '主叫彩印' else '被叫彩印' end as testtype
from z_taskinfo a,z_testresult b
where b.testcode=840 and b.starttime>=trunc(sysdate-7) and a.taskid=b.taskid and b.starttime>to_date('2016-12-26','yyyy-mm-dd')
WITH READ ONLY
/
