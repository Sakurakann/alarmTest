CREATE VIEW W_PSBC AS select "PSBCID","PSBCNAME","PROVINCE" as "AREAID" ,"ROUTER","IP","PORT","REMARK","ISTDATE","UPTDATE","PGWID","PROVINCE" from i_psbc where PROVINCE <> (select paramvalue from s_param where paramname='VOLTE_STATAREACODE')
/
