CREATE VIEW W_AREA AS select "AREAID","AREANAME","AREACODE","STATE","ISTDATE","UPTDATE","REMARK1","REMARK2","AREAALIAS","AREAABB","FATHERID","AREALEVEL" from i_area where areaid <> (select paramvalue from s_param where paramname='VOLTE_STATAREACODE')
/
