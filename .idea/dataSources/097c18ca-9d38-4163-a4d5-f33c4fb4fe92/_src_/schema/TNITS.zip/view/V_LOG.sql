CREATE VIEW V_LOG AS select istdate as LogTime,operator as SubUser,'业务监测系统' as App,ipaddress as Sip,module as AppModule,
context as OpMsg,command as OpType,'1' as Result,'2' as LogLevel  from s_log

/
