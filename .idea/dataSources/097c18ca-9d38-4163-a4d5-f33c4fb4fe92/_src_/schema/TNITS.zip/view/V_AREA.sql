CREATE VIEW V_AREA AS select "ISTDATE","UPTDATE","AREAID","AREANAME","AREACODE","STATE","DZ","GJ","SF","DQ" from (
 select istdate,uptdate,areaid,areaname,areacode,state,areaname as dz, '' as gj, '' as sf , '' dq from I_area where arealevel=1
 union
 select istdate,uptdate,i.areaid,areaname,i.areacode,i.state,(select a.areaname from i_area a where a.areaid=i.fatherid ) as dz, areaname as gj, '' as sf , '' dq from I_area i where i.arealevel=2
 union
 select istdate,uptdate,i.areaid,areaname,i.areacode,i.state,(select ar.areaname from i_area ar where ar.areaid=(select a.fatherid from i_area a where a.areaid=i.fatherid )) as dz, (select a1.areaname from i_area a1 where a1.areaid=i.fatherid) as gj, areaname as sf , '' dq from I_area i where i.arealevel=3
 union
  select istdate,uptdate,i.areaid,areaname,i.areacode,i.state,(select a3.areaname from i_area a3 where a3.areaid=(select ar.fatherid from i_area ar where ar.areaid=(select a.fatherid from i_area a where a.areaid=i.fatherid ))) as dz, (select a2.areaname from i_area a2 where a2.areaid=(select a1.fatherid from i_area a1 where a1.areaid=i.fatherid)) as gj, (select a1.areaname from i_area a1 where a1.areaid=i.fatherid) as sf , i.areaname dq from I_area i where i.arealevel=4
 ) order by dz,gj,sf,dq

/
