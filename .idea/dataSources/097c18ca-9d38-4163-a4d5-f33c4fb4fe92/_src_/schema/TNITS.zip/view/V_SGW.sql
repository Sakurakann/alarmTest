CREATE VIEW V_SGW AS select "SGWID","SGWNAME","IP","ROUTER","REMARK","ISTDATE","UPTDATE","PGWID","ECI","TAC","AREAID","PROVINCE" from i_sgw where PROVINCE=(select paramvalue from s_param where paramname='VOLTE_STATAREACODE')
/
