CREATE VIEW V_ALARM_NE AS select "TYPE","NENAME" from (
select 'SWITCH' as type,switchname as nename from i_switch--交换机出局
union
select 'SGSN' as type,sgsnname as nename from i_sgsn--sgsn设备
union
select 'GGSN' as type,ggsnname as nename from i_ggsn--ggsn设备
union
select 'WAP' as type,wapname as nename  from i_wap--wap
union
select 'MME' as type,mmename as nename from i_mme-- mme
union
select 'SP' as type,rsname as nename from i_gprsresource --sp资源
)
/
