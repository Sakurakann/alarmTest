CREATE VIEW TESTRESULT_VOLTE_COLORPRINT AS select a.taskid,a.taskname, b.ProgID,a.outnename,b.Caller,a.innename,b.Called,b.StartTime,b.EndTime,b.MinDelay,b.responseTime ,(b.responseTime-b.MinDelay)  as ringTime,case b.TalkStatus when 1 then '超时' when 2 then '正常' when 4 then '失败' else ' ' end as taskstatus,b.CodeData,'4G彩印' AS nettype , case a.tonecode1 when  '0'  then '主叫彩印' else '被叫彩印' end  as testtype,b.activationTime,b.receivetime,b.operateTime
from z_taskinfo a,z_testresult b
where b.testcode=3040 and b.starttime>=trunc(sysdate-7) and a.taskid=b.taskid  and b.starttime>to_date('2016-12-26','yyyy-mm-dd')
WITH READ ONLY
/
