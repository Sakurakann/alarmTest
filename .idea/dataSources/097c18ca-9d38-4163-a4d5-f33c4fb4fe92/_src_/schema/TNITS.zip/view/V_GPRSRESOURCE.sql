CREATE VIEW V_GPRSRESOURCE AS select "ID","RSTYPE","RSNAME","IP","URL","KEYWORD","PORT","USERNAME","PASSWORD","REMARK","ISTDATE","UPTDATE" from i_gprsresource a where not exists ( select * from (
select remark from i_gprsresource where remark<>' ' group by remark having count(1)>10) b where a.remark = b.remark)
/
