CREATE VIEW V_VOLTE_NE AS select "DEVICENAME","TYPENAME" from ( select mmename as devicename,'MME' as typename from i_mme union select switchname as devicename,'SWITCH' as typename from i_switch union select draname as devicename,'DRA'  as typename from i_dra union select devicename as devicename,'IMS' as typename from i_imsproxy ) a
/
