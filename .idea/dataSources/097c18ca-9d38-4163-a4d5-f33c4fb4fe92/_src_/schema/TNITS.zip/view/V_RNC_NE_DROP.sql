CREATE VIEW V_RNC_NE_DROP AS select 1 as type, a.switchcode,a.switchname,a.router,b.shortcode,a.switchid,a.areaid
from I_SWITCH a inner join I_RNCRESOURCE b on a.switchid = b.switchid
union all
select 2 as type,a.switchcode,a.switchname,a.router,case when b.switchid is null or b.switchid = ' 'then ''else  b.shortcode end shortcode,a.switchid,a.areaid
from I_SWITCH a left join I_RNCRESOURCE b on a.switchid = b.switchid where a.switchtype=3


/
