CREATE VIEW V_MME_CONNTECT AS (
select areaid,num||'$'|| replace(mme,'#','$') mme from(
select areaid,max(l) num,ltrim(max(sys_connect_by_path(mmename,'#')),'#') mme
from(
select a.areaid||'-'||b.areaname areaid,count(*) over(partition by a.areaid) l,a.DSTHOST||'$'||router mmename,row_number() over(partition by a.areaid order by a.mmeid) rn from i_mme a inner join i_area b on a.areaid = b.areaid)
start with rn=1
connect by rn -1 = prior rn and areaid = prior areaid
group by areaid)
)
/
